﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dwarf.ObjectModel
{
	public interface ISourced
	{
		object Source { get; set; }
	}

	public interface ISourced<TSource>
	{
		TSource Source { get; set; }
	}
}
