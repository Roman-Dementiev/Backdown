﻿using System;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml;
using Dwarf.Platform;
using Windows.UI.Xaml.Controls.Primitives;

namespace Dwarf.UI
{
	public class ChoiceListView : ListView
	{
		public ChoiceListView()
		{
			DefaultStyleKey = typeof(ChoiceListView);
			SelectionChanged += OnSelectionChanged;
		}

		public IChoices Choices {
			get => choices;
			set => SetChoices(value);
		}
		IChoices choices;

		void SetChoices(IChoices choices)
		{
			if (choices == this.choices)
				return;

			if (this.choices != null) {
				this.choices.CurrentChoiceChanged -= OnCurrentChoiceChanged;
			}

			if (choices != null) {
				choices.CurrentChoiceChanged += OnCurrentChoiceChanged;
			}

			this.choices = choices;
			ItemsSource = choices;

			OnCurrentChoiceChanged();
		}

		public void OnCurrentChoiceChanged(IChoices sender = null)
		{
			if (SelectedItem != choices?.CurrentChoice) {
				SelectedItem = choices?.CurrentChoice;
			}
		}

		private void OnSelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (choices != null & SelectedItem != choices.CurrentChoice) {
				choices.CurrentChoice = SelectedItem as IChoice;
			}
		}

		protected override void OnApplyTemplate()
		{
			base.OnApplyTemplate();
			OnCurrentChoiceChanged();
		}
	}
}
