﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing
{
	/// <summary>
	/// Class ASTFactory
	/// </summary>
	public class ASTFactory : ITokenFactory
	{
		#region Methods
		public object CreateTerminal(int sym, char[] buffer, int start, int length)
		{
			return new string(buffer, start, length);
		}

		public object CreateNonterminal(uint rule, Token[] tokens, int start, int length)
		{
			var production = new Token[length];
			Array.Copy(tokens, start, production, 0, length);
			return production;
		}
		#endregion

	}

	#region UnitASTFactory
	public sealed class UnitASTFactory : ClassUnit
	{
		private UnitASTFactory() : base(typeof(ASTFactory), UnitParsing._) { }
		public static readonly UnitASTFactory _ = new UnitASTFactory();
		public static UnitASTFactory Instance => _;
	}
	#endregion
}
