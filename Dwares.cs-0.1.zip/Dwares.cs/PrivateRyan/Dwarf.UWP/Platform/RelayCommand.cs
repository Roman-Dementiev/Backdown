﻿using System;
using System.Threading;
using System.Windows.Input;


namespace Dwarf.Platform
{
	/// <summary>
	/// A command whose sole purpose is to relay its functionality 
	/// to other objects by invoking delegates. 
	/// The default return value for the CanExecute method is 'true'.
	/// <see cref="RaiseCanExecuteChanged"/> needs to be called whenever
	/// <see cref="CanExecute"/> is expected to return a different value.
	/// </summary>
	public class RelayCommand : ICommand
	{
		Action<object> execute;
		Func<object, bool> canExecute;

		public static RelayCommand LazyInit(ref RelayCommand command, Action execute, Func<bool> canExecute = null)
			=> LazyInitializer.EnsureInitialized(ref command, () => new RelayCommand(execute, canExecute));

		public static RelayCommand LazyInit(ref RelayCommand command, Action<object> execute, Func<object, bool> canExecute = null)
			=> LazyInitializer.EnsureInitialized(ref command, () => new RelayCommand(execute, canExecute));

		/// <summary>
		/// Raised when RaiseCanExecuteChanged is called.
		/// </summary 
		public event EventHandler CanExecuteChanged;


		public RelayCommand() { }


		/// <summary>
		/// Creates a new command.
		/// </summary>
		/// <param name="execute">The execution logic.</param>
		/// <param name="canExecute">The execution status logic.</param>
		public RelayCommand(Action<object> execute, Func<object, bool> canExecute = null)
		{
			this.execute = execute;
			this.canExecute = canExecute;
		}

		/// <summary>
		/// Creates a new command.
		/// </summary>
		/// <param name="execute">The execution logic.</param>
		/// <param name="canExecute">The execution status logic.</param>
		public RelayCommand(Action execute, Func<bool> canExecute = null)
		{
			SetExecute(execute, canExecute);
		}

		/// <summary>
		/// Set the command execute logic.
		/// </summary>
		/// <param name="execute">The execution logic.</param>
		/// <param name="canExecute">The execution status logic.</param>
		public void SetExecute(Action execute, Func<bool> canExecute = null)
		{
			if (execute != null) {
				this.execute = (parameter) => execute?.Invoke();
			} else {
				this.execute = null;
			}

			if (canExecute != null) {
				this.canExecute = (parameter) => canExecute();
			} else {
				this.canExecute = null;
			}
			RaiseCanExecuteChanged();
		}

		/// <summary>
		/// Set the command execute logic.
		/// </summary>
		/// <param name="execute">The execution logic.</param>
		/// <param name="canExecute">The execution status logic.</param>
		public void SetExecute(Action<object> execute, Func<object, bool> canExecute = null)
		{
			this.execute = execute;
			this.canExecute = canExecute;
			RaiseCanExecuteChanged();
		}

		public void SetCanExecute(Func<object, bool> canExecute)
		{
			this.canExecute = canExecute;
			RaiseCanExecuteChanged();
		}

		/// <summary>
		/// Determines whether this <see cref="RelayCommand"/> can execute in its current state.
		/// </summary>
		/// <param name="parameter">
		/// Data used by the command. If the command does not require data to be passed, this object can be set to null.
		/// </param>
		/// <returns>true if this command can be executed; otherwise, false.</returns>
		public bool CanExecute(object parameter)
		{
			if (execute != null) {
				return canExecute == null ? true : canExecute(parameter);
			} else {
				return false;
			}
		}

		/// <summary>
		/// Executes the <see cref="RelayCommand"/> on the current command target.
		/// </summary>
		/// <param name="parameter">
		/// Data used by the command. If the command does not require data to be passed, this object can be set to null.
		/// </param>
		public void Execute(object parameter)
		{
			execute?.Invoke(parameter);
		}

		/// <summary>
		/// Method used to raise the <see cref="CanExecuteChanged"/> event
		/// to indicate that the return value of the <see cref="CanExecute"/>
		/// method has changed.
		/// </summary>
		public void RaiseCanExecuteChanged()
		{
			CanExecuteChanged?.Invoke(this, EventArgs.Empty);
		}
	}
}