﻿using System;
using System.IO;
using Dwarf.Utility;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing
{
	/// <summary>
	/// Class DFA
	/// </summary>
	public class DFA : ILexer
	{
		#region Fields
		protected ICharSets charSets;
		protected IDfaStates states;
		protected uint initialState;
		protected uint currentState;
		protected Lookahead lookahead;
		protected DwarfException error;
		#endregion

		#region Properties
		public ICharSets CharSets => charSets;
		public IDfaStates States => states;
		public Lookahead Lookahead => lookahead;
		public TextPosition Position => lookahead.GetPosition();
		public char[] Buffer => lookahead.Buffer;
		public DwarfException Error => error;
		#endregion

		#region Constructors
		public DFA(ICharSets charSets, IDfaStates states, uint initialState)
		{
			Init(charSets, states, initialState);
		}

		protected DFA() { }

		protected void Init(ICharSets charSets, IDfaStates states, uint initialState)
		{
			this.charSets = charSets;
			this.states = states;
			this.initialState = initialState;
			this.currentState = initialState;
		}
		#endregion

		#region Methods

		public void Prepare(Lookahead lookahead)
		{
			if (charSets == null || states == null) {
				new ParserInitializationError(UnitLALRParser._);
			}

			this.lookahead = lookahead;
			currentState = initialState;
			error = null;
		}

		public void Prepare(TextReader source)
		{
			Prepare(new Lookahead(source));
		}

		public int LookaheadToken(out int start, out int length)
		{
			Debug.Assert(lookahead != null);
			start = lookahead.LookaheadLength;
			length = 0;
			char ch = lookahead.LookaheadChar();
			if (ch == TextSource.EOF) {
				return Symbols.cEOF;
			}

			currentState = initialState;
			int acceptedSym = -1;
			int acceptedLen = 0;
			for (;;)
			{
				int targetState = -1;
				for (uint edge = 0, count = states.EdgeCount(currentState); edge < count; edge++)
				{
					uint charset = states.EdgeCharSet(currentState, edge);
					if (charSets.CharInCharset(ch, charset)) {
						targetState = (int)states.EdgeTargetState(currentState, edge);
						break;
					}
				}

				if (targetState < 0) {
					lookahead.PushBack();
				}

				if (states.IsAcceptState(currentState)) {
					acceptedSym = states.AcceptSymbol(currentState);
					acceptedLen = lookahead.LookaheadLength;
				}

				if (targetState < 0)
					break;

				currentState = (uint)targetState;
				ch = lookahead.LookaheadChar();
				if (ch == TextSource.EOF)
					break;
			}

			if (acceptedSym >= 0) {
				length = lookahead.LookaheadLength = acceptedLen;
				return acceptedSym;
			} else {
				SetError(start, ch);
				return Symbols.cError;
			}
		}

		protected void SetError(int start, char ch = TextSource.EOF)
		{
			lookahead.LookaheadLength = 0;
			if (ch == Lookahead.EOF) {
				error = new UnnexpectedEOF(UnitDFA._);
			} else {
				string text = lookahead.LookaheadText(start); 
				error = new UnnexpectedChar(UnitDFA._, ch, text);
			}
		}

		public void ConsumeLookahead()
		{
			lookahead.ConsumeLookahead();
		}
		#endregion
	}

	#region UnitDFA
	public sealed class UnitDFA : ClassUnit
	{
		private UnitDFA() : base(typeof(DFA), UnitParsing._) { }
		public static readonly UnitDFA _ = new UnitDFA();
		public static UnitDFA Instance => _;
	}
	#endregion
}
