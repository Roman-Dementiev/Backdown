﻿//using System;
//using System.IO;
//#pragma warning disable RCS1060, RCS1023

//namespace Dwarf.Parsing
//{
//	/// <summary>
//	/// Class Lexer
//	/// </summary>
//	public class Lexer : ILexer
//	{
//		#region Properties
//		private Symbols symbols;
//		private DFA dfa;
//		public int SymComment { get; } = -1;
//		public int SymCommentLine { get; } = -1;
//		public int SymCommentStart { get; } = -1;
//		public int SymCommentEnd { get; } = -1;
//		#endregion

//		#region Constructors
//		public Lexer(Symbols symbols, DFA dfa)
//		{
//			this.symbols = symbols;
//			this.dfa = dfa;
//		}

//		public Lexer(Symbols symbols, DFA dfa, int symComment = -1, int symCommentLine = -1,
//					int symCommentStart = -1, int symCommentEnd = -1)
//		{
//			this.symbols = symbols;
//			this.dfa = dfa;
//			SymComment = symComment;
//			SymCommentLine = symCommentLine;
//			SymCommentStart = symCommentStart;
//			SymCommentEnd = symCommentEnd;
//		}

//		#endregion

//		#region Methods
//		public void Prepare(TextReader source)
//		{
//			dfa.Prepare(source);
//		}

//		public int LookaheadToken(out int start, out int length)
//		{
//			int sym = dfa.LookaheadToken(out start, out length);

//			if (SymComment >= 0) {
//				if (sym == SymCommentLine) {
//					text = buffer.ReadLine();
//					return new NoiseToken(SymComment, text);
//				}

//				if (token.Symbol == SymCommentStart) {
//					int commentLevel = 1;
//					do {
//						token = Lookahead();
//						if (token.Symbol == Symbols.EOF) {
//							return new ErrorToken(new UnnexpectedEOF(UnitLexer._));
//						}
//						if (token.Symbol == SymCommentStart) {
//							commentLevel++;
//						} else if (token.Symbol == SymCommentEnd) {
//							commentLevel--;
//						}
//					}
//					while (commentLevel > 0);
//				}

//				buffer.ConsumeLookahead(out text);
//				return new NoiseToken(SymComment, text);
//			}

//			buffer.ConsumeLookahead();
//			return token;
//		}
//		#endregion
//	}

//	#region UnitLexer
//	public sealed class UnitLexer : ClassUnit
//	{
//		private UnitLexer() : base(typeof(Lexer), UnitParsing._) { }
//		public static readonly UnitLexer _ = new UnitLexer();
//		public static UnitLexer Instance => _;
//	}
//	#endregion
//}
