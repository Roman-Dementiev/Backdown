﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing.Tiny
{
	#region UnitTiny
	public sealed class UnitTiny : NamespaceUnit
	{
		private UnitTiny() : base("Tiny", UnitParsing._) { }
		public static readonly UnitTiny _ = new UnitTiny();
		public static UnitTiny Instance => _;
	}
	#endregion
}
