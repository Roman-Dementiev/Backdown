﻿using System;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;
using Dwarf.Extensions;


namespace Dwarf.UI
{
	public class TextField : TextBox
	{
		public TextField()
		{
			DefaultStyleKey = typeof(TextField);
		}
		
		public InputScopeNameValue InputScopeNameValue {
			get => InputScope.DefaultScopeNameValue();
			set {
				InputScope = value.ToInputScope();
			}
		}
	}
}
