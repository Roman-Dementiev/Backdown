﻿using System;
using System.Threading;
using Windows.UI.Xaml.Controls;
using Dwarf.Localization;


namespace Azbooka
{
	public sealed partial class SettingsPanel : SettingsFlyout
	{
		public SettingsPanel()
		{
			this.InitializeComponent();

			languageCombo.ItemsSource = UILanguages.Instance;
		}

		public Abc ViewModel => Abc.Instance;

		public Localizable Localizable => LazyInitializer.EnsureInitialized(
			ref localizable, () => new Localizable() {
				languageLabel,
				languageCombo,
				themeLabel,
				themeCombo,
			});
		Localizable localizable;
	}
}
