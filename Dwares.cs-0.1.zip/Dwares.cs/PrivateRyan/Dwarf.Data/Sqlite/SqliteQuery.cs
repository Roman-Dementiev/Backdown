﻿using System;
using System.Data;
using Microsoft.Data.Sqlite;


namespace Dwarf.Data.Sqlite
{
	public class SqliteQuery : Query
	{
		public SqliteQuery() { }
		public SqliteQuery(IDataReader reader) : base(reader) { }
		public SqliteQuery(SqliteCommand command) : base(command) { }

		public new bool Bool(string key, bool defaultValue = false) => Long(key) != 0;
		public new int Int(string key, int defaultValue = -1) => (int)Long(key, defaultValue);
		public new short Short(string key, short defaultValue = -1) => (short)Long(key, defaultValue);
		public new byte Byte(string key, byte defaultValue = 0) => (byte)Long(key, defaultValue);
	}
}
