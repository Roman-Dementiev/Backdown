﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Utility
{
	/// <summary>
	/// Utility class Enums
	/// </summary>
	public static class Enums
	{
		#region Properties
		#endregion

		#region Methods
		public static TEnum ToEnum<TEnum>(string str, bool ignoreCase = false) where TEnum : struct
		{
			try {
				return (TEnum)Enum.Parse(typeof(TEnum), str, ignoreCase);
			}
			catch (Exception exc) {
				Log.Error(UnitEnums._, "Invalid argument in Enums.ToEnum({0}): {1}",
						str, exc.Message);
				throw;
			}
		}

		public static TEnum ToEnum<TEnum>(string str, TEnum defaultValue, bool ignoreCase = false) where TEnum : struct
		{
			if (!String.IsNullOrEmpty(str)) {
				TEnum result;
				if (Enum.TryParse(str, out result)) {
					return result;
				}
			}
			return defaultValue;
		}

		public static TEnum ToEnum<TEnum>(object obj, bool ignoreCase = false) where TEnum : struct
		{
			if (obj.GetType() == typeof(TEnum)) {
				return (TEnum)obj;
			} else {
				return ToEnum<TEnum>(obj.ToString(), ignoreCase);
			}
		}

		public static TEnum ToEnum<TEnum>(object obj, TEnum defaultValue, bool ignoreCase = false) where TEnum : struct
		{
			if (obj != null) {
				TEnum result;
				if (Enum.TryParse(obj.ToString(), out result)) {
					return result;
				}
				return defaultValue;
			}
			return defaultValue;
		}

		#endregion
	}

	#region UnitEnums	
	public sealed class UnitEnums : ClassUnit
	{
		private UnitEnums() : base(typeof(Enums), UnitUtility._) { }
		public static readonly UnitEnums _ = new UnitEnums();
		public static UnitEnums Instance => _;
	}
	#endregion
}
