﻿using System;
using Dwarf.ObjectModel;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;


namespace Azbooka
{
	//public class TextField : Dwarf.UI.TextField { }
	//public class PopupControl : Dwarf.UI.PopupControl { }
	//public class ImageButton : Dwarf.UI.ImageButton { }
	
	//public class GlyphButton : Button
	//{
	//	public GlyphButton() { }

	//	public string Glyph {
	//		get => glyph;
	//		set => glyph.Set(value, () => { Content = value; });
	//	}
	//	PropertyValue<string> glyph;

	//	public Color HilightColor {
	//		get { return (Color)GetValue(HilightColorProperty); }
	//		set { SetValue(HilightColorProperty, value); }
	//	}

	//	public static readonly DependencyProperty HilightColorProperty = DependencyProperty.Register(nameof(HilightColor), typeof(Color), typeof(GlyphButton), new PropertyMetadata(Color.FromArgb(255, 0, 0, 0)));
	//}
}
