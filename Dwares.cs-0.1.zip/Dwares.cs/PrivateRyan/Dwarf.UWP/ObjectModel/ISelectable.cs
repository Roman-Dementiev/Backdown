using System;

namespace Dwarf.ObjectModel
{
	public interface ISelectable
	{
		bool IsSelected { get; set; }
	}
}