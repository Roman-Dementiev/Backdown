﻿using System;
using Dwarf.Config;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Assets
{
	public static class Messages
	{
		public const string GetAssetTypeMismatch = nameof(GetAssetTypeMismatch); // key, expectedType, actualType
		public const string AddAssetTypeMismatch = nameof(AddAssetTypeMismatch); // key, actualType, expectedType
	}

	#region UnitAssets
	public sealed class UnitAssets : NamespaceUnit
	{
		private UnitAssets() : base("BaseAssets", UnitDwarf._)
		{
#if INIT_DEFAULT_MESSAGES
			AssetMgr.SetDefaultStrings(
				Messages.GetAssetTypeMismatch, "GetAsset(\"{0}\", type={1}); actual type is {2}",   // key, expectedType, actualType
				Messages.AddAssetTypeMismatch, "AddAsset(\"{0}\", type={1}); expected type is {2}"  // key, actualType, expectedType
			);
#endif
		}
		public static readonly UnitAssets _ = new UnitAssets();
		public static UnitAssets Instance => _;
	}
	#endregion
}
