﻿using System;
using Dwarf;
using Dwarf.ObjectModel;
using Dwarf.Platform;


namespace Azbooka
{
	public class Language : ShelfEntity, ICloneable<Language> //, IPopupChoice
	{
		public Language(string tag) : base(tag) { }

		public Language(string tag, Language language) :
			base(tag, language)
		{ }

		public string Tag => Uid;
		public string NativeName {
			get {  return DefaultName; }
			set {  DefaultName = value; }
		}

		public LanguagePoSList PoS => PartsOfSpeech.GetLanguagePoSList(Tag);

		//public string ChoiceLabel => Name;
		//public Bitmap ChoiceImage => Icon;
		//public string FlyoutLabel => Name;
		//public Bitmap FlyoutImage => Icon;

		object ICloneable.Clone(bool deepCopy) => new Language(Tag, this);
		public Language Clone(bool deepCopy) => new Language(Tag, this);
		public void CopyFrom(Language language, bool deepCopy = false) => base.CopyFrom(language);
	}
}
