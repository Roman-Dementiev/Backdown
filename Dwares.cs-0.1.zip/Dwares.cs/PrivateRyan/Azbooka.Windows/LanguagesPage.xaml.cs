﻿using System;
using System.Collections.Generic;
using Windows.UI.Xaml.Controls;
using Dwarf.ObjectModel;
using Dwarf.Platform;
using Dwarf.UI;


namespace Azbooka
{
	public sealed partial class LanguagesPage : Page, IStateful
	{
		LanguageViewHelper helper = new LanguageViewHelper();

		public LanguagesPage()
		{
			this.InitializeComponent();

			helper.AttachTo(gridView);

			gridView.ItemsSource = Languages.Known;
		}

		public Abc ViewModel => Abc.Instance;
		public bool NeedGoBack => true;

		public string Title => Appx.GetString(_Title);
		const string _Title = "Languages";

		//public LocalizableUI LocalizableUI => LazyInitializer.EnsureInitialized(
		//	ref localizableUI, () => new LocalizableUI() {
		//	});
		//LocalizableUI localizableUI;


		public string StateKey => _Title;
		public void LoadState(StateDict state, StateDict shared, object navigationParameter)
		{
		}

		public void SaveState(ref StateDict state, ref StateDict shared, object navigationParameter)
		{
			Abc.Instance.UpdateActiveLanguages(helper.SelectedChanged);
			helper.SelectedChanged.Clear();
		}
	}
}
