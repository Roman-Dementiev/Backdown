﻿//using System;
//using System.Collections;
//using System.Collections.Generic;


//namespace Dwarf.Collections
//{
//	public class ListCasting<TItem, TBase> : ListWrapper<TItem>, IReadOnlyList<TBase> where TItem : TBase
//	{
//		public ListCasting() { }
//		public ListCasting(IEnumerable<TItem> items) : base(items) { }
//		public ListCasting(IList<TItem> source) : base(source) { }

//		public int IndexOf(TBase baseItem)
//		{
//			if (baseItem is TItem item) {
//				return items.IndexOf(item);
//			} else {
//				return -1;
//			}
//		}

//		TBase IReadOnlyList<TBase>.this[int index] => items[index];
//		IEnumerator<TBase> IEnumerable<TBase>.GetEnumerator() => new RelayEnumerator<TBase, TItem>(items);
//	}
//}
