﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf
{
	/// <summary>
	/// Utility class Debug
	/// </summary>
	public static class Debug
	{
#if DEBUG
		public const bool IsDebugConfiguration = true;
#else
		public const bool IsDebugConfiguration = false;
#endif

		/// <summary>
		/// Gets a value that indicates whether a debugger is attached to the process.
		/// </summary>
		/// <value>
		/// <c>true</c> if a debugger is attached; otherwise, <c>false</c>.
		/// </value>
		public static bool IsAttached => System.Diagnostics.Debugger.IsAttached;

		/// <summary>
		/// Gets or sets a value indicating whether attach debugger when <see cref="Debug"/ method is called>.
		/// </summary>
		/// <value>
		///   if <c>true</c> debugger will be attached; otherwise, Debug methods will be ignored</c>.
		/// </value>
		public static bool AutoAttach {
			get; set;
		} = true;

		/// <summary>
		/// Gets a value indicating whether this instance is attached.
		/// In Debug build attach debugger if <see cref="AutoAttach" /> is <c>true</c> and condition is <c>false</c>.
		/// </summary>
		/// <param name="condition">The condition.</param>
		/// <returns>
		///   <c>true</c> if a debugger is attached; otherwise, <c>false</c>.
		/// </returns>
		public static bool IsAttachedOrAuto(bool condition=false) {
#if DEBUG
			if (!condition && AutoAttach && !System.Diagnostics.Debugger.IsAttached) {
				System.Diagnostics.Debugger.Launch();
			}
#endif
			return System.Diagnostics.Debugger.IsAttached;
		}

		/// <summary>
		/// In Debug build launches and attaches a debugger to the process.
		/// Does nothing in Release build.
		/// </summary>
		[System.Diagnostics.Conditional("DEBUG")]
		public static void Attach()
		{
			if (!System.Diagnostics.Debugger.IsAttached) {
				System.Diagnostics.Debugger.Launch();
			}
		}

		/// <summary>
		/// In Debug build signals a breakpoint to an attached debugger.
		/// Does nothing in Release build.
		/// </summary>
		[System.Diagnostics.Conditional("DEBUG")]
		public static void Break()
		{
			if (IsAttachedOrAuto()) {
				System.Diagnostics.Debugger.Break();
			}
		}

		/// <summary>
		/// In Debug build writes a message followed by a line terminator to the trace listeners.
		/// Does nothing in Release build.
		/// </summary>
		/// <param name="message">The message.</param>
		[System.Diagnostics.Conditional("DEBUG")]
		public static void Print(string message)
		{
			if (IsAttachedOrAuto()) {
				System.Diagnostics.Debug.WriteLine(message);
			}
		}

		/// <summary>
		/// In Debug build writes a formatted message followed by a line terminator to the trace listeners.
		/// Does nothing in Release build.
		/// </summary>
		/// <param name="format">The format.</param>
		/// <param name="args">The arguments.</param>
		[System.Diagnostics.Conditional("DEBUG")]
		public static void Print(string format, params object[] args)
		{
			if (IsAttachedOrAuto()) {
				System.Diagnostics.Debug.WriteLine(format, args);
			}
		}

		/// <summary>
		/// In Debug build writes a category name and message to the trace listeners.
		/// Does nothing in Release build.
		/// </summary>
		/// <param name="message">The message.</param>
		/// <param name="category">The category.</param>
		[System.Diagnostics.Conditional("DEBUG")]
		public static void Print(string message, string category)
		{
			if (IsAttachedOrAuto()) {
				System.Diagnostics.Debug.WriteLine(message, category);
			}
		}

		/// <summary>
		/// In Debug build condition; if it <c>false</c> shows dialog box showing call stach
		/// Does nothing in Release build.
		/// </summary>
		/// <param name="condition">if set to <c>true</c> [condition].</param>
		/// <param name="message">The message.</param>
		/// <param name="details">The detailed message.</param>
		/// <param name="args">The arguments for detailed message.</param>
		[System.Diagnostics.Conditional("DEBUG")]
		public static void Assert(bool condition, string message = null, string details = null, params object[] args)
		{
			if (IsAttachedOrAuto(condition))
			{
				if (message == null) {
					System.Diagnostics.Debug.Assert(condition);
				} else if (details == null) {
					System.Diagnostics.Debug.Assert(condition, message);
				} else if (args == null) {
					System.Diagnostics.Debug.Assert(condition, message, details);
				} else {
					System.Diagnostics.Debug.Assert(condition, message, details, args);
				}
			}
		}

		/// <summary>
		/// Fails the specified message.
		/// </summary>
		/// <param name="message">The message.</param>
		/// <param name="details">The detailed message.</param>
		[System.Diagnostics.Conditional("DEBUG")]
		public static void Fail(string message, string details=null)
		{
			if (IsAttachedOrAuto())
			{
				if (details == null) {
					System.Diagnostics.Debug.Fail(message);
				} else {
					System.Diagnostics.Debug.Fail(message, details);
				}
			}
		}
	}

	#region UnitDebug
	public class UnitDebug : UtilityUnit
	{
		private UnitDebug() : base(typeof(Debug), UnitDwarf._) { }
		public static readonly UnitDebug _ = new UnitDebug();
		public static UnitDebug Instance => _;
	}
	#endregion
}
