﻿//#define AUTO_LOCALIZABLE
using System;
using System.Threading;
using Windows.UI.Xaml.Controls;
using Dwarf.Platform;
using Dwarf.UI;
using Dwarf.Localization;


namespace Azbooka
{
	public sealed partial class BookshelfPage : Page
	{
		EntityListViewHelper<Book> bookViewHelper = new EntityListViewHelper<Book>();
		EntityListViewHelper<Language> languageViewHelper = new EntityListViewHelper<Language>();
		EntityListViewHelper<Topic> topicViewHelper = new EntityListViewHelper<Topic>();

		public BookshelfPage()
		{
			this.InitializeComponent();

			bookViewHelper.AttachTo(booksList);
			languageViewHelper.AttachTo(languagesList);
			topicViewHelper.AttachTo(topicsList);

			booksList.ItemsSource = ViewModel.Books;
			languagesList.ItemsSource = ViewModel.Languages;

			moreLanguages.Action = MoreLanguages;
			addTopic.Action = AddTopic;

#if AUTO_LOCALIZABLE
			LocalizableUI.SetMode(this, LocalizableUI.Mode.Auto);
#endif
		}

		public Abc ViewModel => Abc.Instance;
		public string Title => Appx.GetString(_Title);
		const string _Title = "Bookshelf";

#if !AUTO_LOCALIZABLE
		public Localizable Localizable => LazyInitializer.EnsureInitialized(
			ref localizable, () => new Localizable() {
				booksCaption,
				languagesCaption,
				topicsCaption,
				moreLanguages,
				addTopic
			});
		Localizable localizable;
#endif

		RelayCommand ImportCommand => RelayCommand.LazyInit(ref importCommand, Import);
		RelayCommand importCommand = null;

		RelayCommand ExportCommand => RelayCommand.LazyInit(ref exportCommand, Export);
		RelayCommand exportCommand = null;

		RelayCommand ClearCommand => RelayCommand.LazyInit(ref clearCommand, ClearUnused);
		RelayCommand clearCommand = null;

		void Import()
		{
			// TODO
		}

		void Export()
		{
			var exportPanel = new ExportPanel();
			Localizer.Localize(exportPanel);
			exportPanel.ShowIndependent();
		}

		void ClearUnused()
		{
			// TODO
		}


		public void MoreLanguages()
		{
			ViewModel.ContentFrame.Navigate(typeof(LanguagesPage));
		}

		void AddTopic()
		{
			// TODO
		}

		private void booksList_ContainerContentChanging(ListViewBase sender, ContainerContentChangingEventArgs e)
		{
//			bookViewHelper.ContainerContentChanging(sender, e);
		}

		private void booksList_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
//			bookViewHelper.SelectionChanged(sender, e);

			ViewModel.UpdateActiveBooks(bookViewHelper.SelectedChanged);
			bookViewHelper.SelectedChanged.Clear();
		}

		private void languagesList_ContainerContentChanging(ListViewBase sender, ContainerContentChangingEventArgs e)
		{
//			languageViewHelper.ContainerContentChanging(sender, e);
		}

		private void languagesList_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
//			languageViewHelper.SelectionChanged(sender, e);

			ViewModel.UpdateActiveLanguages(languageViewHelper.SelectedChanged);
			languageViewHelper.SelectedChanged.Clear();
		}

		private void topicsList_ContainerContentChanging(ListViewBase sender, ContainerContentChangingEventArgs e)
		{
//			topicViewHelper.ContainerContentChanging(sender, e);
		}

		private void topicsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
//			topicViewHelper.SelectionChanged(topicsList, e);

			ViewModel.UpdateActiveTopics(topicViewHelper.SelectedChanged);
			topicViewHelper.SelectedChanged.Clear();
		}
	}
}
