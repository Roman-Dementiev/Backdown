﻿using System;
using Dwarf;
using Dwarf.ObjectModel;


namespace Azbooka
{
	public class Meaning : Entity, ICloneable<Meaning>, IIndexed
	{
		public Meaning(Word word)
		{
			Word = word ?? throw new ArgumentNullException(nameof(word));
			Name = word.Name;
			Text = null;
			Translations = new ClonableCollection<Translation>();
		}

		public Meaning(string uid, Word word) :
			this(word)
		{
			Uid = uid ?? throw new ArgumentNullException(uid);
		}

		public Meaning(string uid, Meaning meaning, bool deepCopy) :
			base(uid)
		{
			CopyFrom(meaning, deepCopy);
		}

		public new string Uid {
			get {
				if (base.Uid == null) {
					base.Uid = String.Format("{0}:{1}:{2}", Word.Uid, PoS.Tag, /*TODO*/"something");
				}
				return base.Uid;
			}
			set => base.Uid = value;
		}

		public Word Word { get; private set; }
		public PoS PoS { get; set; }
		public string Text { get; set; }
		public ClonableCollection<Translation> Translations { get; private set; }

		public int Index {
			get => index;
			set => index.Set(value, () => NotifyPropertyChanged(nameof(Index)));
		}
		ScalarPropertyValue<int> index = new ScalarPropertyValue<int>(-1);

		public bool IsEditable {
			get => isEditable;
			set => isEditable.Set(value);
		}
		ScalarPropertyValue<bool> isEditable;


		object ICloneable.Clone(bool deepCopy) => new Meaning(uid, this, deepCopy);
		public Meaning Clone(bool deepCopy) => new Meaning(uid, this, deepCopy);
		
		public void CopyFrom(Meaning meaning, bool deepCopy = false)
		{
			base.CopyFrom(meaning);
			Word = meaning.Word;
			PoS = meaning.PoS;
			Text = meaning.Text;
			Translations = meaning.Translations.Clone(deepCopy);
		}
	}
}
