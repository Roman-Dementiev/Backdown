﻿using System;
using Windows.UI.Xaml.Controls;
using Dwarf.UWP;


namespace Azbooka
{
	/// <summary>
	/// An empty page that can be used on its own or navigated to within a Frame.
	/// </summary>
	public sealed partial class MainPage : Page
	{
		public Abc ViewModel => Abc.Instance;
		public NavigationHelper NavigationHelper { get; }

		public MainPage()
		{
			this.InitializeComponent();

			Abc.MainPage = this;
		}
	}
}
