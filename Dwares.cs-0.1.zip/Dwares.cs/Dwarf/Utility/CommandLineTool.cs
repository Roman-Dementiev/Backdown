﻿using System;
using Dwarf.Logging;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Utility
{
	/// <summary>
	/// Abstract class CommandLineTool
	/// </summary>
	public abstract class CommandLineTool
	{
		#region Properties
		public string[] Arguments { get; private set; }
		#endregion

		#region Methods
		public static void Main(CommandLineTool tool, string[] args,
								CommandLine.OptionStyle optionStyle = CommandLine.OptionStyle.Default,
								CommandLine.ProcessProc preprocess = null,
								CommandLine.ProcessProc postprocess = null)
		{
			Main(tool, tool, args, optionStyle, preprocess, postprocess);
		}

		public static void Main(CommandLineTool tool, object clTarget, string[] args,
								CommandLine.OptionStyle optionStyle = CommandLine.OptionStyle.Default,
								CommandLine.ProcessProc preprocess = null,
								CommandLine.ProcessProc postprocess = null)
		{
			Log.Logger = new TextLogger(Console.Out, new DefaultLogFormatter(true));

			if (!CommandLine.Parse(clTarget, args, optionStyle, preprocess, postprocess)) {
				Environment.Exit(-1);
			}
			tool.Arguments = args;

			try {
				Environment.ExitCode = tool.Run();
			}
			catch (DwarfException exc) {
				exc.Log();
				Environment.Exit(-1);
			}
			catch (Exception exc) {
				DwarfException.Wrap(exc).Log();
				Environment.Exit(-1);
			}
		}

		public abstract int Run();
		#endregion
	}

	#region UnitCommandLineTool
	public sealed class UnitCommandLineTool : ClassUnit
	{
		private UnitCommandLineTool() : base(typeof(CommandLineTool), UnitUtility._) { }
		public static readonly UnitCommandLineTool _ = new UnitCommandLineTool();
		public static UnitCommandLineTool Instance => _;
	}
	#endregion
}
