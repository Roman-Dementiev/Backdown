﻿using System;

namespace Dwarf.Config
{
	/// <summary>
	/// Class PlainConfig
	/// </summary>
	public class PlainConfig : CachedConfig
	{
		#region Constructors
		/// <summary>
		/// Initializes a new instance of the <see cref="PlainConfig"/> class.
		/// </summary>
		/// <param name="source">The buffer for this config.</param>
		/// <param name="mutable">if set to <c>true</c> config is mutable.</param>
		public PlainConfig(IConfig source, bool mutable = true) :
			base(source, mutable)
		{}

		/// <summary>
		/// Initializes a new instance of the <see cref="PlainConfig"/> class.
		/// </summary>
		/// <param name="mutable">if set to <c>true</c> config is mutable.</param>
		public PlainConfig(bool mutable=true) :
			this(null, mutable)
		{}
		#endregion

		#region Properties
		#endregion

		#region Methods
		protected virtual string FetchString(string key)
		{
			if (Source != null) {
				return Source.Get<string>(key);
			} else {
				return null;
			}
		}
		protected override object Fetch(string key, Type type)
		{
			string value = FetchString(key);
			if (value == null || type == null || type == typeof(string)) {
				return value;
			}

			try {
				return Convert.ChangeType(value, type);
			} 
			catch (Exception exc) {
				throw new InvalidConfigValue(UnitPlainConfig._, key, value, type, exc);
			}
		}
		#endregion

	}

	#region UnitPlainConfig
	#pragma warning disable RCS1060, RCS1023
	public sealed class UnitPlainConfig : ClassUnit
	{
		private UnitPlainConfig() : base(typeof(PlainConfig), UnitConfig._) { }
		public static readonly UnitPlainConfig _ = new UnitPlainConfig();
		public static UnitPlainConfig Instance => _;
	}
	#endregion
}
