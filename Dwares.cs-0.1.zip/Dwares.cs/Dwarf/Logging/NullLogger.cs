﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Logging
{
	/// <summary>
	/// Class NullLogger
	/// </summary>
	public class NullLogger : BaseLogger
	{
		#region Methods
		/// <summary>
		/// Writes nothing.
		/// </summary>
		/// <param name="level">Logging level.</param>
		/// <param name="source">The source.</param>
		/// <param name="message">The message.</param>
		/// <param name="args">The arguments.</param>
		/// <param name="formatted">if set to <c>true</c> message was formatted by <see cref="Log.DefaultFormatter" />.</param>
		public override void Write(LogLevel level, string source, string message, object[] args, bool formatted)
		{
		}

		/// <summary>
		/// Writes nothing.
		/// </summary>
		/// <param name="message">The message.</param>
		public override void Write(string message)
		{
		}
		#endregion
	}

	#region UnitNullLogger
	public sealed class UnitNullLogger : ClassUnit
	{
		private UnitNullLogger() : base(typeof(NullLogger), UnitLogging._) { }
		public static readonly UnitNullLogger _ = new UnitNullLogger();
		public static UnitNullLogger Instance => _;
	}
	#endregion
}
