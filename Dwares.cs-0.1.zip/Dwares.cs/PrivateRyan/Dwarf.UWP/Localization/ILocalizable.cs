﻿using System;


namespace Dwarf.Localization
{
	public interface ILocalizable
	{
		void Localize();
	}
}
