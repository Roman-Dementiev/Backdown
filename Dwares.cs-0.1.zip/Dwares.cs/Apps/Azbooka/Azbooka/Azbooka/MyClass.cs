﻿using System;

namespace Azbooka
{
	public class MyClass
	{
		public MyClass ()
		{
		}
	}
}

