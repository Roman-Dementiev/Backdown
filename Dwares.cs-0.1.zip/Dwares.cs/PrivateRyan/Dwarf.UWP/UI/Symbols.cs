﻿using System;
using Windows.UI.Xaml.Controls;


namespace Dwarf.UI
{
	public static class Symbols
	{
		public static bool IsSymbolChar(this char ch) => (ch >= '\uE100') && (ch <= '\uE295');
		public static bool IsSymbolChar(char? ch) => ch == null ? false : ((char)ch).IsSymbolChar();

		public static Symbol? ToSymbol(this char ch) => IsSymbolChar(ch) ? (Symbol)ch : (Symbol?)null;
		public static Symbol? ToSymbol(char? ch) => ch?.ToSymbol();

		public static char ToChar(this Symbol symbol) => (char)symbol;
		public static char? ToChar(Symbol? symbol) => symbol?.ToChar();
	}
}
