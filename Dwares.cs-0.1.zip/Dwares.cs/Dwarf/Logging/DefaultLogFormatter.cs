﻿using System;

namespace Dwarf.Logging
{
	/// <summary>
	/// Class DefaultLogFormatter
	/// </summary>
	public class DefaultLogFormatter : BaseLogFormatter
	{
		#region Constructor
		/// <summary>
		/// Initializes a new instance of the <see cref="DefaultLogFormatter"/> class.
		/// </summary>
		/// <param name="messageOnly">if set to <c>true</c> exclude unit name from message.</param>
		public DefaultLogFormatter(bool messageOnly = false)
		{
			MessageOnly = messageOnly;
		}
		#endregion

		#region Properties		
		/// <summary>
		/// Gets or sets a value indicating whether [message only].
		/// </summary>
		/// <value>
		///   if set to <c>true</c> the formatter excludes unit name from message.
		/// </value>
		public bool MessageOnly { get; set; }
		#endregion

		#region Methods
		/// <summary>
		/// Formats the message.
		/// </summary>
		/// <param name="level">The level.</param>
		/// <param name="source">The source.</param>
		/// <param name="message">The message.</param>
		/// <returns></returns>
		public override string Format(LogLevel level, string source, string message)
		{
			String msg;
			if (source == null || MessageOnly) {
				msg = String.Format("{0}", message);
			} else {
				msg = String.Format("[{0}]: {1}", source, message);
			}
			if (IndentLevel > 0) {
				String fmt = String.Format("{{0,{0}}}", IndentLevel*IndentSize);
				msg = String.Format(fmt, msg);
			}
			return msg;
		}
		#endregion

	}

	#region UnitDefaultLogFormatter
	#pragma warning disable RCS1060, RCS1023
	public sealed class UnitDefaultLogFormatter : ClassUnit
	{
		private UnitDefaultLogFormatter() : base(typeof(DefaultLogFormatter),UnitLogging._) {}
		public static readonly UnitDefaultLogFormatter _ = new UnitDefaultLogFormatter();
		public static UnitDefaultLogFormatter Instance => _;
	}
	#endregion
}
