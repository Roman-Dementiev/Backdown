﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Native
{
	#region UnitNative
	public sealed class UnitNative : NamespaceUnit
	{
		private UnitNative() : base("Native", UnitDwarf._) { }
		public static readonly UnitNative _ = new UnitNative();
		public static UnitNative Instance => _;
	}
	#endregion
}
