﻿using System;
using System.IO;
using System.Text;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Utility
{
	/// <summary>
	/// Utility class Strings
	/// </summary>
	public static class Strings
	{
		public static bool IsPrintable(this string str)
		{
			for (int i = 0; i < str.Length; i++) {
				if (!str[i].IsPrintable()) {
					return false;
				}
			}
			return true;
		}

		public static bool IsLowerCase(this string str)
		{
			for (int i = 0; i < str.Length; i++) {
				if (!Char.IsLower(str[i])) {
					return false;
				}
			}
			return true;
		}

		public static bool IsUpperCase(this string str)
		{
			for (int i = 0; i < str.Length; i++) {
				if (!Char.IsUpper(str[i])) {
					return false;
				}
			}
			return true;
		}

		public static string ToLowerCase(this string str)
		{
			if (str.IsLowerCase()) {
				return str;
			} else {
				return str.ToLower();
			}
		}

		public static string ToUpperCase(this string str)
		{
			if (str.IsUpperCase()) {
				return str;
			} else {
				return str.ToUpper();
			}
		}

		public static string ToPrintable(this string str, Encoding<char> encoding = null)
		{
			if (str.IsPrintable()) {
				return str;
			} else {
				if (encoding == null) {
					encoding = Chars.CEscapeEncoding;
				}
				StringBuilder sb = new StringBuilder();
				for (int i = 0; i < str.Length; i++) {
					if (str[i].IsPrintable()) {
						sb.Append(str[i]);
					} else {
						sb.Append(encoding(str[i]));
					}
				}
				return sb.ToString();
			}
		}

		public static string Encode(this string str, Encoding<char> encoding)
		{
			Debug.Assert(encoding != null);

			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < str.Length; i++) {
				sb.Append(encoding(str[i]));
			}
			return sb.ToString();
		}

		public static string Escape(this string str) => Encode(str, Chars.CEscapeEncoding);
		public static string ToHtml(this string str) => Encode(str, Chars.HtmlEncoding);

		public static string ReadCString(this BinaryReader reader)
		{
			StringBuilder sb = new StringBuilder();
			for (;;) {
				char ch = reader.ReadChar();
				if (ch == 0)
					break;
				sb.Append(ch);
			}

			return sb.ToString();
		}

	}

	#region UnitStrings	
	public sealed class UnitStrings : UtilityUnit
	{
		private UnitStrings() : base(typeof(Strings), UnitUtility._) { }
		public static readonly UnitStrings _ = new UnitStrings();
		public static UnitStrings Instance => _;
	}
	#endregion
}
