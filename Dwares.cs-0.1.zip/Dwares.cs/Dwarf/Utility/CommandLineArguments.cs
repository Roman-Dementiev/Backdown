﻿using System;
using System.Collections.Generic;
using System.Reflection;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Utility
{
	public partial class CommandLine
	{
		public class Element : IElement
		{
			#region Constructors
			protected Element(string name, string description, string note, bool required)
			{
				Name = name;
				Text = null;
				Description = description;
				Note = note;
				IsRequired = required;
				IsPresent = false;
			}
			#endregion

			#region Properties
			public string Name { get; set; }
			public string Text { get; set; }
			public string Description { get; set; }
			public string Note { get; set; }
			public bool IsRequired { get; set; }
			public bool IsPresent { get; set; }
			#endregion

		}

		public class Argument<TValue> : Element, IArgument where TValue : IConvertible
		{
			public delegate void Setter(TValue value);

			#region Fields
			private TValue value = default(TValue);
			private Setter setter = null;
			private object target = null;
			private MethodInfo setMethod = null;
			#endregion

			#region Constructors
			protected Argument(string name, string description, string note, bool required) :
				base(name, description, note, required)
			{
			}

			public Argument(string name, string description, string note, bool required, TValue defaultValue, Setter setter) :
				base(name, description, note, required)
			{
				value = defaultValue;
				this.setter = setter;
			}

			public Argument(string name, string description, string note, bool required, object target, PropertyInfo propertyInfo) :
				base(name, description, note, required)
			{
				InitForProperty(target, propertyInfo);
			}

			public Argument(string name, string description, string note, bool required, object target, string property) :
				base(name, description, note, required)
			{
				InitForProperty(target, property);
			}

			protected void InitForProperty(object target, string property)
			{
				if (target == null) {
					throw new ArgumentNullException(nameof(target));
				}
				if (String.IsNullOrEmpty(property)) {
					throw new ArgumentNullException(nameof(property));
				}

				PropertyInfo propertyInfo = Reflection.GetProperty(target, property, true);
				InitForProperty(target, propertyInfo);
			}

			protected void InitForProperty(object target, PropertyInfo propertyInfo)
			{
				if (target == null) {
					throw new ArgumentNullException(nameof(target));
				}
				if (propertyInfo == null) {
					throw new ArgumentNullException(nameof(propertyInfo));
				}
				if (propertyInfo.PropertyType != typeof(TValue)) {
					throw new ArgumentException("Property has different type", propertyInfo.Name);
				}

				MethodInfo getMethod = propertyInfo.GetMethod;
				MethodInfo setMethod = propertyInfo.SetMethod;
				if (setMethod == null) {
					throw new ArgumentException("Property is read-only", propertyInfo.Name);
				}
				if (getMethod != null) {
					value = (TValue)Convert.ChangeType(getMethod.Invoke(target, null), typeof(TValue));
					IsPresent = false;
				}

				this.setter = SetProperty;
				this.target = target;
				this.setMethod = setMethod;
			}

			private void SetProperty(TValue value)
			{
				setMethod.Invoke(target, new object[1] { value });
			}
			#endregion

			#region Properties
			public TValue Value {
				get {
					return value;
				}
				set {
					this.value = value;
					if (setter != null) {
						setter(value);
					}
					IsPresent = true;
				}
			}
			#endregion

			#region Methods
			public virtual object Parse(string text)
			{
				try {
					Value = (TValue)Convert.ChangeType(text, typeof(TValue));
				} catch {
					if (String.IsNullOrEmpty(text)) {
						Value = default(TValue);
					} else {
						throw;
					}
				}
				return Value;
			}

			public object GetValue()
			{
				return value;
			}
			#endregion
		}

		public class ArgList : Argument<string>, IArgument, IArgumentList
		{
			#region Fields
			private List<string> list = null;
			#endregion

			#region Constructors
			public ArgList(string name, string description, string note, bool required) :
				base(name, description, note, required)
			{
				list = new List<string>();
			}

			public ArgList(string name, string description, string note, bool required, object target, PropertyInfo propertyInfo) :
				base(name, description, note, required)
			{
				InitForProperty(target, propertyInfo);
			}

			public ArgList(string name, string description, string note, bool required, object target, string property) :
				base(name, description, note, required)
			{
				InitForProperty(target, property);
			}

			protected new void InitForProperty(object target, string property)
			{
				if (target == null) {
					throw new ArgumentNullException(nameof(target));
				}
				if (String.IsNullOrEmpty(property)) {
					throw new ArgumentNullException(nameof(property));
				}

				PropertyInfo propertyInfo = Reflection.GetProperty(target, property, true);
				InitForProperty(target, propertyInfo);
			}

			protected new void InitForProperty(object target, PropertyInfo propertyInfo)
			{
				if (target == null) {
					throw new ArgumentNullException(nameof(target));
				}
				if (propertyInfo == null) {
					throw new ArgumentNullException(nameof(propertyInfo));
				}

				if (propertyInfo.PropertyType != typeof(List<string>)) {
					throw new ArgumentException(Messages.ArgumentListInvalidType, propertyInfo.Name);
				}

				list = (List<string>)propertyInfo.GetMethod.Invoke(target, null);
			}
			#endregion


			public new object GetValue()
			{
				return list;
			}

			public void Add(string arg)
			{
				list.Add(arg);
			}

			public int Count {
				get {
					return list.Count;
				}
			}

			public string this[int index] {
				get {
					return list[index];
				}
			}

			public new object Parse(string text)
			{
				list.Add(text);
				return text;
			}
		}
	}
}
