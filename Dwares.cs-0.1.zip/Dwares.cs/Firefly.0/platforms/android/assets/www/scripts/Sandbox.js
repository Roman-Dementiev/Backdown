var Sandbox;
(function (Sandbox) {
    ;
    function stringOrFunc(source, sf, useToString) {
        if (!sf) {
            return useToString ? source.toString() : "";
        }
        if (typeof sf === 'string') {
            return sf;
        }
        else {
            return sf(source);
        }
    }
    function toText(source, items, args) {
        if (!args)
            args = {};
        var str = "";
        str += stringOrFunc(source, args.textPrefix);
        if (items) {
            for (var i = 0; i < items.length; i++) {
                str += stringOrFunc(source, args.textBreaks);
                var item = items[i];
                str += stringOrFunc(item, args.itemPrefix);
                str += stringOrFunc(item, args.itemString, true);
                str += stringOrFunc(item, args.itemSuffix);
            }
        }
        if (args.textSuffix) {
            str += stringOrFunc(source, args.textSuffix);
        }
        return str;
    }
    Sandbox.toText = toText;
})(Sandbox || (Sandbox = {}));
;
//# sourceMappingURL=Sandbox.js.map