﻿using System;
using Dwarf;


namespace Azbooka
{
	struct LanguageRef
	{
		Ref<Language> @ref;
		public string Tag { 
			get => tag;
			set {
				if (value != tag) {
					tag = value;
					@ref.Value = null;
				}
			}
		}
		string tag;

		public Language Value {
			get {
				if (String.IsNullOrEmpty(this.tag))
					return null;

				string tag = this.tag;
				return @ref.EnsureInitialized(() => Languages.GetOrAdd(tag), Abc.RefLock);
			}
			set {
				if (value != @ref.Value) {
					tag = value?.Tag;
					@ref.Value = value;
				}
			}
		}
	}
}
