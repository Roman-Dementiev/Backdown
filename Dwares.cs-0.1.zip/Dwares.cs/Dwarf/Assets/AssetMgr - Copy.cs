﻿using System;
using Dwarf.Utility;
using Dwarf.Assets.Generic;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Assets
{
	/// <summary>
	/// Class AssetMgr
	/// </summary>
	public class AssetMgr : IDisposable, IAssets
	{
		private static AssetMgr defaultMgr = new AssetMgr();
		private static AssetMgr currentMgr = defaultMgr;

		#region Fields
		private AssetMgr previous = null;
		private CommonAssets<object> commonAssets = null;
		private CulturalAssets<object> culturalAssets = null;
		#endregion

		#region Properties
		public static object Culture { get; set; }
		public static AssetMgr Default => defaultMgr;
		public static AssetMgr Current => currentMgr;

		public object this[string key, Type type, object culture = null] {
			get { return GetAsset(key, type, culture); }
			set { AddAsset(key, value, culture); }
		}
		#endregion

		#region Constructors
		public AssetMgr(bool makeCurrent=false)
		{
			if (makeCurrent) {
				Push(this);
			}
		}
		#endregion

		#region Methods
		public virtual void Dispose()
		{
			Remove(this);
		}

		public virtual bool HasAsset(string key, object culture = null)
		{
			return GetAsset(key, culture) != null;
		}

		public virtual object GetAsset(string key, object culture = null)
		{
			object asset = null;

			if (culture == null) {
				culture = Culture;
			}
			if (culture != null && culturalAssets != null) {
				asset = culturalAssets.GetAsset(key, culture);
			}
			if (asset == null && commonAssets != null) {
				asset = commonAssets.GetAsset(key);
			}

			return asset;
		}

		public virtual object GetAsset(string key, Type type, object culture = null)
		{
			object asset = null;

			if (culture == null) {
				culture = Culture;
			}
			if (culture != null && culturalAssets != null) {
				asset = culturalAssets.GetAsset(key, type, culture);
			}
			if (asset == null && commonAssets != null) {
				asset = commonAssets.GetAsset(key, type);
			}

			return asset;
		}

		public void AddString(string key, string value)
		{
			AddAsset(key, value ?? String.Empty);
		}

		public virtual void AddAsset(string key, object asset, object culture = null)
		{
			if (culture == null) {
				culture = Culture;
			}
			if (culture != null) {
				if (culturalAssets == null) {
					culturalAssets = new CulturalAssets<object>();
				}
				culturalAssets.AddAsset(key, asset, culture);
			} else {
				if (commonAssets == null) {
					commonAssets = new CommonAssets<object>();
				}
				commonAssets.AddAsset(key, asset, culture);
			}
		}

		#endregion

		#region Static Methods
		public static void Push(AssetMgr mgr)
		{
			if (mgr == defaultMgr)
				return;

			mgr.previous = currentMgr;
			currentMgr = mgr;
		}

		public static AssetMgr Pop()
		{
			AssetMgr mgr = currentMgr;
			if (mgr == defaultMgr)
				return null;

			currentMgr = mgr.previous ?? defaultMgr;
			mgr.previous = null;
			return mgr;
		}

		public static void Remove(AssetMgr mgr)
		{
			if (mgr == null || mgr == defaultMgr)
				return;

			if (mgr == currentMgr) {
				currentMgr = mgr.previous;
			} else {
				for (AssetMgr prev, next = currentMgr; ; next = prev) {
					prev = next.previous;
					if (prev == null)
						break;
					if (prev == mgr) {
						next.previous = mgr.previous;
						break;
					}
				}
			}
			mgr.previous = null;
		}

		public static TAsset GetAsset<TAsset>(string key) where TAsset : class
		{
			for (AssetMgr mgr = currentMgr; mgr != null; mgr = mgr.previous) {
				object asset = mgr.GetAsset(key, typeof(TAsset), Culture);
				if (asset != null) {
					return asset as TAsset;
				}
			}
			return null;
		}

		public static string GetString(string key, bool useKeyAsDefault=true)
		{
			string value = GetAsset<string>(key);
			return value ?? (useKeyAsDefault ? key : null);
		}

		public static byte[] GetBinary(string key)
		{
			return GetAsset<byte[]>(key);
		}

		public static void SetDefaultString(string key, string value)
		{
			defaultMgr.AddString(key, value);
		}

		public static void SetDefaultStrings(params string[] keysAndValues)
		{
			if (keysAndValues != null) {
				for (int i = 1; i < keysAndValues.Length; i += 2) {
					defaultMgr.AddString(keysAndValues[i-1], keysAndValues[i]);
				}
			}
		}
		#endregion
	}

	#region UnitAssetMgr
	public sealed class UnitAssetMgr : ClassUnit
	{
		private UnitAssetMgr() : base(typeof(AssetMgr), UnitAssets._) { }
		public static readonly UnitAssetMgr _ = new UnitAssetMgr();
		public static UnitAssetMgr Instance => _;
	}
	#endregion
}
