﻿using System;
using System.Threading.Tasks;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;


namespace Dwarf.Platform
{
	public interface IApp
	{
		Task OnStartup(LaunchActivatedEventArgs e);
		Task OnResuming(LaunchActivatedEventArgs e);
		Task OnSuspending(SuspendingEventArgs e);
	}
}
