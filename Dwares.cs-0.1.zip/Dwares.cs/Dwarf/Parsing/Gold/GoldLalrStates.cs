﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing.Gold
{
	/// <summary>
	/// Class GoldLalrStates
	/// </summary>
	public class GoldLalrStates : ILalrStates
	{
		#region Fields
		Grammar.LalrState[] states;
		#endregion

		#region Constructors
		public GoldLalrStates(Grammar grammar)
		{
			states = grammar.LalrStates;
		}
		#endregion

		#region Properties
		public Grammar.LalrState[] GrammarLalrStates => states;
		public int StateCount => states.Length;
		public uint ShiftAction  => 1;
		public uint ReduceAction => 2;
		public uint GotoAction   => 3;
		public uint AcceptAction => 4;
		#endregion

		#region Methods
		public int ActionCount(uint state)
		{
			Debug.Assert(state < states.Length);
			return states[state].Actions.Length;
		}

		public int ActionSymbol(uint state, uint action)
		{
			Debug.Assert(state < states.Length);
			Grammar.LalrState larlState = states[state];
			Debug.Assert(action < larlState.Actions.Length);
			Grammar.LalrState.Action lalrAction = larlState.Actions[action];
			return lalrAction.symbol;
		}

		public uint ActionType(uint state, uint action)
		{
			Debug.Assert(state < states.Length);
			Grammar.LalrState larlState = states[state];
			Debug.Assert(action < larlState.Actions.Length);
			Grammar.LalrState.Action lalrAction = larlState.Actions[action];
			return lalrAction.action;
		}

		public uint ActionTarget(uint state, uint action)
		{
			Debug.Assert(state < states.Length);
			Grammar.LalrState larlState = states[state];
			Debug.Assert(action < larlState.Actions.Length);
			Grammar.LalrState.Action lalrAction = larlState.Actions[action];
			return lalrAction.target;
		}
		#endregion

	}

	#region UnitGoldLalrStates
	public sealed class UnitGoldLalrStates : ClassUnit
	{
		private UnitGoldLalrStates() : base(typeof(GoldLalrStates), UnitGold._) { }
		public static readonly UnitGoldLalrStates _ = new UnitGoldLalrStates();
		public static UnitGoldLalrStates Instance => _;
	}
	#endregion
}
