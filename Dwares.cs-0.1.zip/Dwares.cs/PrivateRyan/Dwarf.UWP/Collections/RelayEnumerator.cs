﻿using System;
using System.Collections;
using System.Collections.Generic;



namespace Dwarf.Collections
{
	public struct RelayEnumerator<TItem, TSourceItem> : IEnumerator<TItem> where TSourceItem : TItem
	{
		IEnumerator<TSourceItem> enumerator;

		public RelayEnumerator(IEnumerator<TSourceItem> enumerator)
		{
			this.enumerator = enumerator;
		}

		public RelayEnumerator(IEnumerable<TSourceItem> enumerable)
		{
			enumerator = enumerable.GetEnumerator();
		}

		public void Dispose()
		{
			if (enumerator != null) {
				enumerator.Dispose();
				enumerator = null;
			}
		}

		public TItem Current => enumerator.Current;
		object IEnumerator.Current => enumerator.Current;
		public bool MoveNext() => enumerator.MoveNext();
		public void Reset() => enumerator.Reset();
	}
}
