﻿using System;
using System.IO;
using System.Text;
using Dwarf.Config;
using Dwarf.Assets;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Utility
{
	[Flags]
	public enum EOLMode
	{
		Default = 0,
		LF = 1,
		CRLF = 2,
		Any = LF|CRLF
	}

	public class TextPosition
	{
		public static readonly TextPosition None = new TextPosition(0, 0, 0);

		public TextPosition(uint position, uint lineNo, uint linePos)
		{
			Position = position;
			LineNo = lineNo;
			LinePos = linePos;
		}

		public static implicit operator uint(TextPosition pos) {
			return pos.Position;
		}
		public uint Position { get; }
		public uint LineNo { get; }
		public uint LinePos { get; }
	}

	/// <summary>
	/// Class LineReader
	/// </summary>
	public class TextSource
	{
		public const char EOF = (char)0;
		public static readonly string LF = "\n";
		public static readonly string CRLF = "\r\n";

		#region Fields
		public TextReader Reader { get; }
		public EOLMode EOLMode { get; }
		public string NewLine { get; }
		public uint Position { get; protected set; }
		public uint LineNo { get; protected set; }
		public uint LinePos { get; protected set; }
		private bool hasCR;
		#endregion


		#region Constructors
		public TextSource(TextReader reader, EOLMode eolMode = EOLMode.Default)
		{
			Reader = reader;

			if (eolMode == EOLMode.Default) {
				NewLine = System.Environment.NewLine;
				if (NewLine == LF) {
					EOLMode = EOLMode.LF;
				} else if (NewLine == "\r\n") {
					EOLMode = EOLMode.CRLF;
				} else {
					Log.Warning(UnitTextSource._, Messages.UnknownEnvironmentNewLine, NewLine.ToPrintable());
					EOLMode = EOLMode.Any;
				}
			} else {
				EOLMode = eolMode;
				if ((eolMode & EOLMode.CRLF) != 0) {
					NewLine = CRLF;
				} else if ((eolMode & EOLMode.LF) != 0) {
					NewLine = LF;
				} else {
					Log.Warning(UnitTextSource._, Messages.UnknownEndOfLineMode, eolMode.ToString());
					NewLine = String.Empty;
				}
			}

			Position = LineNo = LinePos = 1;
			hasCR = false;
		}
		#endregion

		#region Properties
		#endregion

		#region Methods
		public TextPosition GetPosition()
		{
			return new TextPosition(Position, LineNo, LinePos);
		}

		public char ReadChar()
		{
			int ch = Reader.Read();
			if (ch < 0) {
				return EOF;
			}

			Position++;
			LinePos++;

			switch (ch)
			{
			case '\n':
				if ((EOLMode & EOLMode.LF) != 0 || hasCR) {
					LineNo++;
					LinePos = 1;
					hasCR = false;
				}
				break;

			case '\r':
				if ((EOLMode & EOLMode.CRLF) != 0) {
					ch = Reader.Peek();
					if (ch == '\n') {
						hasCR = true;
						break;
					}
				}
				break;

			default:
				hasCR = false;
				break;
			}

			return (char)ch;
		}

		public string ReadLine()
		{
			StringBuilder sb = new StringBuilder();
			uint lineNo = LineNo;
			do {
				sb.Append(ReadChar());
			}
			while (LineNo == lineNo);

			return sb.ToString();
		}
		#endregion

		public static class Messages
		{
			public static readonly string UnknownEnvironmentNewLine = nameof(UnknownEnvironmentNewLine);
			public static readonly string UnknownEndOfLineMode = nameof(UnknownEndOfLineMode);
		}
	}

	#region UnitTextSource
	public sealed class UnitTextSource : ClassUnit
	{
		private UnitTextSource() : base(typeof(TextSource), UnitUtility._)
		{
#if INIT_DEFAULT_MESSAGES
			AssetMgr.SetDefaultStrings(
				TextSource.Messages.UnknownEnvironmentNewLine, "Unknown Environment NewLine '{0}'",  // newline
				TextSource.Messages.UnknownEndOfLineMode, "Unknown End Of Line mode'{0}"             // EOLMode
			);
#endif
		}
		public static readonly UnitTextSource _ = new UnitTextSource();
		public static UnitTextSource Instance => _;
	}
	#endregion
}
