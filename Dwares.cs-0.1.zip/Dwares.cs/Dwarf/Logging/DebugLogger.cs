﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Logging
{
	/// <summary>
	/// Class DebugLogger
	/// </summary>
	public class DebugLogger : BaseLogger
	{
		#region Methods
		/// <summary>
		/// Writes message to the trace listeners.
		/// </summary>
		/// <param name="message">The message.</param>
		public override void Write(string message)
		{
			System.Diagnostics.Debug.WriteLine(message);
		}
		#endregion

	}

	#region UnitDebugLogger
	public sealed class UnitDebugLogger : ClassUnit
	{
		private UnitDebugLogger() : base(typeof(DebugLogger), UnitLogging._) { }
		public static readonly UnitDebugLogger _ = new UnitDebugLogger();
		public static UnitDebugLogger Instance => _;
	}
	#endregion
}
