﻿using System;
using System.Diagnostics;
using System.IO;
using Dwarf.Config;
using Dwarf.Assets;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Utility
{
	/// <summary>
	/// Utility class Sys
	/// </summary>
	public static class Sys
	{
		#region Properties
		public static Process CurrentProcess {
			get { return Process.GetCurrentProcess(); }
		}

		public static string ProcessName {
			get { return CurrentProcess.ProcessName; }
		}

		public static string AppPath {
			get { return CurrentProcess.MainModule.FileName; }
		}

		public static string AppName {
			get { return Path.GetFileNameWithoutExtension(AppPath); }
		}

		public static string AppDir {
			get { return Path.GetDirectoryName(AppPath); }
		}

		public static string CurrentDir {
			get { return Environment.CurrentDirectory; }
		}
		#endregion

		public static string SystemDir {
			get { return Environment.GetFolderPath(Environment.SpecialFolder.System); }
		}

		#region Methods
		public static void Exit(int exitCode = 0)
		{
			Environment.Exit(exitCode);
		}

		public static void Abort(string message, int exitCode =-1)
		{
			Console.Out.WriteLine(message);
			Exit(exitCode);
		}

		public static int ExecuteFile(string fileName, string verb = null, string workingDir = null, bool hidden = true)
		{
			if (fileName == null) {
				throw new ArgumentNullException(nameof(fileName));
			}

			int exitCode = 0;
			try {
				exitCode = Execute(fileName, null, workingDir, verb, hidden, true, null, null, false);
			}
			catch (Exception exc) {
				new ExecuteException(UnitSys._, exc, fileName).Throw();
			}

			return exitCode;
		}

		public static int ExecuteCommand(string command, string workingDir = null, bool hidden = true,
										TextWriter output = null, TextWriter error = null, bool addEOL = true)
		{
			if (command == null) {
				throw new ArgumentNullException(nameof(command));
			}

			string program = Path.Combine(SystemDir, "cmd.exe");
			string arguments = "/c " + command;

			int exitCode = 0;
			try {
				exitCode = Execute(program, arguments, workingDir, null, hidden, false, output, error, addEOL);
			}
			catch (Exception exc) {
				new ExecuteException(UnitSys._, exc, command).Throw();
			}

			return exitCode;
		}

		public static int ConsoleExecute(string fileName, string arguments, string workingDir = null, string verb = null)
		{
			return Execute(fileName, arguments, workingDir, verb, true, verb != null, Console.Out, Console.Error, true);
		}

		public static int Execute(string program, string arguments, string workingDir = null, bool hidden = true, 
								TextWriter output = null, TextWriter error = null, bool addEOL = true)
		{
			int exitCode = 0;
			try {
				exitCode = Execute(program, arguments, workingDir, null, hidden, false, output, error, addEOL);
			}
			catch (Exception exc) {
				new ExecuteException(UnitSys._, exc, program + " " + arguments).Throw();
			}

			return exitCode;
		}

		public static int Execute(string fileName, string arguments, string workingDir, string verb, bool hidden, 
									bool shell, TextWriter output, TextWriter error, bool addEOL)
		{
			using (Process process = new Process()) {

				process.StartInfo.FileName = fileName;

				if (!String.IsNullOrEmpty(arguments)) {
					process.StartInfo.Arguments = arguments;
				}
				if (!String.IsNullOrEmpty(workingDir)) {
					process.StartInfo.WorkingDirectory = workingDir;
				}
				if (!String.IsNullOrEmpty(verb)) {
					process.StartInfo.Verb = verb;
				}
				//if (hidden) {
				//	process.StartInfo.CreateNoWindow = true;
				//	process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
				//}
				process.StartInfo.UseShellExecute = shell;

				if (output != null) {
					process.StartInfo.RedirectStandardOutput = true;
					process.OutputDataReceived += (sender, arg) => RedirectOutput(sender, arg, output, addEOL);
				}
				if (error != null) {
					process.StartInfo.RedirectStandardError = true;
					process.ErrorDataReceived += (sender, arg) => RedirectOutput(sender, arg, error, addEOL);
				}

				process.Start();

				if (output != null) {
					process.BeginOutputReadLine();
				}
				if (error != null) {
					process.BeginErrorReadLine();
				}

				process.WaitForExit();

				if (output != null) {
					output.Flush();
				}
				if (error != null) {
					error.Flush();
				}

				return process.ExitCode;
			}
		}

		static void RedirectOutput(object sender, DataReceivedEventArgs e, TextWriter writer, bool addEOL)
		{
			if (e.Data != null) {
				if (addEOL) {
					writer.WriteLine(e.Data);
				} else {
					writer.Write(e.Data);
				}
			}
		}

		#endregion

		public class ExecuteException : DwarfException
		{
			public ExecuteException(Dwarf.Unit unit, string message, bool useAssets, Exception innerExc = null) :
				base(unit, message, useAssets, innerExc)
			{ }

			public ExecuteException(Dwarf.Unit unit, Exception innerExc, string command) :
				base(unit, innerExc, true, Messages.ExecuteException, command)
			{
			}
		}

		public class Messages
		{
			public const string ExecuteException = nameof(ExecuteException); // command
		}
	}

	#region UnitSys
	public sealed class UnitSys : ClassUnit
	{
		private UnitSys() : base(typeof(Sys), UnitUtility._)
		{
#if INIT_DEFAULT_MESSAGES
			AssetMgr.SetDefaultString(Sys.Messages.ExecuteException, "Failed to execute '{%0}'"); // command
#endif
		}
		public static readonly UnitSys _ = new UnitSys();
		public static UnitSys Instance => _;
	}
	#endregion
}
