﻿using System;
using System.IO;
using Dwarf.Utility;

namespace Dwarf.Parsing
{
	/// <summary>
	/// Interface IParser
	/// </summary>
	public interface IParser : ITextProcessor<object>
	{
		#region Properties
		/// <summary>
		/// Gets or sets a value indicating whether input was parsed successfully.
		/// </summary>
		/// <value>
		///   <c>true</c> if input was parsed successfully; otherwise, <c>false</c>.
		/// </value>
		bool Accepted { get; }
		#endregion

		#region Methods
		/// <summary>
		/// Parses the specified stream.
		/// </summary>
		/// <param name="stream">The stream.</param>
		/// <returns>The parsed object</returns>
		object Parse(Stream stream);

		/// <summary>
		/// Parses input from the specified reader.
		/// </summary>
		/// <param name="reader">The reader.</param>
		/// <returns>The parsed object.</returns>
		object Parse(TextReader reader);

		/// <summary>
		/// Parses the specified text.
		/// </summary>
		/// <param name="text">The text.</param>
		/// <returns>The parsed object.</returns>
		object ParseText(string text);

		/// <summary>
		/// Parses the specified buffer.
		/// </summary>
		/// <param name="buffer">The buffer.</param>
		/// <returns>The parsed object.</returns>
		object ParseData(byte[] buffer);

		/// <summary>
		/// Parses the file with the specified path.
		/// </summary>
		/// <param name="path">The path.</param>
		/// <returns>The parsed object.</returns>
		object ParseFile(string path);

		/// <summary>
		/// Validates the input from the specified stream.
		/// </summary>
		/// <param name="stream">The stream.</param>
		/// <returns><c>true</c> if input is valid; otherwise <c>false</c></returns>
		bool Validate(Stream stream);

		/// <summary>
		/// Validates input from the specified reader.
		/// </summary>
		/// <param name="reader">The reader.</param>
		/// <returns><c>true</c> if input is valid; otherwise <c>false</c></returns>
		bool Validate(TextReader reader);

		/// <summary>
		/// Validates the specified text.
		/// </summary>
		/// <param name="text">The text.</param>
		/// <returns><c>true</c> if input is valid; otherwise <c>false</c></returns>
		bool Validate(string text);

		/// <summary>
		/// Validates the specified buffer.
		/// </summary>
		/// <param name="buffer">The buffer.</param>
		/// <returns><c>true</c> if input is valid; otherwise <c>false</c></returns>
		bool Validate(byte[] buffer);

		/// <summary>
		/// Validates the file with the specified path.
		/// </summary>
		/// <param name="path">The path.</param>
		/// <returns><c>true</c> if input is valid; otherwise <c>false</c></returns>
		bool ValidateFile(string path);

		#endregion
	}

	#region UnitIParser
	#pragma warning disable RCS1060, RCS1023
	public sealed class UnitIParser : InterfaceUnit
	{
		private UnitIParser() : base(typeof(IParser), UnitParsing._) { }
		public static readonly UnitIParser _ = new UnitIParser();
		public static UnitIParser Instance => _;
	}
	#endregion
}
