﻿using System;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Shapes;
using Windows.Foundation;
using Dwarf.Platform;

namespace Dwarf.UI
{
	[Flags]
	public enum ShapeStyle
	{
		None,
		//Circle,
		//Square,
		Ellipse,
		Rectangle,
		GeometryMask = 0x0F,

		Fill = 0x10,
		Stroke = 0x20,
		Drawn = Fill|Stroke,

		FilledEllipse = Ellipse|Fill,
		StrokedEllipse = Ellipse|Stroke,
		DrawnEllipse = Ellipse|Fill|Stroke,

		FilledRectangle = Rectangle|Fill,
		StrokedRectangle = Rectangle|Stroke,
		DrawnRectangle = Rectangle|Fill|Stroke
	}

	public class IconButton : CommandButton
	{
		//protected StackPanel stackPanel;
		//protected FrameworkElement iconPanel;
		protected Shape shapeElement;
		protected TextBlock labelElement;
		protected FrameworkElement separator;

		public IconButton()
		{
			DefaultStyleKey = typeof(IconButton);
		}

		//public StackPanel StackPanel => stackPanel;
		//protected FrameworkElement IconPanel => iconPanel;
		public Shape ShapeElement => shapeElement;
		public TextBlock LabelElement => labelElement;

		public new string Label {
			get => base.Label;
			set {
				base.Label = value ?? String.Empty;
				SetLabelVisibility();
			}
		}

		public Color IconForegrounColor {
			get => UI.BrushColor(IconForeground);
			set => IconForeground = new SolidColorBrush(value);
		}

		public Color IconBackgrounColor {
			get => UI.BrushColor(IconBackground);
			set => IconBackground = new SolidColorBrush(value);
		}

		public Orientation Orientation {
			get => (Orientation)GetValue(OrientationProperty);
			set => SetValue(OrientationProperty, value);
		}
		public static readonly DependencyProperty OrientationProperty = UI.RegisterDependencyProperty<IconButton, Orientation>(nameof(Orientation), Orientation.Horizontal);


		public double ShapeWidth {
			get => (double)GetValue(ShapeWidthProperty);
			set => SetValue(ShapeWidthProperty, value);
		}
		public static readonly DependencyProperty ShapeWidthProperty = UI.RegisterDependencyProperty<IconButton, double>(nameof(ShapeWidth), 26);

		public double ShapeHeight {
			get => (double)GetValue(ShapeHeightProperty);
			set => SetValue(ShapeHeightProperty, value);
		}
		public static readonly DependencyProperty ShapeHeightProperty = UI.RegisterDependencyProperty<IconButton, double>(nameof(ShapeHeight), 26);

		public double ShapeOpacity {
			get => (double)GetValue(ShapeOpacityProperty);
			set => SetValue(ShapeOpacityProperty, value);
		}
		public static readonly DependencyProperty ShapeOpacityProperty = UI.RegisterDependencyProperty<IconButton, double>(nameof(ShapeOpacity), 1);

		public Thickness ShapeMargin {
			get => (Thickness)GetValue(ShapeMarginProperty);
			set => SetValue(ShapeMarginProperty, value);
		}
		public static readonly DependencyProperty ShapeMarginProperty = UI.RegisterDependencyProperty<IconButton, Thickness>(nameof(ShapeMargin), new Thickness(0));

		public Geometry ShapeGeometry {
			get => (Geometry)GetValue(ShapeGeometryProperty);
			set => SetValue(ShapeGeometryProperty, value);
		}
		public static readonly DependencyProperty ShapeGeometryProperty = UI.RegisterDependencyProperty<IconButton, Geometry>(nameof(ShapeGeometry));

		public double ShapeStrokeThickness {
			get => (double)GetValue(ShapeStrokeThicknessProperty);
			set => SetValue(ShapeStrokeThicknessProperty, value);
		}
		public static readonly DependencyProperty ShapeStrokeThicknessProperty = UI.RegisterDependencyProperty<IconButton, double>(nameof(ShapeStrokeThickness), 0);

		public ShapeStyle ShapeStyle {
			get => (ShapeStyle)GetValue(ShapeStyleProperty);
			set {
				SetValue(ShapeStyleProperty, value);
				if (shapeElement != null) {
					ApplyShapeStyle();
				}
			}
		}
		public static readonly DependencyProperty ShapeStyleProperty = UI.RegisterDependencyProperty<IconButton, ShapeStyle>(nameof(ShapeStyle));

		public Brush IconForeground {
			get => (Brush)GetValue(IconForegroundProperty);
			set => SetValue(IconForegroundProperty, value);
		}
		public static readonly DependencyProperty IconForegroundProperty = UI.RegisterDependencyProperty<IconButton, Brush>(nameof(IconForeground), UI.Brushes.Black);

		public Brush IconBackground {
			get => (Brush)GetValue(IconBackgroundProperty);
			set => SetValue(IconBackgroundProperty, value);
		}
		public static readonly DependencyProperty IconBackgroundProperty = UI.RegisterDependencyProperty<IconButton, Brush>(nameof(IconBackground), UI.Brushes.Transparent);

		public Thickness LabelMargin {
			get => (Thickness)GetValue(LabelMarginProperty);
			set => SetValue(LabelMarginProperty, value);
		}
		public static readonly DependencyProperty LabelMarginProperty = UI.RegisterDependencyProperty<IconButton, Thickness>(nameof(LabelMargin), new Thickness(0));


		public void SetLabelVisibility()
		{
			var visibility = String.IsNullOrEmpty(Label) ? Visibility.Collapsed : Visibility.Visible;
			if (labelElement != null) {
				labelElement.Visibility = visibility;
			}
			if (separator != null) {
				separator.Visibility = visibility;
			}
		}

		protected override void OnApplyTemplate()
		{
			base.OnApplyTemplate();
			
			//stackPanel = GetTemplateChild("StackPanel") as StackPanel;
			//iconPanel = GetTemplateChild("IconPanel") as FrameworkElement;
			shapeElement = GetTemplateChild("Shape") as Shape;
			labelElement = GetTemplateChild("Label") as TextBlock;
			separator = GetTemplateChild("Separator") as FrameworkElement;

			SetLabelVisibility();

			if (shapeElement != null) {
				ApplyShapeStyle();
			}
		}

		protected void ApplyShapeStyle()
		{
//			Path path = shapeElement as Path;

			if ((ShapeStyle & ShapeStyle.Fill) != 0) {
				shapeElement.Fill = IconBackground;
			} else {
				shapeElement.Fill = null;
			}

			if ((ShapeStyle & ShapeStyle.Stroke) != 0) {
				shapeElement.StrokeThickness = ShapeStrokeThickness;
			} else {
				shapeElement.StrokeThickness = 0;
			}

			if (shapeElement is Path)
			{
				Point center;
				//double radius;
				double fullStroke = ShapeStrokeThickness;
				double halfStroke = fullStroke / 2;

				switch (ShapeStyle & ShapeStyle.GeometryMask)
				{
				case ShapeStyle.None:
					ShapeGeometry = null;
					break;

				case ShapeStyle.Ellipse:
					center = new Point(ShapeWidth / 2, ShapeHeight / 2);
					halfStroke = ShapeStrokeThickness / 2;
					ShapeGeometry = new EllipseGeometry() { Center = center, RadiusX = center.X - halfStroke, RadiusY = center.Y - halfStroke };
					break;

				case ShapeStyle.Rectangle:
					center = new Point(ShapeWidth / 2, ShapeHeight / 2);
					ShapeGeometry = new RectangleGeometry() { Rect = new Rect(halfStroke, halfStroke, ShapeWidth - fullStroke, ShapeHeight - fullStroke) };
					break;

				//case ShapeStyle.Circle:
				//	center = new Point(ShapeWidth / 2, ShapeHeight / 2);
				//	radius = Math.Min(center.X, center.Y);
				//	ShapeGeometry = new EllipseGeometry() { Center = center, RadiusX = radius - halfStroke, RadiusY = radius - halfStroke };
				//	break;

				//case ShapeStyle.Square:
				//	Rect rect;
				//	double width = ShapeWidth - fullStroke;
				//	double height = ShapeHeight - fullStroke;
				//	if (width < height) {
				//		rect.X = halfStroke;
				//		rect.Y = (ShapeHeight - width) / 2;
				//		rect.Width = rect.Height = width;
				//	} else {
				//		rect.X = (ShapeWidth - height) / 2;
				//		rect.Y = halfStroke;
				//		rect.Width = rect.Height = height;
				//	}
				//	ShapeGeometry = new RectangleGeometry() { Rect = rect };
				//	break;
				}
			}
		}
	}
}
