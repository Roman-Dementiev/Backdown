﻿using System;
using Dwarf;
using Dwarf.ObjectModel;


namespace Azbooka
{
	public class Volume : Entity
	{
		public Volume(string uid) : base(uid) {}

		public string PrimaryLanguageTag {
			get => primaryLanguage.Tag;
			set => primaryLanguage.Tag = value;
		}
		public Language PrimaryLanguage {
			get => primaryLanguage.Value;
			set => primaryLanguage.Value = value;
		}
		LanguageRef primaryLanguage = new LanguageRef();

		public string SecondaryLanguageTag {
			get => primaryLanguage.Tag;
			set => primaryLanguage.Tag = value;
		}
		public Language SecondaryLanguage {
			get => secondaryLanguage.Value;
			set => secondaryLanguage.Value = value;
		}
		LanguageRef secondaryLanguage = new LanguageRef();
	}
}
