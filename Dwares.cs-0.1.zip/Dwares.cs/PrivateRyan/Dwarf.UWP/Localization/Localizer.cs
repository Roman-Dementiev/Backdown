﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Windows.UI.Xaml;
using Windows.UI.Core;
using Dwarf.Collections;
using Dwarf.UWP;
using Dwarf.Platform;
using Dwarf.Extensions;


namespace Dwarf.Localization
{
	public partial class Localizer
	{
		public delegate void LocalizationHandlerProc(object target, string uid);

		public static Localizer Instance = LazyInitializer.EnsureInitialized(ref instance, () => Initialize(Window.Current.Content));
		static Localizer instance = null;

		class HandlerEntry
		{
			public Type BaseType { get; set; }
			public String Property { get; set; }
			public LocalizationHandlerProc Handler { get; set; }
		}

		Dictionary<Type, HandlerEntry> handlers = new Dictionary<Type, HandlerEntry>();
		WeakCollection targets;
		ResourceMapListener listener;
		public string DefaultLocalizableProperty { get; set; } = nameof(Localizable);

		public static Localizer Initialize(UIElement ui)
		{
			if (instance != null)
				throw new Exception("Localizer already initialized");
			if (ui == null)
				throw new ArgumentNullException(nameof(ui));

			var localizer = new Localizer(ui.Dispatcher, true);
			localizer.AddUiHandlers();
			localizer.targets.Add(ui);

			return localizer;
		}

		public static void Localize(object target, string uid = null) => Instance.LocalizeObject(target, uid, null);

		Localizer(CoreDispatcher dispatcher, bool useUiHandlers)
		{
			handlers = new Dictionary<Type, HandlerEntry>();
			targets = new WeakCollection();
			listener = new ResourceMapListener("Language", LocalizeTargets, dispatcher, null);
			listener.Register();

			if (useUiHandlers) {
				AddUiHandlers();
			}
		}

		void LocalizeTargets(string resourceKey, string value)
		{
			foreach (var target in targets) {
				Localize(target);
			}
		}

		public static void AddTarget(object target, bool localize = true)
		{
			Instance.targets.Add(target);
			if (localize) {
				Localize(target);
			}
		}

		public static bool RemoveTarget(object target)
		{
			return Instance.targets.Remove(target);
		}

		public void AddHandler(Type type, string property)
		{
			var entry = new HandlerEntry() { BaseType = type, Property = property };
			handlers.Add(type, entry);
		}

		public void AddHandler(Type type, LocalizationHandlerProc handler)
		{
			var entry = new HandlerEntry() { BaseType = type, Handler = handler };
			handlers.Add(type, entry);
		}

		public void AddHandler(Type type, Type baseType)
		{
			var entry = handlers[baseType];
			handlers[type] = entry;
		}

		public void InvokeHandler(object target, string uid)
		{
			var entry = handlers.GetValue(target.GetType());
			if (entry != null) {
				entry.Handler?.Invoke(target, uid);
				if (entry.Property != null) {
					LocalizeProperty(target, entry.Property, uid);
				}
			}
		}

		void GetUidAndLocalizable(object target, ref string uid, ref string localizableProperty)
		{
			if (target is DependencyObject dob) {
				if (uid == null) {
					uid = Xaml.Localizer.GetUid(dob);
				}

				if (localizableProperty == null) {
					localizableProperty = Xaml.Localizer.GetLocalizable(dob);
				}
			}

			if (localizableProperty == null) {
				localizableProperty = DefaultLocalizableProperty;
			}
		}

		public void LocalizeObject(object target, string uid = null, string localizableProperty = null)
		{
			if (target == null)
				return;

			if (target is ILocalizable localizable) {
				localizable.Localize();
				return;
			}


			GetUidAndLocalizable(target, ref uid, ref localizableProperty);

			InvokeHandler(target, uid);

			if (localizableProperty != null) {
				LocalizeProperty(target, localizableProperty, uid);
			}

			if (target is IEnumerable enumerable) {
				foreach (var obj in enumerable) {
					LocalizeObject(obj, null, null);
				}
			}
		}

		public void LocalizeProperty(object target, string property, string uid)
		{
			if (target == null)
				return;

			var propertyInfo = Reflection.GetProperty(target, property);
			if (propertyInfo == null)
				return;

			var propertyType = Reflection.GetPropertyType(target, propertyInfo);
			if (propertyType == typeof(string)) {
				if (propertyInfo.CanWrite) {
					var value = Appx.GetString(uid);
					Reflection.SetPropertyValue(target, propertyInfo, value);
				}
			} else if (propertyInfo.CanRead) {
				var propertyValue = Reflection.GetPropertyValue(target, propertyInfo);
				Localize(propertyValue, uid);
			}
		}
	}
}
