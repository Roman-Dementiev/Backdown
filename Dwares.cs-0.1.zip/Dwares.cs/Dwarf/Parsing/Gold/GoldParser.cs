﻿using System;
using System.IO;
using System.Collections.Generic;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing.Gold
{
	/// <summary>
	/// Class Gold.Parser
	/// </summary>
	public class GoldParser : LALRParser
	{
		#region Constructors
		/// <summary>
		/// Initializes a new instance of the <see cref="GoldParser" /> class from grammar.
		/// </summary>
		/// <param name="grammar">The grammar.</param>
		/// <param name="factory">The token factory.</param>
		public GoldParser(Grammar grammar, ITokenFactory factory = null)
		{
			Init(grammar, factory);
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="GoldParser" /> class.
		/// Loads grammar from the file with specified path.
		/// </summary>
		/// <param name="egtPath">The EGT file path.</param>
		/// <param name="factory">The token factory.</param>
		public GoldParser(string egtPath, ITokenFactory factory = null)
		{
			using (FileStream stream = new FileStream(egtPath, FileMode.Open, FileAccess.Read, FileShare.Read)) {
				Init(new GTable(stream), factory);
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="GoldParser" /> class.
		/// Loads grammar from the buffer.
		/// </summary>
		/// <param name="egtBuffer">The buffer containing EGT data.</param>
		/// <param name="factory">The token factory.</param>
		public GoldParser(byte[] egtBuffer, ITokenFactory factory = null)
		{
			using (MemoryStream stream = new MemoryStream(egtBuffer)) {
				Init(new GTable(stream), factory);
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="GoldParser" /> class.
		/// Loads grammar from the specified stream.
		/// </summary>
		/// <param name="stream">The stream.</param>
		/// <param name="factory">The token factory.</param>
		public GoldParser(Stream stream, ITokenFactory factory = null)
		{
			Init(new GTable(stream), factory);
		}
		#endregion


		#region Methods
		protected void Init(Grammar grammar, ITokenFactory factory)
		{
			var symbols = new GoldSymbols(grammar);
//			var lexer = new GoldLexer(grammar, symbols);
			var lexer = grammar.CreateLexer(symbols);
			var rules = new GoldRules(grammar);
			var states = new GoldLalrStates(grammar);

			Init(symbols, lexer, rules, states, grammar.InitialLalrState);
			Factory = factory;
		}

		#endregion
	}

	#region UnitGoldParser
	public sealed class UnitGoldParser : ClassUnit
	{
		private UnitGoldParser() : base(typeof(GoldParser), UnitGold._) { }
		public static readonly UnitGoldParser _ = new UnitGoldParser();
		public static UnitGoldParser Instance => _;
	}
	#endregion
}
