﻿using System;
using System.IO;
using System.Text;
using Dwarf.Utility;
#pragma warning disable RCS1060, RCS1023


namespace Dwarf.Parsing
{
	/// <summary>
	/// Class LookaheadReader
	/// </summary>
	public class Lookahead : TextSource
	{
		const int cDefaultSize = 1024;

		#region Fields
		private char[] buffer;
		private int bufEnd, readPos, lookPos;
		private bool hasCrAtEnd;
		#endregion

		#region Properties
		public char[] Buffer => buffer;
		public int IncrementSize { get; set; }
		public int LookaheadLength {
			get {
				return lookPos - readPos;
			}
			set {
				Debug.Assert(value >= 0 && value <= (lookPos - readPos));
				lookPos = readPos + value;
			}
		}
		#endregion

		#region Constructors
		public Lookahead(TextReader source, int initialSize = 0, int incrementSize = 0) :
			base(source, EOLMode.Any)
		{
			Debug.Assert(source != null);
			if (initialSize <= 0) {
				initialSize = cDefaultSize;
			}
			IncrementSize = incrementSize > 0 ? incrementSize : initialSize;
			buffer = new char[initialSize];
			bufEnd = readPos = lookPos = 0;
			hasCrAtEnd = false;
		}
		#endregion

		#region Methods
		public string GetLookaheadText()
		{
			return LookaheadText(0, LookaheadLength);
		}

		public string GetLookaheadText(int start, int length)
		{
			if (start < 0) {
				throw new ArgumentOutOfRangeException(nameof(start));
			}
			if (length < 0) {
				throw new ArgumentOutOfRangeException(nameof(length));
			}
			if (start + length > LookaheadLength) {
				length = LookaheadLength - start;
			}
			return LookaheadText(start, length);
		}

		public string LookaheadText()
		{
			return new string(buffer, readPos, LookaheadLength);
		}

		public string LookaheadText(int start)
		{
			Debug.Assert(start >= 0 && start <= LookaheadLength);
			return new string(buffer, readPos + start, LookaheadLength - start);
		}

		public string LookaheadText(int start, int length)
		{
			Debug.Assert(start >= 0 && length >= 0 && (start + length) <= LookaheadLength);
			return new string(buffer, readPos + start, length);
		}

		public void PushBack(int count=1)
		{
			Debug.Assert(count <= LookaheadLength);
			lookPos -= count;
		}

		public char LookaheadChar()
		{
			if (lookPos == bufEnd)
			{
				if (hasCrAtEnd) {
					bufEnd++;
					hasCrAtEnd = false;
				}

				bool resize = false;
				if (readPos > 0) {
					int unread = bufEnd - readPos;
					if (unread < IncrementSize / 2) {
						Array.Copy(buffer, readPos, buffer, 0, bufEnd - readPos);
						bufEnd -= readPos;
						lookPos -= readPos;
						readPos = 0;
					} else {
						resize = true;
					}
				} else {
					resize = (bufEnd == buffer.Length);
				}

				if (resize) {
					Array.Resize(ref buffer, 2 * buffer.Length);
				}

				int read = Reader.Read(buffer, bufEnd, buffer.Length - bufEnd);
				if (read == 0 && lookPos == bufEnd) {
					return EOF;
				}

				bufEnd += read;
				if (buffer[bufEnd-1] == '\r') {
					hasCrAtEnd = true;
					bufEnd--;
				}
			}

			return buffer[lookPos++];
		}

		public void ConsumeLookahead()
		{
			ConsumeLookahead(LookaheadLength);
		}

		public void ConsumeLookahead(int length)
		{
			Debug.Assert(length >= 0 && length <= LookaheadLength);

			for (int i = 0; i < length; i++)
			{
				switch (buffer[readPos++])
				{
				case '\n':
					LineNo++;
					LinePos = 1;
					break;

				case '\r':
					break;

				default:
					LinePos++;
					break;
				}

				Position++;
			}
			lookPos = readPos;
		}

		public void ConsumeLookahead(out string text)
		{
			text = LookaheadText();
			ConsumeLookahead(LookaheadLength, out text);
		}

		public void ConsumeLookahead(int length, out string text)
		{
			if (length > LookaheadLength) {
				length = LookaheadLength;
			}
			text = LookaheadText(0, length);
			ConsumeLookahead(length);
		}

		public new char ReadChar()
		{
			char ch;
			if (LookaheadLength == 0) {
				ch = LookaheadChar();
			} else {
				ch = buffer[readPos];
			}
			if (ch != EOF) {
				ConsumeLookahead(1);
			}
			return ch;
		}

		public new string ReadLine()
		{
			uint lineNo = LineNo;
			ConsumeLookahead(0);
			StringBuilder sb = new StringBuilder();
			do {
				char ch = LookaheadChar();
				if (ch == EOF)
					break;
				sb.Append(ch);
				ConsumeLookahead();
			}
			while (LineNo == lineNo);

			return sb.ToString();
		}

		public void SkipLine()
		{
			uint lineNo = LineNo;
			ConsumeLookahead(0);
			do {
				LookaheadChar();
				ConsumeLookahead();
			}
			while (LineNo == lineNo);
		}
		#endregion
	}

	#region UnitLookahead
	public sealed class UnitLookahead : ClassUnit
	{
		private UnitLookahead() : base(typeof(Lookahead), UnitParsing._) { }
		public static readonly UnitLookahead _ = new UnitLookahead();
		public static UnitLookahead Instance => _;
	}
	#endregion
}
