﻿using System;

namespace Dwarf.Utility
{
	public partial class CommandLine
	{
		[AttributeUsage(AttributeTargets.Property)]
		public class UsageAttribute : Attribute
		{
			public string UsageString { get; set; } = null;
			public string LinePrefix { get; set; } = null;
			public string Additional { get; set; } = null;
		}

		[AttributeUsage(AttributeTargets.Method)]
		public class PreviewAttribute : Attribute
		{
		}

		[AttributeUsage(AttributeTargets.Method)]
		public class PreprocessAttribute : Attribute
		{
		}

		[AttributeUsage(AttributeTargets.Method)]
		public class PostprocessAttribute : Attribute
		{
		}

		[AttributeUsage(AttributeTargets.Property)]
		public class ArgumentAttribute : Attribute
		{
			public string Name { get; set; }
			public string Description { get; set; } = null;
			public string Note { get; set; } = null;
			public bool IsRequired { get; set; } = false;

			public ArgumentAttribute(string name)
			{
				Name = name;
			}
		}

		[AttributeUsage(AttributeTargets.Property)]
		public class ArgumentListAttribute : Attribute
		{
			public string Name { get; set; }
			public string Description { get; set; } = null;
			public string Note { get; set; } = null;
			public bool IsRequired { get; set; } = false;

			public ArgumentListAttribute(string name)
			{
				Name = name;
			}
		}

		[AttributeUsage(AttributeTargets.Property)]
		public class ArgumentPairedListAttribute : Attribute
		{
		}

		[AttributeUsage(AttributeTargets.Property)]
		public class OptionAttribute : Attribute
		{
			public char ShortName { get; set; }
			public string LongName { get; set; }
			public string Param { get; set; } = null;
			public string Description { get; set; } = null;
			public string Note { get; set; } = null;
			public bool IsRequired { get; set; } = false;
			public bool IsHelpOption { get; set; } = false;
			public OptionStyle Style { get; set; } = OptionStyle.Default;
			public bool AllowMultiple { get; set; } = false;
			public string Group { get; set; } = null;

			public OptionAttribute(char shortName, string longName)
			{
				ShortName = shortName;
				LongName = longName;
			}

			public OptionAttribute(char shortName)
			{
				ShortName = shortName;
				LongName = String.Empty;
			}

			public OptionAttribute(string longName)
			{
				ShortName = cNoShortName;
				LongName = longName;
			}
		}

		[AttributeUsage(AttributeTargets.Property)]
		public class OptionGroupAttribute : Attribute
		{
			public string Name { get; set; }
			public string Text { get; set; }
			public string Description { get; set; } = null;
			public string Note { get; set; } = null;
			public bool IsRequired { get; set; } = false;
			public bool IsDefault { get; set; } = false;
			public bool AfterArguments { get; set; } = false;
		}
	}
}
