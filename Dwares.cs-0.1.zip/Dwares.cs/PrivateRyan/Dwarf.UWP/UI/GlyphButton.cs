﻿//using System;
using System.Threading;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Text;
using Windows.UI.Xaml;
using Dwarf.Data;


namespace Dwarf.UI
{
	public class GlyphButton : IconButton
	{
		public GlyphButton()
		{
			DefaultStyleKey = typeof(GlyphButton);

//			ShapeStyle = ShapeStyle.Fill | ShapeStyle.Ellipse;
		}

		public new FontIcon Icon {
			get => LazyInitializer.EnsureInitialized(ref fontIcon, () => new FontIcon() {
						Glyph = this.Glyph,
						FontFamily = GlyphFontFamily,
						FontSize = GlyphFontSize,
						FontStyle = GlyphFontStyle,
						FontWeight = GlyphFontWeight
					});

			private set {
				base.Icon = fontIcon = value;
			}
		}
		FontIcon fontIcon;


		public bool GlyphIsSymbol {
			get {
				char? ch = Convert.ToNullabe<char>(Glyph);
				return Symbols.IsSymbolChar(ch);
			}
		}

		public Symbol? GlyphAsSymbol {
			get {
				char? ch = Convert.ToNullabe<char>(Glyph);
				return Symbols.ToSymbol(ch);
			}
			set {
				char? ch = value?.ToChar();
				Glyph = ch?.ToString();
			}
		}

		public new Symbol Symbol {
			set {
				char ch = value.ToChar();
				Glyph = ch.ToString();
			}
		}

		public string Glyph {
			get => (string)GetValue(GlyphProperty);
			set => SetValue(GlyphProperty, value);
		}
		public static readonly DependencyProperty GlyphProperty = UI.RegisterDependencyProperty<GlyphButton, string>(nameof(Glyph), string.Empty);

		public FontFamily GlyphFontFamily {
			get => (FontFamily)GetValue(GlyphFontFamilyProperty);
			set => SetValue(GlyphFontFamilyProperty, value);
		}
		public static readonly DependencyProperty GlyphFontFamilyProperty = UI.RegisterDependencyProperty<GlyphButton, FontFamily>(nameof(GlyphFontFamily), UI.SymboslFontFamily);

		public double GlyphFontSize {
			get => (double)GetValue(GlyphFontSizeProperty);
			set => SetValue(GlyphFontSizeProperty, value);
		}
		public static readonly DependencyProperty GlyphFontSizeProperty = UI.RegisterDependencyProperty<GlyphButton, double>(nameof(GlyphFontSize), 16);

		public FontWeight GlyphFontWeight {
			get => (FontWeight)GetValue(GlyphFontWeightProperty);
			set => SetValue(GlyphFontWeightProperty, value);
		}
		public static readonly DependencyProperty GlyphFontWeightProperty = UI.RegisterDependencyProperty<GlyphButton, FontWeight>(nameof(GlyphFontWeight));

		public FontStyle GlyphFontStyle {
			get => (FontStyle)GetValue(GlyphFontStyleProperty);
			set => SetValue(GlyphFontStyleProperty, value);
		}
		public static readonly DependencyProperty GlyphFontStyleProperty = UI.RegisterDependencyProperty<GlyphButton, FontStyle>(nameof(GlyphFontStyle));


		protected override void OnApplyTemplate()
		{
			base.OnApplyTemplate();
			Icon = GetTemplateChild("Icon") as FontIcon;
		}
	}
}
