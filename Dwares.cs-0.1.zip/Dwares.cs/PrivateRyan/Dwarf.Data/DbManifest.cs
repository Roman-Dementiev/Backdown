﻿using System;
using System.Collections.Generic;
using System.Data;
using Dwarf.Collections;


namespace Dwarf.Data
{
	public class DbManifest : IDbManifest
	{
		internal enum Type
		{
			Version,
			Content,
			Table,
			Metadata,
			Asset
		}

		internal enum Field
		{
			Type,
			Name,
			Value
		}

		internal static class Names
		{
			internal const string Version = nameof(Version);
		}

		Version version;
		string contentType;
		string contentName;
		IEnumerable<string> tables;
		Vocabulary<string> schemas;
		Vocabulary<string> metadata;


		public DbManifest(IDb db, string manifestTable) :
			this(db, null, null, null)
		{
			ManifestTable = manifestTable;
		}

		public DbManifest(Vocabulary<string> schemas, Vocabulary<string> metadata = null) :
			this(null, schemas, schemas.Keys, metadata)
		{}

		public DbManifest(Vocabulary<string> schemas, Vocabulary<string> metadata, params string[] tables) :
			this(null, schemas, tables, metadata)
		{ }

		public DbManifest(Vocabulary<string> schemas, params string[] tables) :
			this(null, schemas, tables, null)
		{ }

		DbManifest(IDb db, Vocabulary<string> schemas, IEnumerable<string> tables, Vocabulary<string> metadata)
		{
			Db = db;
			this.schemas = schemas;
			this.tables= tables;
			this.metadata = metadata;
		}

		public IDb Db { get; private set; }
		public string ManifestTable { get; set; }

		public Version Version {
			get {
				if (version == null) {
					var value = GetValue(Type.Version, Names.Version);
					if (value != null) {
						version = new Version(value);
					}
				}
				return version;
			}
			set {
				version = value;
			}
		}

		public string ContentType {
			get {
				if (contentType == null) {
					GetContent();
				}
				return contentType;
			}
			set {
				contentType = value;
			}
		}

		public string ContentName {
			get {
				if (contentName == null) {
					GetContent();
				}
				return contentName;
			}
			set {
				contentName = value;
			}
		}

		public IEnumerable<string> Tables {
			get {
				if (tables == null) {
					tables = GetNames(Type.Table);
				}
				return tables;
			}
		}

		public IEnumerable<string> Metadata {
			get {
				if (metadata == null) {
					return GetNames(Type.Metadata);
				} else {
					return metadata.Keys;
				}
			}
		}

		public string GetSchema(string table)
		{
			if (schemas == null) {
				schemas = new Vocabulary<string>();
			} else if (schemas.ContainsKey(table)) {
				return schemas[table];
			}

			var schema = GetValue(Type.Table, table);
			schemas[table] = schema;
			return schema;
		}

		public string GetMetadata(string name)
		{
			if (metadata == null) {
				metadata = new Vocabulary<string>();
			} else if (metadata.ContainsKey(name)) {
				return metadata[name];
			}

			var value = GetValue(Type.Metadata, name);
			metadata[name] = value;
			return value;
		}

		public virtual void InitDb(IDb db)
		{
			Db = db;
			InitDb(db, this);
		}

		public static void InitDb(IDb db, IDbManifest manifest)
		{
			using (var command = db.Command())
			{
				var manifestTable = manifest.ManifestTable;
				if (manifestTable != null) {
					command.CommandText = manifest.GetSchema(manifestTable);
					command.ExecuteNonQuery();

					var version = manifest.Version;
					var contentType = manifest.ContentType;
					var contentName = manifest.ContentName;
					if (version != null) {
						Insert(command, manifestTable, Type.Version, Names.Version, version);
					}
					if (contentType != null || contentName != null) {
						Insert(command, manifestTable, Type.Content, contentName ?? String.Empty, contentType ?? String.Empty);
					}
				}

				var tables = manifest.Tables;
				if (tables != null) {
					foreach (var table in tables) {
						var schema = manifest.GetSchema(table);
						if (table != manifestTable) {
							command.CommandText = schema;
							command.ExecuteNonQuery();
						}

						if (manifestTable != null) {
							Insert(command, manifest.ManifestTable, Type.Table, table, schema);
						}
					}
				}

				var metadata = manifest.Metadata;
				if (metadata != null) {
					foreach (var name in metadata) {
						var value = manifest.GetMetadata(name);
						Insert(command, manifest.ManifestTable, Type.Metadata, name, value);
					}
				}
			}
		}

		static void Insert(IDbCommand command, string manifestTable, Type type, string name, object value) =>
			Insert(command, manifestTable, type.ToString(), name, value);

		static void Insert(IDbCommand command, string manifestTable, string type, string name, object value)
		{
			command.CommandText = String.Format("INSERT INTO {0} ({1}, {2}, {3}) VALUES (\"{4}\", \"{5}\", \"{6}\");",
				manifestTable,
				Field.Type, Field.Name, Field.Value,
				type, name, value.ToString());

	 		command.ExecuteNonQuery();
		}

		//public void InsertValue(string type, string name, object value)
		//{
		//	if (Db != null && ManifestTable != null) {
		//		using (var command = Db.Command()) {
		//			Insert(command, ManifestTable, type,name, value);
		//		}
		//	}
		//}

		

		internal string GetValue(Type type, string name) => GetValue(type.ToString(), name);
		public string GetValue(string type, string name)
		{
			if (Db != null && ManifestTable != null) {
				var commandText = String.Format("SELECT * FROM {0} WHERE {1}=\"{2}\" AND [{3}]=\"{4}\";",
				   ManifestTable, Field.Type, type, Field.Name, name);

				using (var query = Db.ExecuteQuery(commandText)) {
					if (query.Read()) {
						return query.String(Field.Value.ToString());
					}
				}
			}

			return null;
		}

		public string GetValue(string name)
		{
			if (Db != null && ManifestTable != null) {
				var commandText = String.Format("SELECT * FROM {0} WHERE {1}=\"{2}\";",
				   ManifestTable, Field.Name, name);

				using (var query = Db.ExecuteQuery(commandText)) {
					if (query.Read()) {
						return query.String(Field.Value.ToString());
					}
				}
			}

			return null;
		}

		internal void GetContent()
		{
			if (Db != null && ManifestTable != null) {
				var commandText = String.Format("SELECT * FROM {0} WHERE {1}=\"{2}\";",
				   ManifestTable, Field.Type, Type.Content);

				using (var query = Db.ExecuteQuery(commandText)) {
					if (query.Read()) {
						contentName = query.String(Field.Name.ToString());
						contentType = query.String(Field.Value.ToString());
					}
				}
			}
		}

		internal List<string> GetNames(Type type) => GetNames(type.ToString());
		internal List<string> GetNames(string type)
		{
			if (Db != null && ManifestTable != null) {
				var names = new List<string>();
				var commandText = String.Format("SELECT * FROM {0} WHERE {1}=\"{2}\";",
					ManifestTable, Field.Type, type);

				using (var query = Db.ExecuteQuery(commandText)) {
					while (query.Read()) {
						var name = query.String(Field.Name.ToString());
						names.Add(name);
					}
				}
				return names;
			}

			return null;
		}

	}
}
