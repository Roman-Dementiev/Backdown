﻿using System;
using System.Resources;
using System.Reflection;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Assets
{
	/// <summary>
	/// Class ResourceMgr
	/// </summary>
	public class ResourceMgr : AssetMgr
	{
		#region Fields
		#endregion

		#region Properties
		public ResourceManager ResourceManager { get; set; }
		#endregion

		#region Constructors
		public ResourceMgr(ResourceManager manager, object culture, bool multiCultural = false) :
			base(culture, multiCultural)
		{
			ResourceManager = manager;
		}

		public ResourceMgr(Assembly assembly, string baseName, Type type, object culture, bool multiCultural = false) :
			base(culture, multiCultural)
		{
			UseAssembly(assembly, baseName, type);
		}

		public ResourceMgr(bool entryAssembly, string baseName, Type type, object culture, bool multiCultural = false) :
			base(culture, multiCultural)
		{
			if (entryAssembly) {
				UseEntryAssembly(baseName, type);
			} else {
				UseExecutingAssembly(baseName, type);
			}
		}
		#endregion

		#region Methods
		public void UseAssembly(Assembly assembly, string baseName, Type type = null)
		{
			if (type != null) {
				ResourceManager = new ResourceManager(baseName, assembly, type);
			} else {
				ResourceManager = new ResourceManager(baseName, assembly);
			}
		}

		public void UseEntryAssembly(string baseName, Type type = null)
		{
			UseAssembly(Assembly.GetEntryAssembly(), baseName, type);
		}

		public void UseExecutingAssembly(string baseName, Type type = null)
		{
			UseAssembly(Assembly.GetExecutingAssembly(), baseName, type);
		}

		public override object GetAsset(string key, object culture = null)
		{
			object asset = base.GetAsset(key, culture);
			if (asset == null) {
				asset = GetResource(key, null, culture);
				AddAsset(key, asset, culture);
			}
			return asset;
		}

		public override object GetAsset(string key, Type type, object culture = null)
		{
			object asset = base.GetAsset(key, culture);
			if (asset == null) {
				asset = GetResource(key, type, culture);
			}
			return asset;
		}

		public object GetResource(string key, Type type, object culture, bool add = true)
		{
			string resourceName;
			if (IsMultiCultural && culture != null) {
				resourceName = culture.ToString() + ':' + key;
			} else {
				resourceName = key;
			}
			object asset = ResourceManager.GetObject(resourceName);
			if (asset == null)
				return null;

			if (type != null && !type.IsInstanceOfType(asset)) {
				Log.Error(UnitResourceMgr._,
					Messages.GetAssetTypeMismatch, key, type.FullName, asset.GetType().FullName);
				return null;
			}

			if (add) {
				AddAsset(key, asset, culture);
			}
			return asset;
		}
		#endregion

	}

	#region UnitResourceMgr
	public sealed class UnitResourceMgr : ClassUnit
	{
		private UnitResourceMgr() : base(typeof(ResourceMgr), UnitAssets._) { }
		public static readonly UnitResourceMgr _ = new UnitResourceMgr();
		public static UnitResourceMgr Instance => _;
	}
	#endregion
}
