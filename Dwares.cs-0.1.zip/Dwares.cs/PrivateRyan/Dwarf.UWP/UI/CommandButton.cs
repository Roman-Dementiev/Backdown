﻿using System;
using Dwarf.Platform;
using Windows.UI.Xaml.Controls;


namespace Dwarf.UI
{
	public class CommandButton : AppBarButton
	{
		public CommandButton() { }

		public Symbol Symbol {
			set {
				Icon = new SymbolIcon(value);
			}
		}

		public Action Action {
			set {
				if (value == null) {
					Command = null;
				} else if (Command is RelayCommand relayCommand) {
					relayCommand.SetExecute(value);
				} else {
					Command = new RelayCommand(value);
				}
			}
		}

		public void RaiseCanExecuteChanged()
		{
			if (Command is RelayCommand relayCommand) {
				relayCommand.RaiseCanExecuteChanged();
			}
		}
	}
}
