﻿using System;


namespace Dwarf.ObjectModel
{
	public class KinCollection<TItem> : EntityCollection<TItem> where TItem : class, IEntity, IKin<TItem>
	{
		public override int Add(TItem item)
		{
			var parent = item.Parent;
			if (parent != null) {
				int parentIndex = IndexOf(parent);
				if (parentIndex < 0) {
					parentIndex = Add(parent);
				}
				
				int index;
				for (index = parentIndex+1; index < Count; index++) {
					if (this[index].Parent != parent)
						break;
				}
				Insert(index, item);
				return index;
			} else {
				return base.Add(item);
			}
		}
	}
}
