﻿using System;
using System.Threading;
using Windows.UI.Xaml.Controls;
using Dwarf.Platform;
using Dwarf.UI;


namespace Azbooka
{
	/// <summary>
	/// An empty page that can be used on its own or navigated to within a Frame.
	/// </summary>
	public sealed partial class PhrasebookPage : Page
	{
		public PhrasebookPage()
		{
			this.InitializeComponent();
		}

		public Abc ViewModel => Abc.Instance;

		public string Title => Appx.GetString(_Title);
		const string _Title = "Phrasebook";

		//public LocalizableUI LocalizableUI => LazyInitializer.EnsureInitialized(
		//	ref localizableUI, () => new LocalizableUI() {
		//	});
		//LocalizableUI localizableUI;
	}
}
