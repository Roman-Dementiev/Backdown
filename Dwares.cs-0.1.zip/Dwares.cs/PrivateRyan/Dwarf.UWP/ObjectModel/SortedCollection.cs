﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Dwarf.Extensions;


namespace Dwarf.ObjectModel
{
	public class SortedCollection<TItem> : ObservableCollection<TItem>
	{
		protected SortedCollection(None none) { }

		public SortedCollection(IComparer<TItem> comparer, bool uniqueItems=true)
		{
			UniqueItems = uniqueItems;
			Sorter = new Sorter<TItem>(comparer);
			Sorter.SetTarget(this);
		}

		public SortedCollection(SortOrder<TItem> sortOrder = null, SortPolicy sortPolicy = SortPolicy.Default) :
			this(true, sortOrder, sortPolicy)
		{ }

		public SortedCollection(bool uniqueItems, SortOrder<TItem> sortOrder = null, SortPolicy sortPolicy = SortPolicy.Default)
		{
			UniqueItems = uniqueItems;
			Sorter = new Sorter<TItem>(sortOrder, sortPolicy);
			Sorter.SetTarget(this);
		}

		public bool UniqueItems { get; protected set; }
		protected Sorter<TItem> Sorter { get; set; }


		public IComparer<TItem> Comparer {
			get => Sorter.Comparer;
			set => Sorter.Comparer = value;
		}

		public SortOrder<TItem> SortOrder { 
			get => Sorter.SortOrder;
			set => Sorter.SortOrder = value;
		}

		public virtual SortPolicy SortPolicy { 
			get => Sorter.SortPolicy;
			set => Sorter.SortPolicy = value;
		}


		public new int IndexOf(TItem item)
		{
			int index = this.BinarySearch(item, Comparer);
			return (index >= 0) ? index : -1;
		}

		public new int Add(TItem item)
		{
			TItem actualItem;
			return Add(item, out actualItem);
		}

		public int Add(TItem item, out TItem actualItem)
		{
			int index = this.BinarySearch(item, Comparer);
			if (UniqueItems && index >= 0) {
				actualItem = this[index];
				return index;
			}

			if (index < 0) {
				InsertItem(-index-1, item);
			} else {
				InsertItem(index+1, item);
			}

			actualItem = item;
			return index;
		}

		public void AddSortedItems(IList<TItem> items)
		{
			if (items == null || items.Count == 0)
				return;

			int index = this.BinarySearch(items[0], Comparer);
			if (index < 0) {
				index = -index - 1;
			} else {
				index++;
			}

			foreach (var item in items)
			{
				if (UniqueItems && IndexOf(item) >= 0)
					continue;

				InsertItem(index, item);
				index++;
			}
		}

	}
}
