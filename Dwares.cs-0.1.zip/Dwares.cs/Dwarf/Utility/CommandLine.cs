﻿using System;
using System.Reflection;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Dwarf.Config;
using Dwarf.Assets;
using Dwarf.Collections;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Utility
{
	/// <summary>
	/// Class CommandLine
	/// </summary>
	public partial class CommandLine
	{
		public const char cNoShortName = '\0';
		public const char cConfigChar = '@';

		[Flags]
		public enum OptionStyle : uint
		{
			ShortSlash = 0x0001,
			ShortDash = 0x0002,
			LongSlash = 0x0004,
			LongDash = 0x00008,
			ShortSlashOrDash = ShortDash | ShortSlash,
			LongSlashOrDash = LongSlash | LongDash,
			Slash = ShortSlash | LongSlash,
			Dash = ShortDash | LongDash,
			SlashOrDash = Slash | Dash,

			IgnoreCase = 0x0100,
			AllowDashDash = 0x0200,
			AllowPairing = 0x0400,
			AllowConfig = 0x0800,
			Default = 0
		}

		#region Interfaces
		public interface IElement
		{
			string Name { get; set; }
			string Text { get; set; }
			string Description { get; set; }
			string Note { get; set; }
			bool IsRequired { get; set; }
			bool IsPresent { get; set; }
		}

		public interface IArgument : IElement
		{
			object Parse(string text);
			object GetValue();
		}

		public interface IArgumentList : IArgument
		{
			void Add(string arg);
			int Count { get; }
			string this[int index] { get; }
		}

		public interface IOption : IArgument
		{
			IOptionGroup Group { get; }
			char ShortName { get; }
			string LongName { get; }
			OptionStyle Style { get; }
			bool IsHelpOption { get; }
			bool AllowMultiple { get; }
		}

		public interface IOptionGroup : IElement
		{
			bool AfterArguments { get; }
			IEnumerable<IOption> Options { get; }
			void Add(IOption option);
		}
		#endregion

		#region Properties
		public List<IOption> Options { get; private set; } = null;
		public List<IOptionGroup> Groups { get; private set; } = null;
		public List<IArgument> Arguments { get; private set; } = null;
		public IArgumentList ArgumentList { get; private set; } = null;
		public IArgumentList PairedList { get; private set; } = null;

		private IOptionGroup defaultGroup = null;
		public IOptionGroup DefaultGroup {
			get {
				if (defaultGroup == null) {
					defaultGroup = new OptionGroup("Options", "Options");
				}
				return defaultGroup;
			}
			set { defaultGroup = value; }
		}

		private OptionStyle style;
		public OptionStyle Style {
			get { return style; }
			set { style = (value == OptionStyle.Default) ? DefaultStyle : value; }
		}

		public static OptionStyle DefaultStyle { get; set; } = OptionStyle.SlashOrDash | OptionStyle.AllowDashDash | OptionStyle.AllowPairing;
		public static string PairingSymbol { get; set; } = ":";

		public string Usage{ get; set; } = null;
		public string UsageString { get; set; } = null;
		public string LinePrefix { get; set; } = "  ";
		public string Additional { get; set; } = null;

		public delegate void PreviewProc(string arg);
		public delegate string[] ProcessProc(string[] arg);
		public ProcessProc Preprocess { get; set; } = null;
		public ProcessProc Postprocess { get; set; } = null;

		private class ProcessMethod : Reflection.GMethod<string[]>
		{
			public ProcessMethod(object target, MethodInfo method) :
				base(target, method)
			{
				ParameterInfo[] parameters = method.GetParameters();
				if (method.ReturnType != typeof(string[]) ||
					parameters.Length != 1 ||
					parameters[0].ParameterType != typeof(string[]))
				{
					new InvalidArgumentProcessor(method.Name).Throw();
				}
			}

			public string[] Invoke(string[] args)
			{
				return base.Invoke(new object[] { args });
			}
		}

		private ProcessMethod preprocess = null;
		private ProcessMethod postprocess = null;
		#endregion

		#region Constructors
		public CommandLine(IEnumerable<IArgument> arguments, OptionStyle style = OptionStyle.Default) :
			this(arguments, null, null, style)
		{ }

		public CommandLine(IEnumerable<IOption> options, OptionStyle style = OptionStyle.Default) :
			this(null, options, null, style)
		{ }

		public CommandLine(IEnumerable<IArgument> arguments, IEnumerable<IOption> options,
							IEnumerable<IOptionGroup> groups, OptionStyle style = OptionStyle.Default)
		{
			if (options != null) {
				Options = new List<IOption>(options);
			} else {
				Options = new List<IOption>();
			}

			if (arguments != null) {
				Arguments = new List<IArgument>(arguments);
			} else {
				Arguments = new List<IArgument>();
			}

			if (groups != null) {
				Groups = new List<IOptionGroup>(groups);
			} else {
				Groups = new List<IOptionGroup>();
			}

			Style = style;
		}

		public CommandLine(object target, OptionStyle style = OptionStyle.Default) :
			this(null, null, null, style)
		{
			foreach (MethodInfo method in target.GetType().GetMethods())
			{
				PreviewAttribute previewAttr = method.GetCustomAttribute<PreviewAttribute>();
				if (previewAttr != null) {
					string[] args = Environment.GetCommandLineArgs();
					for (int i = 1; i < args.Length; i++) {
						method.Invoke(target, new object[] { args[i] });
					}
					continue;
				}

				PreprocessAttribute preprocessAttr = method.GetCustomAttribute<PreprocessAttribute>();
				if (preprocessAttr != null) {
					preprocess = new ProcessMethod(target, method);
					Preprocess = preprocess.Invoke;
					continue;
				}

				PostprocessAttribute postprocessAttr = method.GetCustomAttribute<PostprocessAttribute>();
				if (postprocessAttr != null) {
					postprocess = new ProcessMethod(target, method);
					Postprocess = postprocess.Invoke;
				}
			}

			AddTargetProperties(target);
		}

		#endregion

		#region Method
		public void AddTargetProperties(object target)
		{
			if (target == null) {
				throw new ArgumentNullException(nameof(target));
			}

			foreach (PropertyInfo property in target.GetType().GetProperties())
			{
				OptionGroupAttribute groupAttr = property.GetCustomAttribute<OptionGroupAttribute>();
				if (groupAttr != null) {
					object groupObj = Reflection.GetPropertyValue(target, property);

					string name = groupAttr.Name;
					if (name == null && groupObj != null) {
						name = groupObj.ToString();
					}
					if (String.IsNullOrEmpty(name)) {
						Log.Warning(UnitCommandLine._, AssetMgr.GetString(Messages.OptionGroupWithoutName));
						continue;
					}

					IOptionGroup group = new OptionGroup(
												name,
												groupAttr.Description,
												groupAttr.Note,
												groupAttr.IsRequired,
												groupAttr.AfterArguments);

					if (groupAttr.Text != null) {
						group.Text = groupAttr.Text;
					}

					if (groupAttr.IsDefault) {
						DefaultGroup = group;
					} else {
						Groups.Add(group);
					}

					if (groupObj != null) {
						AddTargetProperties(groupObj);
					}
				}

				OptionAttribute optAttr = property.GetCustomAttribute<OptionAttribute>();
				if (optAttr != null) {
					Type propertyType = property.PropertyType;
					try {
						IOptionGroup group = GetGroup(optAttr.Group);

						IOption option;
						if (optAttr.AllowMultiple) {
							option = new MultiOption<string>(
												group,
												optAttr.ShortName,
												optAttr.LongName,
												optAttr.Param,
												optAttr.Description,
												optAttr.Note,
												optAttr.IsRequired,
												target,
												property,
												optAttr.Style);
						} else {
							option = (IOption)Reflection.CreateGenericInstance(
											typeof(Option<>), propertyType,
											new object[] {
												group,
												optAttr.ShortName,
												optAttr.LongName,
												optAttr.Param,
												optAttr.Description,
												optAttr.Note,
												optAttr.IsRequired,
												target,
												property,
												optAttr.Style
											});
						}

						AddOption(option);
						group.Add(option);
					}
					catch (Exception exc) {
						new InvalidCommandLineOptionType(optAttr.LongName, exc).Throw();
					}
					continue;
				}

				ArgumentAttribute argAttr = property.GetCustomAttribute<ArgumentAttribute>();
				if (argAttr != null) {
					Type propertyType = property.PropertyType;
					try {
						Type argType = typeof(Argument<>).MakeGenericType(propertyType);
						IArgument arg = (IArgument)Reflection.CreateGenericInstance(
											typeof(Argument<>), propertyType,
											new object[] {
												argAttr.Name,
												argAttr.Description,
												argAttr.Note,
												argAttr.IsRequired,
												target,
												property
											});

						AddArgument(arg);
					}
					catch (Exception exc) {
						new InvalidCommandLineArgumentType(argAttr.Name, exc).Throw();
					}
					continue;
				}

				ArgumentListAttribute argListAttr = property.GetCustomAttribute<ArgumentListAttribute>();
				if (argListAttr != null) {
					AddArgument(new ArgList(argListAttr.Name,
											argListAttr.Description,
											argListAttr.Note,
											argListAttr.IsRequired,
											target,
											property
											));
					continue;
				}

				UsageAttribute usageAttr = property.GetCustomAttribute<UsageAttribute>();
				if (usageAttr != null) {
					Usage = Reflection.GetPropertyValue<string>(target, property);
					if (Usage == null) {
						if (usageAttr.UsageString != null) {
							UsageString = usageAttr.UsageString;
						}
						if (usageAttr.LinePrefix != null) {
							LinePrefix = usageAttr.LinePrefix;
						}
						if (usageAttr.Additional != null) {
							Additional = usageAttr.Additional;
						}
					}
				}
			}
		}

		public void AddArgument(IArgument argument)
		{
			if (ArgumentList != null) {
				new ArgumentAfterArgumentList(argument.Name).Throw();
			}

			if (argument is IArgumentList) {
				ArgumentList = argument as IArgumentList;
			}

			Arguments.Add(argument);
		}

		public void AddOption(IOption option)
		{
			Options.Add(option);
		}

		IOptionGroup GetGroup(string name)
		{
			if (name == null) {
				return DefaultGroup;
			}

			foreach (IOptionGroup group in Groups) {
				if (group.Name == name)
					return group;
			}

			OptionGroup newGroup = new OptionGroup(name, String.Empty);
			Groups.Add(newGroup);
			return newGroup;
		}

		public static bool Parse(object target, string[] args, OptionStyle style = OptionStyle.Default,
								ProcessProc preprocess = null, ProcessProc postprocess = null)
		{
			return Parse(target, args, out args, style, preprocess, postprocess);
		}

		public static bool Parse(object target, string[] args, out string[] unprocessed, OptionStyle style = OptionStyle.Default,
								ProcessProc preprocess = null, ProcessProc postprocess = null)
		{
			CommandLine cl = new CommandLine(target, style);
			if (preprocess != null) {
				cl.Preprocess = preprocess;
			}
			if (postprocess != null) {
				cl.Postprocess = postprocess;
			}

			return cl.Parse(args, out unprocessed);
		}

		public bool Parse(string[] args, ProcessProc preprocess = null, ProcessProc postprocess = null)
		{
			return Parse(args, out args);
		}

		public bool Parse(string[] args, out string[] unprocessed)
		{
			bool printHelp;
			bool ok = Parse(args, out unprocessed, out printHelp);
			if (!ok || printHelp) {
				PrintUsage(Console.Out);
			}
			return ok;
		}

		public bool Parse(string[] args, out string[] unprocessed, out bool printHelp)
		{
			if (args == null) {
				throw new ArgumentNullException(nameof(args));
			}

			if (Preprocess != null) {
				args = Preprocess(args);
			}

			bool ok = true, checkOptions = true;
			printHelp = false;
			List<string> outArgs = null;
			int argIndex = 0;
			int i = 0, count = args.Length;
			while (i < count) {
				string arg = args[i++];

				IOption option = null;
				if (checkOptions) {
					switch (arg[0])
					{
					case '/':
						if ((Style & OptionStyle.Slash) != 0) {
							option = GetOption(OptionStyle.ShortSlash, OptionStyle.LongSlash, arg.Substring(1));
							if (option == null) {
								Log.Error(UnitCommandLine._, Messages.UnknownOption, arg);
								ok = false;
							}
						}
						break;

					case '-':
						if (arg.Length == 1)
							continue;
						if ((Style & OptionStyle.AllowDashDash) != 0 && arg.Length == 2 && arg[1] == '-') {
							checkOptions = false;
							continue;
						}
						if ((style & OptionStyle.Dash) != 0) {
							option = GetOption(OptionStyle.ShortDash, OptionStyle.LongDash, arg.Substring(1));
							if (option == null) {
								Log.Error(UnitCommandLine._, Messages.UnknownOption, arg);
								ok = false;
							}
						}
						break;

					case cConfigChar:
						if ((Style & OptionStyle.AllowConfig) != 0) {
							string filename = arg.Substring(1);
							if (!File.Exists(filename)) {
								Log.Error(UnitCommandLine._, Messages.ConfigFileNotFound, filename);
								ok = false;
							} else {
								IConfig config = ConfigMgr.CreateConfig(filename);
								if (config != null) {
									Unit.Root.Configure(config, true, false);
								} else {
									Log.Error(UnitCommandLine._, Messages.CantCreateConfig, filename);
									ok = false;
								}
							}
						}
						break;
					}
				}

				if (option != null) {
					if (option.IsPresent && !option.AllowMultiple) {
						Log.Error(UnitCommandLine._, Messages.DuplicateOption, arg);
						ok = false;
					}
					option.IsPresent = true;

					if (option is Option<bool>) {
						((Option<bool>)option).Value = true;
					} else {
						string val;
						if (i == count || args[i][0] == '-') {
							if (option.IsRequired) {
								Log.Error(UnitCommandLine._, Messages.MissingOptionValue, arg);
								ok = false;
							}
							val = String.Empty;
						} else {
							val = args[i++];
						}

						try {
							option.Parse(val);
						}
						catch (Exception) {
							Log.Error(UnitCommandLine._, Messages.InvalidOptionValue, arg);
							ok = false;
						}
					}
					if (option.IsHelpOption) {
						printHelp = true;
					}
				} else if (ok) {
					if (argIndex < Arguments.GetCount()) {
						Arguments[argIndex++].Parse(arg);
					} else if (ArgumentList != null) {
						if ((Style & OptionStyle.AllowPairing) != 0 && arg == PairingSymbol) {
							if (i < count) {
								if (PairedList == null) {
									PairedList = new ArgList(String.Empty, String.Empty, null, false);
								}
								while (PairedList.Count < ArgumentList.Count - 1) {
									PairedList.Add(null);
								}
								PairedList.Add(args[i++]);
							} else {
								Log.Error(UnitCommandLine._, Messages.MissingOptionValue, arg);
								ok = false;
							}
						} else {
							ArgumentList.Add(arg);
						}
					} else {
						if (outArgs == null) {
							outArgs = new List<string>();
						}
						outArgs.Add(arg);
					}
				}
			}

			foreach (IArgument argument in Arguments) {
				if (argument.IsRequired && !argument.IsPresent) {
					if (args.Length == 0) {
						printHelp = true;
					} else {
						Log.Error(UnitCommandLine._, Messages.RequiredArgumentIsMissing, argument.Name);
					}
					ok = false;
				}
			}

			//foreach (IOption option in Options) {
			//	if (option.IsRequired && !option.IsPresent) {
			//		if (args.Length == 0) {
			//			printHelp = true;
			//		} else {
			//			Log.Error(UnitCommandLine._, Messages.RequiredOptionIsMissing, option.LongName ?? option.Text);
			//		}
			//		ok = false;
			//	}
			//}

			if (PairedList != null) {
				while (PairedList.Count < ArgumentList.Count) {
					PairedList.Add(null);
				}
			}

			if (ok) {
				if (outArgs == null) {
					unprocessed = null;
				} else {
					unprocessed = outArgs.ToArray();
					if (Postprocess != null) {
						unprocessed = Postprocess(unprocessed);
					}
				}
				return true;
			} else {
				unprocessed = null;
				return false;
			}
		}

		public string GetElementText(IElement element)
		{
			if (element.Text == null) {
				IOptionGroup group = element as IOptionGroup;
				if (group != null && group.Description == null) {
					element.Text = String.Empty;
				} else {
					string ellipsis = element is IArgumentList ? "..." : String.Empty;
					if (element.IsRequired) {
						element.Text = String.Format("<{0}>{1}", element.Name, ellipsis);
					} else {
						element.Text = String.Format("[{0}]{1}", element.Name, ellipsis);
					}
				}
			}
			return element.Text;
		}

		public string GetOptionText(IOption option)
		{
			if (option.Text == null)
			{
				StringBuilder sb = new StringBuilder();
				OptionStyle style = GetOptionsStyle(option);

				bool hasShort = false;
				if (option.ShortName != cNoShortName) {
					if ((style & OptionStyle.ShortDash) != 0) {
						sb.Append('-');
						sb.Append(option.ShortName);
						hasShort = true;
					} else if ((style & OptionStyle.ShortDash) != 0) {
						sb.Append('/');
						sb.Append(option.ShortName);
						hasShort = true;
					}
				}

				if ((style & (OptionStyle.LongSlash | OptionStyle.LongDash)) != 0 &&
					!String.IsNullOrEmpty(option.LongName))
				{
					if (hasShort) {
						sb.Append(", ");
//					} else if ((Style & (OptionStyle.ShortSlash | OptionStyle.ShortDash)) != 0) {
//						sb.Append("    ");
					}
					if ((style & OptionStyle.LongDash) != 0) {
						sb.Append('-');
					} else {
						sb.Append('/');
					}
					sb.Append(option.LongName);
				}

				if (option.Name != null) {
					sb.Append(' ');
					if (option.IsRequired) {
						sb.Append(option.Name);
					} else {
						sb.Append('[');
						sb.Append(option.Name);
						sb.Append(']');
					}
				}

				option.Text = sb.ToString();
			}
			return option.Text;
		}

		public OptionStyle GetOptionsStyle(IOption option)
		{
			if (option != null && option.Style != OptionStyle.Default) {
				return Style & option.Style;
			} else {
				return Style;
			}
		}

		public IOption GetOption(OptionStyle shortStyle, OptionStyle longStyle, string name)
		{
			foreach (IOption option in Options)
			{
				OptionStyle optStyle = GetOptionsStyle(option);
				if ((optStyle & shortStyle) != 0 && name.Length == 1 && option.ShortName != cNoShortName) {
					if ((optStyle & OptionStyle.IgnoreCase) != 0) {
						if (option.ShortName == char.ToLower(name[0]))
							return option;
					} else {
						if (option.ShortName == name[0])
							return option;
					}
				}

				if ((optStyle & longStyle) != 0) {
					if ((optStyle & OptionStyle.IgnoreCase) != 0) {
						if (option.LongName == name.ToLower())
							return option;
					} else {
						if (option.LongName == name)
							return option;
					}
				}
			}
			return null;
		}

		public void PrintUsage(TextWriter output)
		{
			if (Usage!= null) {
				output.Write(Usage);
				return;
			}

			if (LinePrefix == null) {
				LinePrefix = String.Empty;
			}

			int maxLength = 0;
			int optCount = 0;
			foreach (IOption option in Options)
			{
				string str = GetOptionText(option);
				if (maxLength < str.Length) {
					maxLength = str.Length;
				}
				optCount++;
			}

			if (optCount > 0 && defaultGroup != null && !Groups.Contains(defaultGroup)) {
				Groups.Insert(0, defaultGroup);
			}

			StringBuilder usageBuilder = null;
			bool hasGroupsAfterArguments = false;
			if (UsageString == null) {
				usageBuilder = new StringBuilder("Usage: ");

				usageBuilder.Append(Sys.AppName);

				foreach (IOptionGroup group in Groups) {
					if (String.IsNullOrEmpty(group.Description))
						continue;

					if (group.AfterArguments) {
						hasGroupsAfterArguments = true;
					} else {
						usageBuilder.Append(' ');
						usageBuilder.Append(GetElementText(group));
					}
				}
			}

			int argCount = 0;
			foreach (IArgument argument in Arguments)
			{
				string str = GetElementText(argument);
				if (maxLength < str.Length) {
					maxLength = str.Length;
				}
				argCount++;

				if (usageBuilder != null) {
					usageBuilder.Append(' ');
					usageBuilder.Append(argument.Name);
				}
			}

			if (usageBuilder != null)
			{
				if (hasGroupsAfterArguments) {
					foreach (IOptionGroup group in Groups)
					{
						if (group.AfterArguments && !String.IsNullOrEmpty(group.Description)) {
							usageBuilder.Append(' ');
							usageBuilder.Append(GetElementText(group));
						}
					}
				}

				UsageString = usageBuilder.ToString();
			}
			output.WriteLine(UsageString);

			string format = String.Format("{0}{{0,-{1}}}   {{1}}", LinePrefix, maxLength);

			foreach (IArgument argument in Arguments)
			{
				output.WriteLine(format, argument.Name, argument.Description);
				if (!String.IsNullOrEmpty(argument.Note)) {
					string[] notes = argument.Note.Split('\n');
					foreach (string note in notes) {
						output.WriteLine(format, String.Empty, note);
					}
				}
			}

			foreach (IOptionGroup group in Groups)
			{
				if (!String.IsNullOrEmpty(group.Description)) {
					output.WriteLine("{0}:", group.Description);
				}

				foreach (IOption option in group.Options) {
					output.WriteLine(format, option.Text, option.Description);
					if (!String.IsNullOrEmpty(option.Note)) {
						string[] notes = option.Note.Split('\n');
						foreach (string note in notes) {
							output.WriteLine(format, String.Empty, note);
						}
					}
				}

				if (!String.IsNullOrEmpty(group.Note)) {
					string[] notes = group.Note.Split('\n');
					foreach (string note in notes) {
						output.Write(LinePrefix);
						output.WriteLine(note);
					}
				}
			}

			if (Additional != null) {
				output.Write(Additional);
			}
		}
		#endregion

		public class InvalidCommandLineOptionType : DwarfException
		{
			public InvalidCommandLineOptionType(Dwarf.Unit unit, string message, bool useAssets, Exception innerExc = null) :
				base(unit, message, useAssets, innerExc)
			{ }

			public InvalidCommandLineOptionType(string option, Exception innerExc = null) :
				base(UnitCommandLine._, innerExc, true, Messages.InvalidOptionType, option)
			{
			}
		}

		public class InvalidCommandLineArgumentType : DwarfException
		{
			public InvalidCommandLineArgumentType(Dwarf.Unit unit, bool useAssets, string message, Exception innerExc = null) :
				base(unit, message, true, innerExc)
			{ }

			public InvalidCommandLineArgumentType(string argument, Exception innerExc = null) :
				base(UnitCommandLine._, innerExc, true, Messages.InvalidArgumentType, argument)
			{
			}
		}

		public class ArgumentAfterArgumentList : DwarfException
		{
			public ArgumentAfterArgumentList(Dwarf.Unit unit, string message, bool useAssets, Exception innerExc = null) :
				base(unit, message, useAssets, innerExc)
			{ }

			public ArgumentAfterArgumentList(string argument, Exception innerExc = null) :
				base(UnitCommandLine._, innerExc, true, Messages.ArgumentAfterArgumentList, argument)
			{
			}
		}

		public class InvalidArgumentProcessor : DwarfException
		{
			public InvalidArgumentProcessor(Dwarf.Unit unit, string message, bool useAssets, Exception innerExc = null) :
				base(unit, message, useAssets, innerExc)
			{ }

			public InvalidArgumentProcessor(string method, Exception innerExc = null) :
				base(UnitCommandLine._, innerExc, true, Messages.InvalidArgumentProcessor, method)
			{
			}
		}

		/// <summary>
		/// Error messages
		/// </summary>
		public static class Messages
		{
			public const string UnknownOption				= nameof(UnknownOption); // option name
			public const string DuplicateOption				= nameof(DuplicateOption); // option name
			public const string MissingOptionValue			= nameof(MissingOptionValue); // option name
			public const string InvalidOptionValue			= nameof(InvalidOptionValue); // option name
			public const string InvalidOptionType			= nameof(InvalidOptionType); // option name
			public const string InvalidArgumentType			= nameof(InvalidArgumentType); // argument name
			public const string RequiredArgumentIsMissing	= nameof(RequiredArgumentIsMissing); // argument name
			public const string RequiredOptionIsMissing		= nameof(RequiredOptionIsMissing); // option name
			public const string ArgumentAfterArgumentList	= nameof(ArgumentAfterArgumentList); // argument name
			public const string ArgumentListInvalidType		= nameof(ArgumentListInvalidType); // argument name
			public const string InvalidArgumentProcessor	= nameof(InvalidArgumentProcessor); // method name
			public const string ConfigFileNotFound			= nameof(ConfigFileNotFound); // file name
			public const string CantCreateConfig			= nameof(CantCreateConfig); // file name
			public const string OptionGroupWithoutName		= nameof(OptionGroupWithoutName); // file name
		}

	}

	#region UnitCommandLine
	public sealed class UnitCommandLine : ClassUnit
	{
		private UnitCommandLine() : base(typeof(CommandLine), UnitUtility._)
		{
#if INIT_DEFAULT_MESSAGES
			AssetMgr.SetDefaultStrings(
				CommandLine.Messages.UnknownOption, "Unknown option '{0}'.", // option name
				CommandLine.Messages.DuplicateOption, "Duplicate option '{0}'.", // option name
				CommandLine.Messages.MissingOptionValue, "Missing value for option '{0}'.", // option name
				CommandLine.Messages.InvalidOptionValue, "Invalid value for option '{0}'.", // option name
				CommandLine.Messages.InvalidOptionType, "Invalid type for option '{0}'.", // option name
				CommandLine.Messages.InvalidArgumentType, "Invalid type for option '{0}'.", // argument name
				CommandLine.Messages.RequiredArgumentIsMissing, "Required argument <{0}> is missing.", // argument name
				CommandLine.Messages.RequiredOptionIsMissing, "Required option {0} is missing.", // option name
				CommandLine.Messages.ArgumentAfterArgumentList, "Argument <{0}> after argument list.", // argument name
				CommandLine.Messages.ArgumentListInvalidType, "Type of argument list property <{0}> must be List<string>.", // argument name
				CommandLine.Messages.InvalidArgumentProcessor, "Invalid argument process method {0}, must accept and return string[].", // method name
				CommandLine.Messages.ConfigFileNotFound, "Configuration file {0} not found.", // file name
				CommandLine.Messages.CantCreateConfig, "Can not create configuration from file {0}.", // file name
				CommandLine.Messages.OptionGroupWithoutName, "Option group without name." //
			);
#endif
		}
		public static readonly UnitCommandLine _ = new UnitCommandLine();
		public static UnitCommandLine Instance => _;
	}
	#endregion

	#region UnitCommanLineIArgument
	public sealed class UnitCommanLineIArgument : InterfaceUnit
	{
		private UnitCommanLineIArgument() : base(typeof(CommandLine.IArgument), UnitCommandLine._) { }
		public static readonly UnitCommanLineIArgument _ = new UnitCommanLineIArgument();
		public static UnitCommanLineIArgument Instance => _;
	}
	#endregion

	#region UnitCommanLineIArgumentList
	public sealed class UnitCommanLineIArgumentList : InterfaceUnit
	{
		private UnitCommanLineIArgumentList() : base(typeof(CommandLine.IArgumentList), UnitCommandLine._) { }
		public static readonly UnitCommanLineIArgumentList _ = new UnitCommanLineIArgumentList();
		public static UnitCommanLineIArgumentList Instance => _;
	}
	#endregion

	#region UnitCommanLineIOption
	public sealed class UnitCommanLineIOption : InterfaceUnit
	{
		private UnitCommanLineIOption() : base(typeof(CommandLine.IOption), UnitCommandLine._) { }
		public static readonly UnitCommanLineIOption _ = new UnitCommanLineIOption();
		public static UnitCommanLineIOption Instance => _;
	}
	#endregion
}
