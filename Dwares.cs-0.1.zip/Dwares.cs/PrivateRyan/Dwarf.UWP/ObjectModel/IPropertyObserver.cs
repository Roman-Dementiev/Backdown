﻿using System;
using System.ComponentModel;


namespace Dwarf.ObjectModel
{
	public interface IPropertyObserver
	{
		void OnPropertyChanged(object sender, PropertyChangedEventArgs e);
	}
}
