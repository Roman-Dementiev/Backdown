﻿using System;
using System.Collections.Generic;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Collections
{
	/// <summary>
	/// Generic class Dict
	/// </summary>
	public class Dict<TKey, TValue> : Dictionary<TKey, TValue>
	{
		#region Properties
		public new TValue this[TKey key] {
			get { return ContainsKey(key) ? base[key] : default(TValue); }
			set { base[key] = value; }
		}
		#endregion

		#region Constructors
		public Dict() { }
		public Dict(int capacity) : base(capacity) { }
		public Dict(IDictionary<TKey, TValue> dict) : base(dict) { }
		public Dict(IEqualityComparer<TKey> comparer) : base(comparer) { }
		public Dict(int capacity, IEqualityComparer<TKey> comparer) : base(capacity, comparer) { }
		public Dict(IDictionary<TKey, TValue> dict, IEqualityComparer<TKey> comparer) : base(dict, comparer) { }
		#endregion
	}

	#region UnitDict
	public sealed class UnitDict : ClassUnit
	{
		private UnitDict() : base(typeof(Dict<,>), UnitCollections._) { }
		public static readonly UnitDict _ = new UnitDict();
		public static UnitDict Instance => _;
	}
	#endregion
}
