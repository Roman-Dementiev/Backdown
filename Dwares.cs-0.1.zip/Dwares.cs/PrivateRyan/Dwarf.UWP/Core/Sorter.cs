﻿using System;
using System.Collections.Generic;


namespace Dwarf
{
	public class Sorter<TItem>
	{
		public Sorter(IComparer<TItem> comparer)
		{
			SetComparer(comparer);
		}

		public Sorter(SortOrder<TItem> sortOrder = null, SortPolicy sortPolicy = SortPolicy.Default)
		{
			SetComparer(null, sortOrder, sortPolicy);
		}

		public object Target => target;
		object target;

		public void SetTarget(IList<TItem> target) => this.target = target;
		public void SetTarget(TItem[] target) => this.target = target;


		public IComparer<TItem> Comparer {
			get => comparer;
			set {
				if (value != comparer) {
					SetComparer(value, sortOrder, sortPolicy);
				}
			}
		}
		IComparer<TItem> comparer;

		public SortOrder<TItem> SortOrder {
			get => sortOrder;
			set {
				if (value != sortOrder) {
					SetComparer(null, value, sortPolicy);
				}
			}
		}
		SortOrder<TItem> sortOrder;

		public SortPolicy SortPolicy {
			get => sortPolicy;
			set {
				if (value != sortPolicy) {
					SetComparer(null, sortOrder, value);
				}
			}
		}
		SortPolicy sortPolicy;

		public virtual void SetComparer(IComparer<TItem> comparer, SortOrder<TItem> sortOrder = null, SortPolicy sortPolicy = SortPolicy.Default)
		{
			if (comparer == null) {
				comparer = Sort.GetDefaultComparer(sortOrder, sortPolicy);
			}
			if (comparer != this.comparer && target != null) {
				SortTarget();
			}

			this.comparer = comparer;
			this.sortOrder = sortOrder;
			this.sortPolicy = sortPolicy;
		}

		public void SortList(IList<TItem> list) => Sort.SortList(list, Comparer);
		public void SortArray(TItem[] array) => Array.Sort(array, Comparer);


		public virtual void SortTarget()
		{
			if (target is IList<TItem> list) {
				SortList(list);
			}
			else if (target is TItem[] array) {
				SortArray(array);
			}
		}

	}

	/*
	public class ListSorter<TItem> : Sorter<TItem>
	{
		public ListSorter(IComparer<TItem> comparer) : 
			this(null, comparer)
		{ }

		public ListSorter(SortOrder<TItem> sortOrder = null, SortPolicy policy = SortPolicy.Default) :
			this(null, sortOrder, policy)
		{ }

		public ListSorter(IList<TItem> target, IComparer<TItem> comparer) : 
			base(comparer)
		{
			SetTarget(target);
		}

		public ListSorter(IList<TItem> target, SortOrder<TItem> sortOrder = null, SortPolicy policy = SortPolicy.Default) :
			base(sortOrder, policy)
		{
			SetTarget(target);
		}

		public override void SortTarget()
		{
			if (Target != null) {
				SortList(Target as IList<TItem>);
			}
		}
	}
	*/
}
