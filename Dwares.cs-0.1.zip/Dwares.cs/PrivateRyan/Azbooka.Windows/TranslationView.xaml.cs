﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Dwarf.UI;
using Dwarf.ObjectModel;
using Dwarf.Collections;
using Dwarf.Platform;


namespace Azbooka
{
	public sealed partial class TranslationView : UserControl, ISourced<Translation>
	{
		EntityChoices<Language> languageChoices;

		public TranslationView()
		{
			this.InitializeComponent();
		}

		public Abc Abc => Abc.Instance;
	
		public Translation Source {
			get => translation;
			set => Init(value);
		}
		Translation translation;

		void Init(Translation translation)
		{
			this.translation = translation;
			if (translation == null)
				return;

			languageChoices = new EntityChoices<Language>(Abc.ActiveLanguages);
			languageChoices.Current = translation.Language;

			lang.Choices = languageChoices;
			text.Text = translation.Text;
		}
	}
}
