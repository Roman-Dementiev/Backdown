﻿using System;
using System.IO;
using System.Reflection;
using Windows.ApplicationModel.Resources;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Media.Imaging;
using Dwarf.Platform;


namespace Dwarf.Extensions
{
	public static partial class Extensions
	{
		public static string GetString(this ResourceLoader loader, string resource, string defaultValue)
		{
			try
			{
				string value = loader.GetString(resource);
				if (String.IsNullOrEmpty(value)) {
					value = defaultValue;
				}
				return value;
			}
			catch {
				return defaultValue;
			}
		}

		public static string[] GetStringSplit(this ResourceLoader loader, string resource, char splitChar)
		{
			try
			{
				string value = loader.GetString(resource);
				if (!String.IsNullOrEmpty(value)) {
					return value.Split(splitChar);
				}
			} catch {
			}
			return new string[0];
		}

		public static void LoadFromStream(this BitmapImage bitmap, Stream input)
		{
			using (var memStream = new MemoryStream())
			{
				input.CopyTo(memStream);
				memStream.Position = 0;

				bitmap.SetSource(memStream.AsRandomAccessStream());
			}
		}

		public static void LoadFromResource(this BitmapImage bitmap, string resourceName, Assembly assemnbly = null)
		{
			using (var input = Appx.GetResourceStream(resourceName, assemnbly))
			{
				LoadFromStream(bitmap, input);
			}
		}

		public static void LoadFromBuffer(this BitmapImage bitmap,  byte[] buffer)
		{
			using (var input = new MemoryStream(buffer))
			{
				bitmap.LoadFromStream(input);
			}
		}
	}
}
