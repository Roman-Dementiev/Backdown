﻿using System;
using System.Reflection;
using Windows.UI.Xaml.Media.Imaging;
using Dwarf.Extensions;


namespace Dwarf.Platform
{
	public class BitmapResource : IBitmapLoader
	{
		string resourceName;
		Assembly assembly;

		public BitmapResource(string resourceName, Assembly assembly = null)
		{
			this.resourceName = resourceName ?? throw new ArgumentNullException(nameof(resourceName));
			this.assembly = assembly;
		}

		public BitmapImage LoadBitmapImage()
		{
			var image = new BitmapImage();
			image.LoadFromResource(resourceName, assembly);
			return image;
		}

		public bool CanLoadData() => true;
		public byte[] LoadBitmapData() => Appx.GetResource(resourceName, assembly);
	}
}
