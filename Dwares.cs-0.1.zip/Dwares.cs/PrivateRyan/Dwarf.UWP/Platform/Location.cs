﻿using System;
using System.Collections.Generic;
using System.IO;


namespace Dwarf.Platform
{
	public class Location : Choice
	{
		protected Location() { }

		public Location(string path) : this(null, path) { }
		
		public Location(Location baseLocation, string path)
		{
			BaseLocation = baseLocation;
			Path = path ?? throw new ArgumentNullException(nameof(path));
		}
		
		public Location(string path, params Location[] baseLocations)
		{
			SelectPath(path, baseLocations);
		}

		public override string ChoiceLabel => DisplayName;
		public override string PopupLabel => RelativePath;
		public override string ChoiceToolTip(ChoiceAppearance appearance) => AbsolutePath;

		public Location BaseLocation { get; protected set; }
		public string Path { get; protected set; }

		public virtual string Root {
			get {
				if (BaseLocation != null) {
					return BaseLocation.Root;
				} else {
					return System.IO.Path.GetPathRoot(AbsolutePath);
				}
			}
		}

		public virtual string AbsolutePath {
			get {
				if (BaseLocation != null) {
					return System.IO.Path.Combine(BaseLocation.AbsolutePath, Path);
				} else {
					return System.IO.Path.GetFullPath(Path);
				}
			}
		}

		public virtual string RelativePath {
			get {
				if (BaseLocation != null) {
					return System.IO.Path.Combine(BaseLocation.RelativePath, Path);
				} else {
					return Path;
				}
			}
		}

		public virtual string DisplayName => GetShortPath(RelativePath, DisplayLength);
		public int DisplayLength { get; set; } = 60;

		public virtual void SelectPath(string path, IEnumerable<Location> baseLocations)
		{
			BaseLocation = SelectBaseLocation(baseLocations, ref path);
			Path = path;
		}

		public static string GetShortPath(string path, int length)
		{
			if (path.Length <= length)
				return path;

			// TODO
			return path;
		}

		public static string NormalizePath(string path, bool addSeparator)
		{
			if (String.IsNullOrEmpty(path))
				return null;

			var normalized =
				System.IO.Path.GetFullPath(path)
				.Replace(System.IO.Path.AltDirectorySeparatorChar, System.IO.Path.DirectorySeparatorChar)
				.ToLower();

			if (addSeparator && normalized[normalized.Length-1] != System.IO.Path.DirectorySeparatorChar)
				normalized += System.IO.Path.DirectorySeparatorChar;
			
			return normalized;
		}

		public static Location SelectBaseLocation(IEnumerable<Location> baseLocations, ref string path)
		{
			string normalizedPath = NormalizePath(path, false);
			if (normalizedPath == null)
				return null;

			Location baseLocation = null;
			int basePathLength = 0;
			foreach (var location in baseLocations)
			{
				var basePath = NormalizePath(location.AbsolutePath, true);
				if (basePath == null)
					continue;

				if (normalizedPath.StartsWith(basePath)) {
					if (basePath.Length > basePathLength) {
						baseLocation = location;
						basePathLength = basePath.Length;
					}
				}
			}

			return baseLocation;
		}
	}
}
