﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading;
//using System.Threading.Tasks;
//using Dwarf.UWP;
//using Windows.Storage;

//namespace Dwarf.Platform
//{
//	public class LibraryLocation : StorageLocation
//	{
//		private LibraryLocation(KnownLibraryId libraryId, StorageLibrary library, string uid = null)
//		{
//			LibraryId = libraryId;
//			Library = library ?? throw new ArgumentNullException(nameof(library));
//			StorageFolder = library.SaveFolder;
//			Uid = uid ?? LibraryName;
//		}

//		public string LibraryName => Uid != null ? Appx.GetString(Uid) : LibraryId.ToString();
//		public KnownLibraryId LibraryId { get; private set; }
//		public StorageLibrary Library { get; private set; }
//		public override string Root => LibraryName;

//		public static LibraryLocation Documents => LazyInitializer.EnsureInitialized(ref documents,
//			() => new LibraryLocation(KnownLibraryId.Documents, StorageLibraries.Documents));
//		static LibraryLocation documents = null;

//		public static LibraryLocation Pictures => LazyInitializer.EnsureInitialized(ref pictures,
//			() => new LibraryLocation(KnownLibraryId.Pictures, StorageLibraries.Pictures));
//		static LibraryLocation pictures = null;

//		public static LibraryLocation Music => LazyInitializer.EnsureInitialized(ref music,
//			() => new LibraryLocation(KnownLibraryId.Music, StorageLibraries.Music));
//		static LibraryLocation music = null;

//		public static LibraryLocation Videos => LazyInitializer.EnsureInitialized(ref videos,
//			() => new LibraryLocation(KnownLibraryId.Videos, StorageLibraries.Videos));
//		static LibraryLocation videos = null;
//	}

//}
