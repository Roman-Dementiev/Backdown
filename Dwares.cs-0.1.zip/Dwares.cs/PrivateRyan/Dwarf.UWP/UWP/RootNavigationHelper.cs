﻿using System;
using Windows.System;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;


namespace Dwarf.UWP
{
	public class RootNavigationHelper : NavigationHelper
	{
		public Page MainPage { get; }

		public RootNavigationHelper(Page mainPage)
		{
			MainPage = mainPage ?? throw new ArgumentNullException(nameof(mainPage));
			Frame = mainPage.Frame;

			RegisterPage(mainPage);

		}

		public RootNavigationHelper(Page mainPage, params INavigationHelper[] additional) :
			this(mainPage)
		{
			AddHelpers(additional);
		}

		public void RegisterPage(Page page)
		{
			// When this page is part of the visual tree make two changes:
			// 1) Map application view state to visual state for the page
			// 2) Handle hardware navigation requests
			page.Loaded += (sender, e) => {
#if WINDOWS_PHONE_APP
				Windows.Phone.UI.Input.HardwareButtons.BackPressed += HardwareButtons_BackPressed;
#else
				// Keyboard and mouse navigation only apply when occupying the entire window
				if (page.ActualHeight == Window.Current.Bounds.Height &&
					page.ActualWidth == Window.Current.Bounds.Width) {
					// Listen to the window directly so focus isn't required
					Window.Current.CoreWindow.Dispatcher.AcceleratorKeyActivated +=
						CoreDispatcher_AcceleratorKeyActivated;
					Window.Current.CoreWindow.PointerPressed +=
						this.CoreWindow_PointerPressed;
				}
#endif
			};

			// Undo the same changes when the page is no longer visible
			page.Unloaded += (sender, e) => {
#if WINDOWS_PHONE_APP
				Windows.Phone.UI.Input.HardwareButtons.BackPressed -= HardwareButtons_BackPressed;
#else
				Window.Current.CoreWindow.Dispatcher.AcceleratorKeyActivated -=
					CoreDispatcher_AcceleratorKeyActivated;
				Window.Current.CoreWindow.PointerPressed -=
					this.CoreWindow_PointerPressed;
#endif
			};
		}

#if WINDOWS_PHONE_APP
        /// <summary>
        /// Invoked when the hardware back button is pressed. For Windows Phone only.
        /// </summary>
        /// <param name="sender">Instance that triggered the event.</param>
        /// <param name="e">Event data describing the conditions that led to the event.</param>
        private void HardwareButtons_BackPressed(object sender, Windows.Phone.UI.Input.BackPressedEventArgs e)
        {
            if (this.GoBackCommand.CanExecute(null))
            {
                e.Handled = true;
                this.GoBackCommand.Execute(null);
            }
        }
#else
		/// <summary>
		/// Invoked on every keystroke, including system keys such as Alt key combinations, when
		/// this page is active and occupies the entire window.  Used to detect keyboard navigation
		/// between pages even when the page itself doesn't have focus.
		/// </summary>
		/// <param name="sender">Instance that triggered the event.</param>
		/// <param name="e">Event data describing the conditions that led to the event.</param>
		private void CoreDispatcher_AcceleratorKeyActivated(CoreDispatcher sender,
			AcceleratorKeyEventArgs e)
		{
			var virtualKey = e.VirtualKey;

			// Only investigate further when Left, Right, or the dedicated Previous or Next keys
			// are pressed
			if ((e.EventType == CoreAcceleratorKeyEventType.SystemKeyDown ||
				e.EventType == CoreAcceleratorKeyEventType.KeyDown) &&
				(virtualKey == VirtualKey.Left || virtualKey == VirtualKey.Right ||
				(int)virtualKey == 166 || (int)virtualKey == 167)) {
				var coreWindow = Window.Current.CoreWindow;
				var downState = CoreVirtualKeyStates.Down;
				bool menuKey = (coreWindow.GetKeyState(VirtualKey.Menu) & downState) == downState;
				bool controlKey = (coreWindow.GetKeyState(VirtualKey.Control) & downState) == downState;
				bool shiftKey = (coreWindow.GetKeyState(VirtualKey.Shift) & downState) == downState;
				bool noModifiers = !menuKey && !controlKey && !shiftKey;
				bool onlyAlt = menuKey && !controlKey && !shiftKey;

				if (((int)virtualKey == 166 && noModifiers) ||
					(virtualKey == VirtualKey.Left && onlyAlt)) {
					// When the previous key or Alt+Left are pressed navigate back
					e.Handled = true;
					this.GoBackCommand.Execute(null);
				} else if (((int)virtualKey == 167 && noModifiers) ||
					  (virtualKey == VirtualKey.Right && onlyAlt)) {
					// When the next key or Alt+Right are pressed navigate forward
					e.Handled = true;
					this.GoForwardCommand.Execute(null);
				}
			}
		}

		/// <summary>
		/// Invoked on every mouse click, touch screen tap, or equivalent interaction when this
		/// page is active and occupies the entire window.  Used to detect browser-style next and
		/// previous mouse button clicks to navigate between pages.
		/// </summary>
		/// <param name="sender">Instance that triggered the event.</param>
		/// <param name="e">Event data describing the conditions that led to the event.</param>
		private void CoreWindow_PointerPressed(CoreWindow sender,
			PointerEventArgs e)
		{
			var properties = e.CurrentPoint.Properties;

			// Ignore button chords with the left, right, and middle buttons
			if (properties.IsLeftButtonPressed || properties.IsRightButtonPressed ||
				properties.IsMiddleButtonPressed)
				return;

			// If back or foward are pressed (but not both) navigate appropriately
			bool backPressed = properties.IsXButton1Pressed;
			bool forwardPressed = properties.IsXButton2Pressed;
			if (backPressed ^ forwardPressed) {
				e.Handled = true;
				if (backPressed)
					this.GoBackCommand.Execute(null);
				if (forwardPressed)
					this.GoForwardCommand.Execute(null);
			}
		}
#endif
	}
}
