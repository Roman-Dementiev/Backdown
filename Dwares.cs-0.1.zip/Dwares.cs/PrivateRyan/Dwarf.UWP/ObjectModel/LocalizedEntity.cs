﻿using System;
using Dwarf.Localization;
using Dwarf.Platform;


namespace Dwarf.ObjectModel
{
	public class LocalizedEntity : ObservableEntity
	{
		public LocalizedEntity(string uid, bool autoLocalize=true) :  base(uid) {}

		public LocalizedEntity(string uid, ObservableEntity entity) :
			base(uid)
		{
			CopyFrom(entity);
		}

		public override string ToString() => LocalizedName;

		public string DefaultName {
			get => name;
			set => Name = value;
		}

		public string LocalizedName {
			get => localizedName;
			set => localizedName.Set(value, () => NotifyPropertyChanged(nameof(Name)));
		}
		protected PropertyValue<string> localizedName;

		public void CopyFrom(LocalizedEntity entity)
		{
			base.CopyFrom(entity);
			localizedName = entity.localizedName;
		}
	}
}
