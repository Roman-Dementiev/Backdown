﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf
{
	/// <summary>
	/// Interface IReleasable
	/// </summary>
	public interface IReleasable
	{
		void ReleaseContent(bool dispose);
	}

	public static class Releasable
	{
		public static readonly string cClearMethod = "Clear";

		public static void ReleaseContent(this IEnumerable enumerabe, bool dispose, bool clear)
		{
			foreach (object obj in enumerabe) {
				obj.Release(dispose);
			}
			if (clear) {
				Reflection.InvokeMethod(enumerabe, cClearMethod, required: false);
			}
		}

		public static void ReleaseContent(this IList list, bool dispose)
		{
			list.ReleaseContent(dispose, false);
			list.Clear();
		}

		public static void ReleaseContent<T>(this Stack<T> stack, bool dispose)
		{
			stack.ReleaseContent(dispose, false);
			stack.Clear();
		}

		public static void ReleaseContent<T>(this Queue<T> queue, bool dispose)
		{
			queue.ReleaseContent(dispose, false);
			queue.Clear();
		}

		public static void ReleaseContent(this IDictionary dict, bool dispose)
		{
			ICollection keys = dict.Keys;
			foreach (object key in keys) {
				dict[key].Release(dispose);
			}
			dict.Clear();
			keys.ReleaseContent(dispose);
		}

		public static void ReleaseContent(this Array array, bool dispose)
		{
			for (int i = 0; i < array.Length; i++) {
				array.GetValue(i).Release(dispose);
				array.SetValue(null, i);
			}
		}

		public static void ReleaseContent(this object obj, bool dispose)
		{
			IReleasable releasabe = obj as IReleasable;
			if (releasabe != null) {
				releasabe.ReleaseContent(dispose);
			} else if (obj is Array) {
				ReleaseContent(obj as Array, dispose);
			} else if (obj is IDictionary) {
				ReleaseContent(obj as IDictionary, dispose);
			} else if (obj is IList) {
				ReleaseContent(obj as IList, dispose);
			} else if (obj is IEnumerable) {
				ReleaseContent(obj as IEnumerable, dispose, true);
			} else {
				Reflection.InvokeMethod(obj, cClearMethod, required: false);
			}
		}

		public static void Release(this object obj, bool dispose)
		{
			obj.ReleaseContent(dispose);
			if (dispose) {
				IDisposable disposable = obj as IDisposable;
				disposable?.Dispose();
			}
		}

		public static void Release<T>(ref T obj, bool dispose) where T : class
		{
			if (obj != null) {
				obj.Release(dispose);
				obj = null;
			}
		}
	}

	#region UnitIReleasable
	public sealed class UnitIReleasable : InterfaceUnit
	{
		private UnitIReleasable() : base(typeof(IReleasable), UnitDwarf._) { }
		public static readonly UnitIReleasable _ = new UnitIReleasable();
		public static UnitIReleasable Instance => _;
	}

	#region UnitExtensions
	public class UnitReleasable : UtilityUnit
	{
		UnitReleasable() : base(typeof(Releasable), UnitDwarf._) { }
		public static readonly UnitReleasable _ = new UnitReleasable();
		public static UnitReleasable Instance => _;
	}
	#endregion
	#endregion
}
