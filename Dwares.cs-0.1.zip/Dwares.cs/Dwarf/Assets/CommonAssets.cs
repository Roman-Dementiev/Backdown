﻿using System;
using System.Collections;
using System.Collections.Generic;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Assets
{
	public class CommonAssets : CultureAssets
	{
		#region Constructors
		public CommonAssets() : base(null) { }
		#endregion

		#region Methods
		public override bool HasAsset(string key, object culture = null)
		{
			if (assets != null) {
				return assets.ContainsKey(key);
			} else {
				return false;
			}
		}

		public override void AddAsset(string key, object asset, object culture = null)
		{
			if (assets == null) {
				assets = new Dictionary<string, object>();
			}
			assets[key] = asset;
		}

		public override object GetAsset(string key, object culture = null)
		{
			if (assets != null) {
				return assets[key];
			} else {
				return null;
			}
		}
		#endregion
	}

	#region UnitCommonAssets
	public sealed class UnitCommonAssets : ClassUnit
	{
		private UnitCommonAssets() : base(typeof(CommonAssets), UnitAssets._) { }
		public static readonly UnitCommonAssets _ = new UnitCommonAssets();
		public static UnitCommonAssets Instance => _;
	}
	#endregion
}
