﻿using System;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml;
using Dwarf;
using Dwarf.UI;


namespace Azbooka
{
	class LanguageViewHelper : EntityListViewHelper<GridView, UserControl, Language>
	{
		public override void ShowPlaceholder(GridView container, UserControl view, Language item)
		{
			base.ShowPlaceholder(container, view, item);

			var nativeName = UI.TextBlock(view, nameof(LanguageView.NativeName));
			var localizedName = UI.TextBlock(view, nameof(LanguageView.LocalizedName));

			nativeName.Opacity = 0;
			localizedName.Opacity = 0;
		}

		public override void ShowPhase(uint phase, GridView container, UserControl view, Language item)
		{
			switch (phase) {
			case 0:
				ShowPlaceholder(container, view, item);
				break;
			case 1:
				ShowNames(view, item);
				break;
			case 2:
				ShowImage(view, item);
				break;
			}
		}

		public void ShowNames(UserControl view, Language item)
		{
			var nativeName = UI.TextBlock(view, nameof(LanguageView.NativeName));
			var localizedName = UI.TextBlock(view, nameof(LanguageView.LocalizedName));

			nativeName.Text = item.NativeName;
			nativeName.Opacity = 1;
			localizedName.Text = item.LocalizedName;
			localizedName.Opacity = 1;
		}
	}
}
