﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Logging
{
	/// <summary>
	/// Interface ILogger
	/// </summary>
	public interface ILogger
	{
		#region Properties
		/// <summary>
		/// Gets or sets the back logger.
		/// </summary>
		/// <value>
		/// The back logger.
		/// </value>
		ILogger BackLogger { get; set; }

		/// <summary>
		/// Gets or sets the log formatter for this instance.
		/// </summary>
		/// <value>
		/// The formatter.
		/// </value>
		ILogFormatter Formatter { get; set; }

		/// <summary>
		/// Gets a value indicating whether this instance or one of back logger has its formatter.
		/// </summary>
		/// <value>
		///   <c>true</c> if there has formatter; otherwise, <c>false</c>.
		/// </value>
		bool CustomFormat { get; }
		#endregion

		#region Methods
		/// <summary>
		/// Writes log message from specified unit.
		/// </summary>
		/// <param name="level">Logging level.</param>
		/// <param name="source">The source.</param>
		/// <param name="message">The message.</param>
		/// <param name="args">The arguments.</param>
		/// <param name="formatted">if set to <c>true</c> message was formatted by <see cref="Log.DefaultFormatter" />.</param>
		void Write(LogLevel level, string source, string message, object[] args, bool formatted);
		#endregion

	}

	#region UnitILogger
	public sealed class UnitILogger : InterfaceUnit
	{
		private UnitILogger() : base(typeof(ILogger), UnitLogging._) {}
		public static readonly UnitILogger _ = new UnitILogger();
		public static UnitILogger Instance => _;
	}
	#endregion
}
