﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing.Gold
{
	/// <summary>
	/// Class DFAStates
	/// </summary>
	public class GoldDfaStates : IDfaStates
	{
		#region Fields
		Grammar.DfaState[] states;
		#endregion

		#region Properties
		public Grammar.DfaState[] GrammarDfaStates => states;
		public int StateCount => states.Length;
		#endregion


		#region Constructors
		public GoldDfaStates(Grammar grammar)
		{
			states = grammar.DfaStates;
		}

		#endregion

		#region Methods
		public bool IsAcceptState(uint state)
		{
			Debug.Assert(state < states.Length);
			return states[state].IsAcceptState;
		}

		public int AcceptSymbol(uint state)
		{
			Debug.Assert(state < states.Length);
			return states[state].IsAcceptState ? states[state].AcceptIndex : GoldSymbols.cNone;
		}

		public uint EdgeCount(uint state)
		{
			Debug.Assert(state < states.Length);
			return (uint)states[state].Edges.Length;
		}

		public uint EdgeCharSet(uint state, uint edge)
		{
			Debug.Assert(state < states.Length);
			return states[state].Edges[edge].charsetIndex;
		}

		public uint EdgeTargetState(uint state, uint edge)
		{
			Debug.Assert(state < states.Length);
			return states[state].Edges[edge].targetIndex;
		}
		#endregion

	}

	#region UnitGoldDfaStates
	public sealed class UnitGoldDfaStates : ClassUnit
	{
		private UnitGoldDfaStates() : base(typeof(GoldDfaStates), UnitGold._) { }
		public static readonly UnitGoldDfaStates _ = new UnitGoldDfaStates();
		public static UnitGoldDfaStates Instance => _;
	}
	#endregion
}
