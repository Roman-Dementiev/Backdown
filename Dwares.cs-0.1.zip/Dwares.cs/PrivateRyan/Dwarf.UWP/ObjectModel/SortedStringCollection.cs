﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dwarf.ObjectModel
{
	public class SortedStringCollection : SortedCollection<string>
	{
		public SortedStringCollection(IComparer<string> comparer, bool uniqueItems = true) :
			this(true, comparer, null, SortPolicy.Default)
		{ }

		public SortedStringCollection(SortOrder<string> sortOrder = null, SortPolicy sortPolicy = SortPolicy.Default) :
			this(true, null, sortOrder, sortPolicy)
		{ }

		public SortedStringCollection(bool uniqueItems, SortOrder<string> sortOrder = null, SortPolicy sortPolicy = SortPolicy.Default) :
			this(uniqueItems, null, sortOrder, sortPolicy)
		{ }

		private SortedStringCollection(bool uniqueItems, IComparer<string> comparer, SortOrder<string> sortOrder, SortPolicy sortPolicy) :
			base(default(None))
		{
			if (comparer == null) {
				comparer = Sort.GetStringComparer(sortOrder, sortPolicy);
			}

			UniqueItems = uniqueItems;
			Sorter = new Sorter<string>(null);
			Sorter.SetComparer(comparer, sortOrder, sortPolicy);
			Sorter.SetTarget(this);
		}
	}
}
