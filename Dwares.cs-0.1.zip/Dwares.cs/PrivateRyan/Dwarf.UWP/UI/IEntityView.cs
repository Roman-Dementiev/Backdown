﻿using System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;

namespace Dwarf.UI
{
	interface IEntityView
	{
		FrameworkElement Indent {  get; }
		Image Image { get; }
		TextBlock Label { get; }
	}


	public static class EntityView
	{
		public static FrameworkElement Indent(UIElement view, bool strict = false)
		{
			if (view is IEntityView entityView) {
				return entityView.Image;
			} else if (strict) {
				return null;
			}

			return UI.Element(view, nameof(IEntityView.Indent));
		}

		public static Image Image(UIElement view, bool strict = false)
		{
			if (view is IEntityView entityView) {
				return entityView.Image;
			} else if (strict) {
				return null;
			}

			return UI.Image(view, nameof(IEntityView.Image));
		}

		public static TextBlock Label(UIElement view, bool strict = false)
		{
			if (view is IEntityView entityView) {
				return entityView.Label;
			} else if (strict) {
				return null;
			}

			return UI.TextBlock(view, nameof(IEntityView.Label));
		}

		public static void SetImageSource(UIElement view, ImageSource imageSource)
		{
			var image = Image(view);
			if (image != null) {
				image.Source = imageSource;
			}
		}

		public static void SetLabelText(UIElement view, string labelText)
		{
			var label = Label(view);
			if (label != null) {
				label.Text = labelText;
			}
		}

	}
}
