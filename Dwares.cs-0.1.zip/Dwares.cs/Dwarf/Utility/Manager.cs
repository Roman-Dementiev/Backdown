﻿using System;
using Dwarf.Collections;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Utility
{
	public enum MakeCurrentMode {
		Push,
		Temp,
		Replace
	}

	/// <summary>
	/// Generic class Manager
	/// </summary>
	public class Manager<TMgr, TManaged, TSource, TDefaultSource> : Linked<TMgr>, IDisposable 
		where TMgr : class, ILinked<TMgr>, new()
		where TManaged : class
		where TSource : class
		where TDefaultSource : TSource, new()
	{
		#region Fields
		protected static TMgr defaultMgr = null;
		protected static TMgr currentMgr = null;
		protected TSource source = null;
		private TMgr prevCurrent = null;
		#endregion

		#region Properties
		public TSource Source => source;

		public static TMgr Default {
			get {
				if (defaultMgr == null) {
					defaultMgr = new TMgr();
				}
				return defaultMgr;
			}
			set {
				Replace(ref currentMgr, defaultMgr, value);
				defaultMgr = value;
			}
		}

		public static TMgr Current {
			get {
				if (currentMgr == null) {
					currentMgr = Default;
				}
				return currentMgr;
			}
			set {
				if (value != null) {
					MakeHead(ref currentMgr, value, MakeCurrentMode == MakeCurrentMode.Push);
				} else {
					currentMgr = Default;
				}
			}
		}

		public static MakeCurrentMode MakeCurrentMode { get; set; } = MakeCurrentMode.Push;
		#endregion

		#region Constructors
		public Manager(TSource source = null)
		{
			this.source = source;
		}

		public Manager(MakeCurrentMode mode, TSource source = null)
		{
			this.source = source;
			MakeCurrent(mode);
		}
		#endregion

		#region Methods
		public virtual void Dispose()
		{
			RestoreCurrent();
			Unlink(ref currentMgr, Default);
			ReleaseManaged();
		}

		public virtual void ReleaseManaged() { }

		public virtual TSource GetSource()
		{
			if (source == null) {
				source = new TDefaultSource();
			}
			return source;
		}

		public void MakeCurrent()
		{
			MakeCurrent(MakeCurrentMode);
		}

		public void MakeCurrent(MakeCurrentMode mode)
		{
			prevCurrent = (mode != MakeCurrentMode.Replace) ? Current : null;
			MakeHead(ref currentMgr, This, mode == MakeCurrentMode.Push);
		}

		public void RestoreCurrent()
		{
			if (this == currentMgr && prevCurrent != null) {
				MakeHead(ref currentMgr, prevCurrent, false);
				prevCurrent = null;
			}
		}

		public static void Push(TMgr mgr)
		{
			MakeHead(ref currentMgr, mgr, true);
		}

		public static TMgr Pop()
		{
			TMgr mgr = Current;
			if (mgr == defaultMgr)
				return null;

			Remove(mgr);
			return mgr;
		}

		public static void Remove(TMgr mgr)
		{
			if (mgr == null || mgr == Default)
				return;

			Unlink(ref currentMgr, mgr);
			if (currentMgr == null) {
				currentMgr = Default;
			}
		}

		public static TManaged GetManaged(Func<TMgr, TManaged> func) => GetFirst(Current, func);
		#endregion

	}

	#region UnitManager
	public sealed class UnitManager : ClassUnit
	{
		private UnitManager() : base(typeof(Manager<,,,>), UnitUtility._) {}
		public static readonly UnitManager _ = new UnitManager();
		public static UnitManager Instance => _;
	}
	#endregion
}
