﻿using System;
using System.Collections.Generic;
using System.Windows.Input;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml;
using Dwarf.ObjectModel;
using Dwarf.Platform;
using Dwarf.UI;


namespace Azbooka
{
	public sealed partial class MeaningView : UserControl, ISourced<Meaning>
	{
		bool isEditing = false;
		EntityListViewHelper<Translation> helper;
		Choices<PoS> PoSChoices;

		public MeaningView()
		{
			this.InitializeComponent();

			helper = new EntityListViewHelper<Translation>() { AdjustWidth = -10 };
			helper.AttachTo(translationList);
		}

		Abc ViewModel => Abc.Instance;

		public Meaning Source {
			get => meaning;
			set => Init(value);
		}
		Meaning meaning;


		void Init(Meaning meaning)
		{
			this.meaning = meaning;
			if (meaning == null)
				return;

			PoS.IsEnabled = false;

			if (meaning is AddMeaningPlaceHolder placeholder) {
				rootGrid.BorderThickness = new Thickness(0);
				meaningGrid.Visibility = Visibility.Collapsed;
				addButton.Visibility = Visibility.Visible;
				addButton.Command = placeholder.Command;
			} else {
				PoSChoices = new Choices<PoS>(PartsOfSpeech.GetLanguagePoSList(meaning.Word.LanguageTag));
				PoSChoices.Current = meaning.PoS;
				PoS.Choices = PoSChoices; //ViewModel.GetPoSChoices(meaning.Word.LanguageTag);

				meaningGrid.Visibility = Visibility.Visible;
				if (meaning.IsEditable) {
					editButton.Visibility = Visibility.Visible;
				} else {
					editButton.Visibility = Visibility.Collapsed;
				}

				translationList.ItemsSource = meaning.Translations;

				UpdateView();

				if (meaning.Text == null) {
					StartEditing();
				}
			}
		}

		void UpdateView()
		{
			index.Text = (meaning.Index + 1).ToString() + ".";
			word.Text = meaning.Word.Text;
			PoSChoices.Current = meaning.PoS;
//			PoS.CurrentChoice = meaning.PoS;
			meaningField.Text = meaning.Text ?? String.Empty;
		}

		void StartEditing()
		{
			if (isEditing)
				return;

			isEditing = true;
			PoS.IsEnabled = true;
			meaningField.IsEnabled = true;
			editButton.Visibility = Visibility.Collapsed;
			acceptButton.Visibility = Visibility.Visible;
			cancelButton.Visibility = meaning.Text != null ? Visibility.Visible : Visibility.Collapsed;
			deleteButton.Visibility = Visibility.Visible;

			meaning.Translations.Add(new Translation());

			meaningField.Focus(FocusState.Programmatic);
		}

		void EndEditing(bool accept, bool delete = false)
		{
			if (!isEditing)
				return;

			isEditing = false;
			PoS.IsEnabled = false;
			meaningField.IsEnabled = false;
			acceptButton.Visibility = Visibility.Collapsed;
			cancelButton.Visibility = Visibility.Collapsed;
			deleteButton.Visibility = Visibility.Collapsed;
			editButton.Visibility = Visibility.Visible;

			if (delete) {
				var meanings = meaning.Word.Meanings;
				meanings.Remove(meaning);
			} else {
				meaning.Translations.RemoveAt(meaning.Translations.Count-1);

				if (accept) {
					meaning.Text = meaningField.Text;
					//meaning.PoS = PoS.CurrentChoice as PoS;
				}

				UpdateView();
			}
		}

		void Delete()
		{
			EndEditing(false, true);
		}

		public RelayCommand EditCommand => RelayCommand.LazyInit(ref editCommand, StartEditing);
		RelayCommand editCommand;

		public RelayCommand AcceptCommand => RelayCommand.LazyInit(ref acceptCommand, () => EndEditing(true));
		RelayCommand acceptCommand;

		public RelayCommand CancelCommand => RelayCommand.LazyInit(ref cancelCommand, () => EndEditing(false));
		RelayCommand cancelCommand;

		public RelayCommand DeleteCommand => RelayCommand.LazyInit(ref deleteCommand, Delete);
		RelayCommand deleteCommand;
	}
}
