﻿using System;
using System.Collections;
using System.Collections.Generic;


namespace Dwarf.Collections
{

	public class ListWrapper<TItem> : IList<TItem>, IReadOnlyList<TItem>
	{
		protected IList<TItem> items;

		public ListWrapper()
		{
			items = new List<TItem>();
		}

		public ListWrapper(IList<TItem> source, bool forReadOnly = true)
		{
			SetSource(source ?? throw new ArgumentNullException(nameof(source)), forReadOnly);
		}

		public ListWrapper(IEnumerable<TItem> items)
		{
			SetItems(items ?? throw new ArgumentNullException(nameof(items)));
		}

		public void SetSource(IList<TItem> source, bool forReadOnly)
		{
			if (source == null) {
				items = new List<TItem>();
			} else if (forReadOnly || !source.IsReadOnly) {
				items = source;
			} else {
				items = new List<TItem>(source);
			} 
		}

		public void SetItems(IEnumerable<TItem> items)
		{
			if (items == null) {
				this.items = new List<TItem>();
			} else {
				this.items = new List<TItem>(items);
			}
		}

		public bool IsReadOnly => items.IsReadOnly;
		public int Count => items.Count;
		public bool Contains(TItem item) => items.Contains(item);
		public int IndexOf(TItem item) => items.IndexOf(item);
		public IEnumerator<TItem> GetEnumerator() => items.GetEnumerator();
		IEnumerator IEnumerable.GetEnumerator() => items.GetEnumerator();

		public TItem this[int index] { 
			get => items[index]; 
			set => items[index] = value;
		}

		public void Clear() => items.Clear();
		public void Add(TItem item) => items.Add(item);
		public void Insert(int index, TItem item) => items.Insert(index, item);
		public bool Remove(TItem item) => items.Remove(item);
		public void RemoveAt(int index) => items.RemoveAt(index);
		public void CopyTo(TItem[] array, int arrayIndex) => items.CopyTo(array, arrayIndex);
	}
}
