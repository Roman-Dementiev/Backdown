﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dwarf.Platform;
using Dwarf.UI;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;


namespace Dwarf.Localization
{
	public partial class Localizer
	{
		bool uiHandlersAdded = false;

		void AddUiHandlers()
		{
			if (uiHandlersAdded)
				return;

			AddHandler(typeof(TextBlock), nameof(TextBlock.Text));
			AddHandler(typeof(ContentControl), nameof(ContentControl.Content));
			AddHandler(typeof(Button), typeof(ContentControl));
			AddHandler(typeof(CheckBox), typeof(ContentControl));
			AddHandler(typeof(RadioButton), typeof(ContentControl));
			AddHandler(typeof(Selector), LocalizeSelector);
			AddHandler(typeof(ComboBox), typeof(Selector));
			AddHandler(typeof(ComboBoxItem), typeof(ContentControl));
			AddHandler(typeof(AppBarButton), nameof(AppBarButton.Label));
			AddHandler(typeof(CommandButton), typeof(AppBarButton));
			AddHandler(typeof(IconButton), typeof(AppBarButton));
			AddHandler(typeof(GlyphButton), typeof(AppBarButton));
			AddHandler(typeof(CommandBar), LocalizeCommandBar);
			AddHandler(typeof(Panel), LocalizePanel);
			AddHandler(typeof(StackPanel), typeof(Panel));
			AddHandler(typeof(Grid), typeof(Panel));
			AddHandler(typeof(UserControl), LocalizeUserControl);
			AddHandler(typeof(Page), typeof(UserControl));
			AddHandler(typeof(SettingsFlyout), LocalizeSettingsFlyout);

			uiHandlersAdded = true;
		}


		public void LocalizeSelector(object target, string uid)
		{
			if (target is Selector selector) {
				var selectedItem = selector.SelectedItem;
				if (selector.ItemsSource != null) {
					var source = selector.ItemsSource;
					selector.ItemsSource = null;
					Localize(source, uid);
					selector.ItemsSource = source;
					selector.SelectedItem = selectedItem;
				} else if (selector.Items != null) {
					selector.SelectedItem = null;
					Localize(selector.Items, uid);
					selector.SelectedItem = selectedItem;
				}
			}
		}

		void LocalizeCommandBar(object target, string uid)
		{
			if (target is CommandBar commandBar) {
				Localize(commandBar.PrimaryCommands);
				Localize(commandBar.SecondaryCommands);
			}
		}

		void LocalizeConten(object target, string uid)
		{
			if (target is Panel panel) {
				Localize(panel.Children);
			}
		}

		void LocalizePanel(object target, string uid)
		{
			if (target is Panel panel) {
				Localize(panel.Children);
			}
		}

		void LocalizeUserControl(object target, string uid)
		{
			if (target is UserControl userControl) {
				var mode = Xaml.Localizer.GetMode(target as Control);
				if (mode == Xaml.LocalizeContentMode.Auto) {
					Localize(userControl.Content);
				}
			}
		}

		void LocalizeSettingsFlyout(object target, string uid)
		{
			if (target is SettingsFlyout setingssetings) {
				setingssetings.Title = Appx.GetString(uid);
				var mode = Xaml.Localizer.GetMode(target as Control);
				if (mode == Xaml.LocalizeContentMode.Auto) {
					Localize(setingssetings.Content);
				}
			}
		}
	}
}
