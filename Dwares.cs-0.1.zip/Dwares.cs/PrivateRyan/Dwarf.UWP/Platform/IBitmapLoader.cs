﻿using System;
using Windows.UI.Xaml.Media.Imaging;


namespace Dwarf.Platform
{
	public interface IBitmapLoader
	{
		BitmapImage LoadBitmapImage();

		bool CanLoadData();
		byte[] LoadBitmapData();
	}
}
