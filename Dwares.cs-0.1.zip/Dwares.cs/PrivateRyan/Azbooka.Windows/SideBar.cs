﻿using System;
using Microsoft.Toolkit.Uwp.UI.Controls;
using Dwarf.Localization;


namespace Azbooka
{
	class SideBar : HamburgerMenu, ILocalizable
	{
		public SideBar() { }

		public void Localize()
		{
			var source = ItemsSource;
			if (source != null) {
				ItemsSource = null;
				Localizer.Localize(source);
				ItemsSource = source;
			}

			source = OptionsItemsSource;
			if (source != null) {
				OptionsItemsSource = null;
				Localizer.Localize(source);
				OptionsItemsSource = source;
			}
		}
	}
}
