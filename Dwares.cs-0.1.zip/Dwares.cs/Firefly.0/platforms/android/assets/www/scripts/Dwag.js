define(["require", "exports", "./Dwog"], function (require, exports, Dwog) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.defaultMessages = {
        failed: "Failed",
        //	checkFailed: "Check for {$} failed",
        truthy: "Check for 'thruthy' failed",
        falsy: "Check for 'falsy' failed",
        equal: "Check for 'equal' failed",
        notEqual: "Check for 'notEqual' failed",
    };
    function defaultMessage(check) {
        if (exports.defaultMessages.hasOwnProperty(check)) {
            return exports.defaultMessages[check];
        }
        if (exports.defaultMessages.hasOwnProperty('checkFailed')) {
            //TODO
        }
        if (exports.defaultMessages.hasOwnProperty('failed')) {
            return exports.defaultMessages['failed'];
        }
        return "Failed";
    }
    exports.defaultMessage = defaultMessage;
    var Unreported = (function () {
        function Unreported() {
        }
        Object.defineProperty(Unreported, "instance", {
            get: function () {
                if (!Unreported._instance) {
                    Unreported._instance = new Unreported();
                }
                return Unreported._instance;
            },
            enumerable: true,
            configurable: true
        });
        Unreported.prototype.onSuccess = function () { };
        Unreported.prototype.onFail = function () { };
        return Unreported;
    }());
    exports.Unreported = Unreported;
    var DwogReporter = (function () {
        function DwogReporter(dwog) {
            this.dwog = dwog;
        }
        Object.defineProperty(DwogReporter, "instance", {
            get: function () {
                if (!DwogReporter._instance) {
                    DwogReporter._instance = new DwogReporter(null);
                }
                return DwogReporter._instance;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwogReporter.prototype, "dwog", {
            get: function () {
                return this._dwog ? this._dwog : Dwog.getDwog();
            },
            set: function (that) {
                this._dwog = that;
            },
            enumerable: true,
            configurable: true
        });
        DwogReporter.prototype.onSuccess = function (message, result) {
            if (message) {
                this.dwog.woof(message);
            }
        };
        DwogReporter.prototype.onFail = function (message, actual, expected) {
            this.dwog.woof(message ? message : "Failed");
        };
        return DwogReporter;
    }());
    exports.DwogReporter = DwogReporter;
    var Dummy = (function () {
        function Dummy() {
            this.truthy = function () { return true; };
            this.falsy = function () { return true; };
            this.equal = function () { return true; };
            this.notEqual = function () { return true; };
        }
        return Dummy;
    }());
    Dummy.instance = new Dummy();
    exports.Dummy = Dummy;
    var Guard = (function () {
        function Guard(reporter) {
            this.reporter = reporter;
        }
        Object.defineProperty(Guard.prototype, "reporter", {
            get: function () {
                return this.ownReporter ? this.ownReporter : Guard.commonReporter ? Guard.commonReporter : Unreported.instance;
            },
            set: function (that) {
                this.ownReporter = that;
            },
            enumerable: true,
            configurable: true
        });
        Guard.prototype.report = function (check, success, actual, expected, failMessage, successMessage) {
            if (success) {
                this.reporter.onSuccess(successMessage, actual);
                return true;
            }
            else {
                if (!failMessage) {
                    failMessage = defaultMessage(check);
                }
                this.reporter.onFail(failMessage, actual, expected);
                return false;
            }
        };
        Guard.prototype.truthy = function (arg, message) {
            var success = !!arg;
            return this.report('truthy', success, arg, '-truthy-', message);
        };
        Guard.prototype.falsy = function (arg, message) {
            var success = !arg;
            return this.report('falsy', success, arg, '-falsy-', message);
        };
        Guard.prototype.equal = function (actual, expected, message) {
            var success = (actual == expected);
            return this.report('equal', success, actual, expected, message);
        };
        Guard.prototype.notEqual = function (actual, expected, message) {
            var success = (actual != expected);
            return this.report('notEqual', success, actual, expected, message);
        };
        return Guard;
    }());
    Guard.commonReporter = DwogReporter.instance;
    exports.Guard = Guard;
    exports.expect = new Guard();
    exports.assert = Dummy.instance;
    function enableAssert() {
        exports.assert = exports.expect;
    }
    exports.enableAssert = enableAssert;
    function disableAssert() {
        exports.assert = Dummy.instance;
    }
    exports.disableAssert = disableAssert;
});
//# sourceMappingURL=Dwag.js.map