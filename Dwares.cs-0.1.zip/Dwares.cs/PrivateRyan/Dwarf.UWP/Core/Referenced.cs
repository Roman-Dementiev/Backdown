﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dwarf
{
	public class Referenced : IReferenced
	{
		public uint RefCount => refCount;
		uint refCount = 0;

		public void AddRef(object @ref) => refCount++;
		public void RemoveRef(object @ref)
		{
			if (refCount > 0) {
				refCount--;
			} else {
				Debug.Print("Referenced: removing unexisting reference");
			}
		}
	}
}
