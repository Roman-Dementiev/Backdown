﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing
{
	/// <summary>
	/// Interface ICharSets
	/// </summary>
	public interface ICharSets
	{
		#region Properties
		int CharSetCount { get; }
		#endregion

		#region Methods
			CharSet GetCharSet(uint charsetIndex);
	bool CharInCharset(char ch, uint charsetIndex);
		#endregion
	}

	#region UnitICharSets
	public sealed class UnitICharSets : InterfaceUnit
	{
		private UnitICharSets() : base(typeof(ICharSets), UnitParsing._) { }
		public static readonly UnitICharSets _ = new UnitICharSets();
		public static UnitICharSets Instance => _;
	}
	#endregion
}
