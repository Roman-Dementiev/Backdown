﻿using System;
using Dwarf.Utility;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing
{
	/// <summary>
	/// Class Token
	/// </summary>
	public class Token
	{
		public TextPosition Position { get; set; }
		public int Symbol { get; set; }
		public object Object { get; set; }

		public Token() : this(-1) { }

		public Token(int sym, object obj = null)
		{
			Position = TextPosition.None;
			Symbol = sym;
			Object = obj;
		}

		public void Set(int sym, object obj = null)
		{
			Symbol = sym;
			Object = obj;
		}

		public void SetEOF() => Set(Symbols.cEOF, null);
		public void SetError(DwarfException exc) => Set(Symbols.cError, exc);
	}

	#region UnitToken
	public sealed class UnitToken : ClassUnit
	{
		private UnitToken() : base(typeof(Symbols), UnitParsing._) { }
		public static readonly UnitToken _ = new UnitToken();
		public static UnitToken Instance => _;
	}
	#endregion
}
