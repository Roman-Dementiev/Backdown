﻿using System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace Dwarf.Xaml
{
	public enum LocalizeContentMode
	{
		Explicit,
		Auto
	}

	public class Localizer
	{
		public static readonly DependencyProperty ModeProperty = DependencyProperty.RegisterAttached(
			"Mode",
			typeof(LocalizeContentMode),
			typeof(Localizer),
			new PropertyMetadata(LocalizeContentMode.Explicit)
		);
		public static void SetMode(Control control, LocalizeContentMode mode) => control.SetValue(ModeProperty, mode);
		public static LocalizeContentMode GetMode(Control control) => (LocalizeContentMode)control.GetValue(ModeProperty);

		public static readonly DependencyProperty UidProperty = DependencyProperty.RegisterAttached(
			"Uid",
			typeof(string),
			typeof(Localizer),
			null
		);
		public static void SetUid(DependencyObject obj, string uid) => obj.SetValue(UidProperty, uid);
		public static string GetUid(DependencyObject obj) => (string)obj.GetValue(UidProperty);

		public static readonly DependencyProperty LocalizableProperty = DependencyProperty.RegisterAttached(
			"Localizable",
			typeof(string),
			typeof(Localizer),
			null
		);
		public static void SetLocalizable(DependencyObject obj, string propertyName) => obj.SetValue(LocalizableProperty, propertyName);
		public static string GetLocalizable(DependencyObject obj) => (string)obj.GetValue(LocalizableProperty);
	}
}
