﻿using System.IO;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Utility
{
	/// <summary>
	/// Generic Interface ITextProcessor
	/// </summary>
	/// <typeparam name="TResult">The type of the result.</typeparam>
	public interface ITextProcessor<TResult>
	{
		#region Properties
		/// <summary>
		/// Gets the reader.
		/// </summary>
		/// <value>
		/// The source.
		/// </value>
		TextReader Reader { get; }

		/// <summary>
		/// Gets the source.
		/// </summary>
		/// <value>
		/// The source.
		/// </value>
		TextSource Source { get; }

		/// <summary>
		/// Gets the result.
		/// </summary>
		/// <value>
		/// The result.
		/// </value>
		TResult Result { get; }

		/// <summary>
		/// Gets the error exception.
		/// </summary>
		/// <value>
		/// The error.
		/// </value>
		DwarfException ErrorOccured { get; }

		/// <summary>
		/// Gets or sets a value indicating whether the <see cref="Try"/> returns <see cref="ErrorOccured"/>.
		/// </summary>
		/// <value>
		/// <c>true</c> if the TryProcess returns exceptions;
		/// <c>false</c> if it returns null in case of error.
		/// </value>
		bool ReturnErrors { get; set; }
		#endregion

		#region Events
		/// <summary>
		/// Fired when error occurs.
		/// </summary>
		event ExceptionHandler OnError;
		#endregion

		#region Methods
		/// <summary>
		/// Prepare for processing input from the reader.
		/// </summary>
		/// <param name="source">The buffer.</param>
		void Prepare(TextReader reader);

		/// <summary>
		/// Prepare for processing input from the source.
		/// </summary>
		/// <param name="source">The source.</param>
		void Prepare(TextSource source);

			/// <summary>
		/// Processes the text input from the <see cref="Source" />.
		/// </summary>
		/// <returns>The result of processing</returns>
		TResult Process();

		/// <summary>
		/// Tries to prepare and process input from the reader.
		/// </summary>
		/// <param name="source">The source.</param>
		/// <returns>
		///  <see cref="Result"/> if processed successfully;
		///  otherwise <see cref="ErrorOcuured"/> when <see cref="ReturnErrors"/> is <c>true</c> or <c>null</c> when <see cref="ReturnErrors"/> is false.
		/// </returns>
		object Try(TextReader reader);
		#endregion
	}

	#region UnitITextProcessor
	public sealed class UnitITextProcessor : InterfaceUnit
	{
		private UnitITextProcessor() : base(typeof(ITextProcessor<>), UnitUtility._) { }
		public static readonly UnitITextProcessor _ = new UnitITextProcessor();
		public static UnitITextProcessor Instance => _;
	}
	#endregion
}
