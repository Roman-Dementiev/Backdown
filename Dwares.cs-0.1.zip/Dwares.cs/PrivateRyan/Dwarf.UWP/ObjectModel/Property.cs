﻿//using System;
//using System.ComponentModel;


//namespace Dwarf.ObjectModel
//{
//	public class Property_<TValue>
//	{
//		protected TValue value;

//		public Property_(string propertyName, TValue value, object owner = null, bool propagate = false)
//		{
//			Name = propertyName ?? throw new ArgumentNullException(nameof(propertyName));
//			this.value = value;
//			Owner = owner;
//			Propagate = propagate;
//		}

//		public Type PropertyType => typeof(TValue);
//		public string Name { get; }
//		public object Owner { get; private set; }
//		public bool Propagate { get; private set; }

//		public void SetValue(TValue value)
//		{
//			this.value = value;
//			if (Owner != null) {
//				if (Owner is IPropertyNotifier notifier) {
//					notifier.NotifyPropertyChanged(Name);
//				}
//				if (Propagate && Owner is IPropagating propagating) {
//					propagating.PropagateProperty(Name, value);
//				}
//			}
//		}

//		public void SetOwner(object owner, bool propagatable = false)
//		{
//			Owner = owner;
//			Propagate = propagatable;
//		}
//	}

//	public class Property<TValue> : Property_<TValue> where TValue : class
//	{
//		public Property(string propertyName, object owner = null, bool propagate = false) :
//			base(propertyName, null, owner, propagate)
//		{ }

//		public Property(string propertyName, TValue value, object owner = null, bool propagate = false) :
//			base(propertyName, value, owner, propagate)
//		{ }

//		public TValue Value {
//			get => value;
//			set {
//				if (value != this.value) {
//					SetValue(value);
//				}
//			}
//		}

//		public static implicit operator TValue(Property<TValue> propery) => propery.value;
//	}


//	public class NullableProperty<TValue> : Property_<TValue?> where TValue : struct
//	{
//		public NullableProperty(string propertyName, object owner = null, bool propagate = false) :
//			base(propertyName, null, owner, propagate)
//		{ }

//		public NullableProperty(string propertyName, TValue value, object owner = null, bool propagate = false) :
//			base(propertyName, (TValue?)value, owner, propagate)
//		{ }

//		public NullableProperty(string propertyName, TValue? value, object owner = null, bool propagate = false) :
//			base(propertyName, (TValue?)value, owner, propagate)
//		{ }

//		public TValue? Nullable {
//			get => value;
//			set {
//				if (!System.Nullable.Equals(value, this.value)) {
//					SetValue(value);
//				}
//			}
//		}

//		public TValue Value {
//			get => (value != null) ? (TValue)value : default(TValue);
//			set {
//				if (this.value == null || !value.Equals((TValue)this.Value)) {
//					SetValue(value);
//				}
//			}
//		}

//		public static implicit operator TValue? (NullableProperty<TValue> propery) => propery.Nullable;
//		public static implicit operator TValue(NullableProperty<TValue> propery) => propery.Value;
//	}

//	public class NotNullableProperty<TValue> : Property_<TValue> where TValue : struct
//	{
//		public NotNullableProperty(string propertyName, TValue value, object owner = null, bool propagate = false) :
//			base(propertyName, value, owner, propagate)
//		{ }

//		public TValue Value {
//			get => value;
//			set {
//				if (!value.Equals(this.value)) {
//					SetValue(value);
//				}
//			}
//		}

//		public static implicit operator TValue(NotNullableProperty<TValue> propery) => propery.Value;
//	}
//}
