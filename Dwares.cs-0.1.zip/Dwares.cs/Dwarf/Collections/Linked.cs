﻿using System;
using System.Collections.Generic;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Collections
{
	/// <summary>
	/// Generic interface ILinked
	/// </summary>
	public interface ILinked<TLinked> where TLinked : class
	{
		#region Properties
		TLinked This { get; }
		TLinked Link { get; set; }
		#endregion

		#region Methods
//		void MakeHead(ref TLinked head, bool linkIn = true);
//		void LinkIn(ref TLinked head, TLinked linked);
//		void Unlink(ref TLinked head, TLinked defaultHead = null);
//		TLinked GetLinked(TLinked head);
		#endregion
	}

	/// <summary>
	/// Generic class Linked
	/// </summary>
	public class Linked<TLinked> : ILinked<TLinked> where TLinked : class, ILinked<TLinked>
	{
		#region Properties
		public TLinked This => this as TLinked;
		public TLinked Link { get; set; }
		#endregion

		#region Constructors
		public Linked() { }

		public Linked(ref TLinked head, bool linkIn = true)
		{
			MakeHead(ref head, This, linkIn);
		}
		#endregion

		#region Methods
		public void LinkIn(ref TLinked head, TLinked linked) => LinkIn(ref head, this, linked);
		public bool Unlink(ref TLinked head) => Unlink(ref head, this);
		public TLinked GetLinked(TLinked head) => GetLinked(head, this);
		public bool IsLinked(TLinked head) => GetLinked(head, this) != null;
		#endregion

		#region Static Methods
		public static int GetCount(TLinked head)
		{
			int count = 0;
			for (TLinked linked = head; linked != null; linked = linked.Link) {
				count++;
			}
			return count;
		}

		public static TLinked GetLast(TLinked head)
		{
			TLinked last = null, link = head;
			while (link != null) {
				last = link;
				link = link.Link;
			}
			return last;
		}

		public static int GetIndex(TLinked head, ILinked<TLinked> node)
		{
			int i = 0;
			for (TLinked link = head; link != null; link = link.Link, i++) {
				if (link == node)
					return i;
			}
			return -1;
		}

		public static TLinked GetAt(TLinked head, int index)
		{
			if (index >= 0 && head != null) {
				int i = 0;
				for (TLinked link = head; link != null; link = link.Link, i++) {
					if (i == index)
						return link;
				}
			}
			throw new IndexOutOfRangeException();
		}


		public static TLinked GetLinked(TLinked head, ILinked<TLinked> node) =>
			FindFirst(head, linked => (linked.Link == node));

		protected static void MakeHead(ref TLinked head, TLinked node, bool linkIn = true)
		{
			if (node == null) {
				throw new ArgumentNullException(nameof(node));
			}
			if (node == head)
				return;

			TLinked linked = GetLinked(head, node);
			if (linked != null) {
				linked.Link = node.Link;
			}
			node.Link = linkIn ? head : null;
			head = node;
		}


		public static void LinkIn(ref TLinked head, ILinked<TLinked> node, ILinked<TLinked> linked)
		{
			if (linked == null) {
				node.Link = head;
				head = node.This;
			} else {
				node.Link = linked.Link;
				linked.Link = node.This;
			}
		}

		public static bool Unlink(ref TLinked head, ILinked<TLinked> node)
		{
			if (node == null) {
				throw new ArgumentNullException(nameof(node));
			}

			if (node == head) {
				head = node.Link;
			} else {
				TLinked linked = GetLinked(head, node);
				if (linked == null)
					return false;

				linked.Link = node.Link;
			}
			node.Link = null;
			return true;
		}

		protected static void ReplaceNode(ref TLinked head, TLinked node, TLinked linked, TLinked newNode)
		{
			newNode.Link = node.Link;
			if (linked == null) {
				head = newNode;
			} else {
				linked.Link = newNode;
			}
			node.Link = null;
		}

		public static void Replace(ref TLinked head, int index, TLinked newNode)
		{
			if (index >= 0 && head != null) {
				int i = 0;
				for (TLinked linked = null, node = head; node != null; node = node.Link, i++) {
					if (i == index) {
						ReplaceNode(ref head, node, linked, newNode);
						return;
					}
					linked = node;
				}
			}
			throw new IndexOutOfRangeException();
		}

		public static bool Replace(ref TLinked head, TLinked node, TLinked newNode)
		{
			if (node == null) {
				throw new ArgumentNullException(nameof(node));
			}

			if (head == null)
				return false;

			if (newNode == null) {
				Unlink(ref head, node);
				return true;
			}

			for (TLinked linked = null, link = head; link != null; link = link.Link)
			{
				if (link == node) {
					ReplaceNode(ref head, node, linked, newNode);
					return true;
				}
				linked = link;
			}

			return false;
		}

		public static bool Contains(TLinked head, TLinked node) =>
			FindFirst(head, linked => linked == node) != null;

		public static TLinked FindFirst(TLinked head, Func<TLinked, bool> func)
		{
			for (TLinked linked = head; linked != null; linked = linked.Link) {
				if (func(linked))
					return linked;
			}
			return null;
		}

		public static TLinked FindLast(TLinked head, Func<TLinked, bool> func)
		{
			TLinked last = null;
			for (TLinked linked = head; linked != null; linked = linked.Link) {
				if (func(linked))
					last = linked;
			}
			return last;
		}

		public static List<TLinked> FindAll(TLinked head, Func<TLinked, bool> func)
		{
			var list = new List<TLinked>();
			for (TLinked linked = head; linked != null; linked = linked.Link) {
				if (func(linked))
					list.Add(linked);
			}
			return list;
		}

		public static TResult GetFirst<TResult>(TLinked head, Func<TLinked, TResult> func) where TResult : class
		{
			for (TLinked linked = head; linked != null; linked = linked.Link)
			{
				TResult result = func(linked);
				if (result != null)
					return result;
			}
			return null;
		}

		public static TResult GetLast<TResult>(TLinked head, Func<TLinked, TResult> func) where TResult : class
		{
			TResult last = null;
			for (TLinked linked = head; linked != null; linked = linked.Link) {
				TResult result = func(linked);
				if (result != null)
					last = result;
			}
			return last;
		}

		public static List<TResult> GetAll<TResult>(TLinked head, Func<TLinked, TResult> func) where TResult : class
		{
			var list = new List<TResult>();
			for (TLinked linked = head; linked != null; linked = linked.Link) {
				TResult result = func(linked);
				if (result != null)
					list.Add(result);
			}
			return list;
		}

		public static void ForEach(TLinked head, Action<TLinked> action)
		{
			for (TLinked linked = head; linked != null; linked = linked.Link) {
				action(linked);
			}
		}
		#endregion
	}

	#region UnitIManager
	public sealed class UnitILinked : InterfaceUnit
	{
		private UnitILinked() : base(typeof(ILinked<>), UnitCollections._) { }
		public static readonly UnitILinked _ = new UnitILinked();
		public static UnitILinked Instance => _;
	}
	#endregion

	#region UnitLinked
	public sealed class UnitLinked : ClassUnit
	{
		private UnitLinked() : base(typeof(Linked<>), UnitCollections._) { }
		public static readonly UnitLinked _ = new UnitLinked();
		public static UnitLinked Instance => _;
	}
	#endregion
}
