﻿using System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Toolkit.Uwp.UI;
using Dwarf.Platform;
using Dwarf;
using Dwarf.UI;
using Dwarf.UWP;
using Dwarf.Localization;


namespace Azbooka
{
	public sealed partial class MainPage : Page, ILocalizable
	{
		Page contentPage = null;
		AutoSuggestBox searchBox = null;
		public SharedCommandBar sharedCommandBar;
		public NavigationHelper navigationHelper;

		public MainPage()
		{
			Localizer.Initialize(this);
			this.InitializeComponent();

			sharedCommandBar = new SharedCommandBar(commandBar, localizable: true);
			navigationHelper = new NavigationHelper(contentFrame, sharedCommandBar);

			sideBar.ItemsSource = ViewModel.Directory;
			//sideBar.OptionsItemsSource = new[]
			//{
			//	new Option { Glyph = "", Name = "More resources", PageType = null/*typeof(About)*/ },
			//	new Option { Glyph = "", Name = "About", PageType = null/*typeof(About)*/ }
			//};	
			ConnectToSearch();

			ViewModel.MainPage = this;
		}

		public Abc ViewModel => Abc.Instance;
		public Frame ContentFrame => contentFrame;
		public Page ContentPage => contentPage;
		//public CommandBar CommandBar => commandBar;
		//public NavigationHelper NavigationHelper => navigationHelper;
		public RelayCommand GoBackCommand => navigationHelper.GoBackCommand;
		public RelayCommand AboutCommand => RelayCommand.LazyInit(ref aboutCommand, ShowAbout);
		RelayCommand aboutCommand = null;

		RelayCommand SettingsCommand => RelayCommand.LazyInit(ref settingsCommand, ShowSettings);
		RelayCommand settingsCommand = null;

		void ShowAbout()
		{
			UI.ShowSettingsFlyout<AboutPanel>();
		}

		void ShowSettings()
		{
			SettingsPanel.ShowIndependent();
		}

		SettingsPanel SettingsPanel => LazyInitializer.EnsureInitialized(ref settingsPanel, () => UI.LocalizedSettingsFlyout<SettingsPanel>(true));
		SettingsPanel settingsPanel = null;

		void ConnectToSearch()
		{
			var searchButton = sideBar.FindDescendantByName("SearchButton") as Button;
			searchBox = sideBar.FindDescendantByName("SearchBox") as AutoSuggestBox;
			if (searchBox == null || searchButton == null)
				return;

			searchButton.Click += async (sender, args) =>
			{
				sideBar.IsPaneOpen = true;
				searchBox.Text = string.Empty;

				// We need to wait for the textbox to be created to focus it (only first time).
				TextBox innerTextbox = null;

				do
				{
					innerTextbox = searchBox.FindDescendant<TextBox>();
					innerTextbox?.Focus(FocusState.Programmatic);

					if (innerTextbox == null)
					{
						await Task.Delay(150);
					}
				}
				while (innerTextbox == null);
			};

			searchBox.DisplayMemberPath = "Name";
			searchBox.TextMemberPath = "Name";

			searchBox.QuerySubmitted += (sender, args) =>
			{
				//NavigationFrame.Navigate(typeof(SamplePicker), _searchBox.Text);
			};

			searchBox.TextChanged += (sender, args) =>
			{
				if (args.Reason != AutoSuggestionBoxTextChangeReason.UserInput)
					return;

				UpdateSearchSuggestions();
			};
		}

		async void UpdateSearchSuggestions()
		{
			//searchBox.ItemsSource = (await Samples.FindSamplesByName(_searchBox.Text)).OrderBy(s => s.Name);
		}

		void SideBar_OnItemClick(object sender, ItemClickEventArgs e)
		{
			var item = e.ClickedItem as DirectoryItem;
			if (item != null && item.PageType != null) {
				contentFrame.Navigate(item.PageType);
			} else {
				contentFrame.Navigate(typeof(BlankPage));
			}
		}

		void SideBar_OnOptionsItemClick(object sender, ItemClickEventArgs e)
		{
			var item = e.ClickedItem as Option;
			if (item == null)
				return;
		}

		public void Localize()
		{
			Localizer.Localize(sideBar);
			Localizer.Localize(sharedCommandBar);

			if (contentPage != null) {
				Localizer.Localize(contentPage);

				var title = Reflection.GetPropertyValue(contentPage, "Title", false) as string;
				pageTitle.Text = title ?? String.Empty;
			} else {
				pageTitle.Text = String.Empty;
			}

			//if (settingsPanel != null) {
			//	Localizer.Localize(settingsPanel);
			//}
		}

		private void ContentFrame_Navigated(object sender, NavigationEventArgs e)
		{
			contentPage = e.Content as Page;
			if (contentPage != null) {
				bool? needGoBack = Reflection.GetPropertyValue(contentPage, "NeedGoBack", false) as bool?;
				back.Visibility = (needGoBack != null && (bool)needGoBack) ? Visibility.Visible : Visibility.Collapsed;

				var title = Reflection.GetPropertyValue(contentPage, "Title", false) as string;
				pageTitle.Text = title ?? String.Empty;

				Localizer.Localize(contentPage);
			} else {
				back.Visibility = Visibility.Collapsed;
				pageTitle.Text = String.Empty;
			}
		}
	}
}
