﻿using System;
using System.Text;
using Dwarf.Config;
using Dwarf.Assets;
using Dwarf.Utility;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing
{
	public class ParserInternalError : DwarfException
	{
		public ParserInternalError(Dwarf.Unit unit = null, Exception innerExc = null) :
			base(unit, Messages.InternalError, true, innerExc)
		{ }

		public ParserInternalError(Dwarf.Unit unit, string message, bool useAssets, Exception innerExc = null) :
			base(unit, message, useAssets, innerExc)
		{ }

		public ParserInternalError(Dwarf.Unit unit, Exception innerExc, bool useAssets, string format, params object[] args) :
			base(unit, innerExc, useAssets, format, args)
		{ }
	}

	public class ParserInitializationError : ParserInternalError
	{
		public ParserInitializationError(Dwarf.Unit unit) :
			base(unit, Messages.IntializationError, true)
		{ }
	}

	public class InvalidParserTable : ParserInternalError
	{
		public InvalidParserTable(Dwarf.Unit unit) :
			base(unit, Messages.InvalidParserTable, true)
		{ }

		public InvalidParserTable(Dwarf.Unit unit, uint state, int symbol, int actionType=-1) :
			base(unit, actionType < 0 ?
				FormatMessage(null, true, Messages.ActionNotFound, symbol, state) :
				FormatMessage(null, true, Messages.InvalidActionType, actionType, state), false)
		{ }
	}

	public class LexerError : DwarfException
	{
		public LexerError(Dwarf.Unit unit, Exception innerExc = null) :
			base(unit, Messages.LexerError, true, innerExc)
		{ }

		public LexerError(Dwarf.Unit unit, string message, bool useAssets, Exception innerExc = null) :
			base(unit, message, useAssets, innerExc)
		{ }

		public LexerError(Dwarf.Unit unit, Exception innerExc, string format, params object[] args) :
			base(unit, innerExc, true, format, args)
		{ }
	}

	public class UnnexpectedEOF : LexerError
	{
		public UnnexpectedEOF(Dwarf.Unit unit, string message, bool useAssets, Exception innerExc = null) :
			base(unit, message, useAssets, innerExc)
		{ }

		public UnnexpectedEOF(Dwarf.Unit unit) :
			base(unit, Messages.UnexpectedEOF, true)
		{ }
	}

	public class UnnexpectedChar : LexerError
	{
		public UnnexpectedChar(Dwarf.Unit unit, string message, bool useAssets, Exception innerExc = null) :
			base(unit, message, useAssets, innerExc)
		{ }

		public UnnexpectedChar(Dwarf.Unit unit, char ch, string after=null) :
			base(unit, FormatMessage(ch, after), false)
		{ }

		public static string FormatMessage(char ch, string after)
		{
			if (String.IsNullOrEmpty(after)) {
				return FormatMessage(null, true, Messages.UnexpectedChar, ch.ToPrintable());
			} else {
				return FormatMessage(null, true, Messages.UnexpectedCharAfter, ch.ToPrintable(), after.ToPrintable());
			}

		}
	}

	public class SyntaxError : DwarfException
	{
		public SyntaxError(Dwarf.Unit unit = null, Exception innerExc = null) :
			base(unit, Messages.SyntaxError, true, innerExc)
		{ }

		public SyntaxError(Dwarf.Unit unit, string message, bool useAssets, Exception innerExc = null) :
			base(unit, message, useAssets, innerExc)
		{ }

		public SyntaxError(Dwarf.Unit unit, Exception innerExc, string format, params object[] args) :
			base(unit, innerExc, true, format, args)
		{ }

		public SyntaxError(Dwarf.Unit unit, string[] expected) :
			base(unit, ExpectedMessage(expected), false)
		{ }

		public static string ExpectedMessage(string[] expected)
		{
			if (expected == null || expected.Length == 0) {
				return Messages.SyntaxError;
			}
			if (expected.Length == 1) {
				return FormatMessage(null, true, Messages.SyntaxExpectedOne, expected[0]);
			}

			StringBuilder sb = new StringBuilder(expected[0]);
			for (int i = 1; i < expected.Length; i++) {
				sb.Append(", ");
				sb.Append(expected[i]);
			}

			return FormatMessage(null, true, Messages.SyntaxExpectedOneOf, sb.ToString());
		}
	}

	/// <summary>
	/// Error message for exceptions
	/// </summary>
	public static class Messages
	{
		public const string InternalError		= nameof(InternalError);
		public const string IntializationError	= nameof(IntializationError);
		public const string InvalidParserTable	= nameof(InvalidParserTable);
		public const string InvalidActionType	= nameof(InvalidActionType); // actionType, state
		public const string ActionNotFound		= nameof(ActionNotFound); // symbol, state
		public const string LexerNotImplemented	= nameof(LexerNotImplemented);
		public const string LexerError			= nameof(LexerError);
		public const string UnexpectedEOF		= nameof(UnexpectedEOF);
		public const string UnexpectedChar		= nameof(UnexpectedChar); // char
		public const string UnexpectedCharAfter	= nameof(UnexpectedCharAfter); // char, string
		public const string SyntaxError			= nameof(SyntaxError);
		public const string SyntaxExpectedOne	= nameof(SyntaxExpectedOne); // expected
		public const string SyntaxExpectedOneOf	= nameof(SyntaxExpectedOneOf); // expected

		public const string InvalidRangeArray = nameof(InvalidRangeArray);
	}

	#region Unit
	public sealed class UnitParsing : NamespaceUnit
	{
		private UnitParsing() : base("Parsing", UnitDwarf._)
		{
#if INIT_DEFAULT_MESSAGES
			AssetMgr.SetDefaultStrings(
				Messages.InternalError, "Parser internal error.",
				Messages.IntializationError, "Parser not initialized.",
				Messages.InvalidParserTable, "Invalid parser table",
				Messages.InvalidActionType, "Invalid parser action {0} for state {1}.", // actionType, state
				Messages.ActionNotFound, "Action for symbol {0} not found in state {1}.", // symbol, state
				Messages.LexerNotImplemented, "Can not create lexer.",
				Messages.LexerError, "Lexical error.",
				Messages.UnexpectedEOF, "Unexpected end of file.",
				Messages.UnexpectedChar, "Unexpected character '{0}'.", // char
				Messages.UnexpectedCharAfter, "Unexpected character '{0}' after \"{1}\".", // char, string
				Messages.SyntaxError, "Syntax error.",
				Messages.SyntaxExpectedOne, "Syntax error; expected {0}.", // expected
				Messages.SyntaxExpectedOneOf, "Syntax error; expected one of {0}.", // expected
				Messages.InvalidRangeArray, "Invalid CharSet range array." 
			);
#endif
		}
		public static readonly UnitParsing _ = new UnitParsing();
		public static UnitParsing Instance => _;
	}
	#endregion
}
