﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing
{
	/// <summary>
	/// Interface IRules
	/// </summary>
	public interface IRules
	{
		#region Properties
		int RulesCount { get; }
		#endregion

		#region Methods
		int GetHeadSymbol(uint rule);
		int GetRuleLength(uint rule);
		int GetRuleSymbol(uint rule, uint index);
		bool IsTrimable(uint rule);
		#endregion
	}

	#region UnitIRules
	public sealed class UnitIRules : InterfaceUnit
	{
		private UnitIRules() : base(typeof(IRules), UnitParsing._) { }
		public static readonly UnitIRules _ = new UnitIRules();
		public static UnitIRules Instance => _;
	}
	#endregion
}