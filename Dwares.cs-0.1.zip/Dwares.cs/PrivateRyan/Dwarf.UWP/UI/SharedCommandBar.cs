﻿using System;
using System.Collections.Generic;
using Windows.Foundation.Collections;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml;
using Dwarf.UWP;
using Dwarf.Localization;

namespace Dwarf.UI
{
	public class SharedCommandBar : INavigationHelper, ILocalizable
	{
		public SharedCommandBar(CommandBar commandBar, bool localizable = false)
		{
			CommandBar = commandBar ?? throw new ArgumentNullException(nameof(commandBar));
			Localizable = localizable;
			DefaultPrimaryCommands = CopyCommands(commandBar.PrimaryCommands);
			DefaultSecondaryCommands = CopyCommands(commandBar.SecondaryCommands);

			if (Localizable) {
				Localizer.Localize(CommandBar);
			}
		}

		public CommandBar CommandBar { get; }
		public bool Localizable { get; }
		public IObservableVector<ICommandBarElement> DefaultPrimaryCommands { get; }
		public IObservableVector<ICommandBarElement> DefaultSecondaryCommands { get; }

		static IObservableVector<ICommandBarElement> CopyCommands(IEnumerable<ICommandBarElement> source, IObservableVector<ICommandBarElement> dest = null)
		{
			if (dest == null) {
				dest = new CommandList();
			} else {
				dest.Clear();
			}

			foreach (var element in source) {
				dest.Add(element);
			}

			return dest;
		}

		public void Localize()
		{
			if (Localizable) {
				Localizer.Localize(CommandBar);
			}
		}

		public void OnNavigatedTo(Page page, NavigationEventArgs e)
		{
			var primaryCommands = GetPrimaryCommands(page);
			var secondaryCommands = GetSecondaryCommands(page);

			if (primaryCommands != null) {
				CopyCommands(primaryCommands, CommandBar.PrimaryCommands);
			}

			if (secondaryCommands != null) {
				CopyCommands(secondaryCommands, CommandBar.SecondaryCommands);
			}

			Localize();
		}

		public void OnNavigatedFrom(Page page, NavigationEventArgs e)
		{
			var primaryCommands = GetPrimaryCommands(page);
			var secondaryCommands = GetSecondaryCommands(page);

			if (primaryCommands != null) {
				CopyCommands(DefaultPrimaryCommands, CommandBar.PrimaryCommands);
			}

			if (secondaryCommands != null) {
				CopyCommands(DefaultSecondaryCommands, CommandBar.SecondaryCommands);
			}

			Localize();
		}

		public void OnNavigatingFrom(Page page, NavigatingCancelEventArgs e) {}


		public static readonly DependencyProperty PrimaryCommandsProperty = DependencyProperty.RegisterAttached(
			"PrimaryCommands",
			typeof(CommandList),
			typeof(SharedCommandBar),
			null
		);

		public static void SetPrimaryCommands(Page page, CommandList commands)
		{
			page.SetValue(PrimaryCommandsProperty, commands);
		}

		public static CommandList GetPrimaryCommands(Page page)
		{
			var list = (CommandList)page.GetValue(PrimaryCommandsProperty);
			//if (list == null) {
			//	list = new CommandList();
			//	page.SetValue(PrimaryCommandsProperty, list);
			//}
			return list;
		}

		public static readonly DependencyProperty SecondaryCommandsProperty = DependencyProperty.RegisterAttached(
			"SecondaryCommands",
			typeof(CommandList),
			typeof(SharedCommandBar),
			null
		);

		public static void SetSecondaryCommands(Page page, CommandList commands)
		{
			page.SetValue(SecondaryCommandsProperty, commands);
		}

		public static CommandList GetSecondaryCommands(Page page)
		{
			var list = (CommandList)page.GetValue(SecondaryCommandsProperty);
			//if (list == null) {
			//	list = new CommandList();
			//	page.SetValue(SecondaryCommandsProperty, list);
			//}
			return list;
		}

	}


public class CommandList : List<ICommandBarElement>, IObservableVector<ICommandBarElement>
	{
		public event VectorChangedEventHandler<ICommandBarElement> VectorChanged;
	}

}
