﻿using System;
using System.Collections;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Assets
{
	/// <summary>
	/// Abstract class BaseAssets
	/// </summary>
	public abstract class BaseAssets : IAssets
	{
		#region Properties
		public object Culture { get; }
		public bool IsMultiCultural { get; }

		public object this[string key, Type type, object culture = null] {
			get { return GetAsset(key, type, culture); }
			set { AddAsset(key, value, culture); }
		}
		#endregion

		#region Constructors
		public BaseAssets(object culture, bool multiCultural)
		{
			Culture = culture;
			IsMultiCultural = multiCultural;
		}
		#endregion

		#region Methods
		public abstract IEnumerable GetCultures();
		public abstract void AddAsset(string key, object asset, object culture = null);
		public abstract object GetAsset(string key, object culture = null);

		public virtual bool HasAsset(string key, object culture = null) =>
			GetAsset(key, culture) != null;

		public virtual object GetAsset(string key, Type type, object culture = null) =>
			GetAsset(this, key, type, culture);

		public static object GetAsset(IAssets assets, string key, Type type, object culture)
		{
			object asset = assets.GetAsset(key, culture);
			if (type == null || type.IsInstanceOfType(asset)) {
				return asset;
			} else {
				Log.Error(UnitBaseAssets._,
					Messages.GetAssetTypeMismatch, key, type.FullName, asset.GetType().FullName);
				return null;
			}
		}

		public virtual void ReleaseAllAssets(bool dispose) { }
		public virtual void ReleaseCultureAssets(object culture, bool dispose) { }
		#endregion

	}

	#region UnitAssets
	public sealed class UnitBaseAssets : ClassUnit
	{
		private UnitBaseAssets() : base(typeof(BaseAssets), UnitAssets._) { }
		public static readonly UnitBaseAssets _ = new UnitBaseAssets();
		public static UnitBaseAssets Instance => _;
	}
	#endregion
}
