﻿using System;
using System.IO;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Logging
{
	/// <summary>
	/// Class FileLogger
	/// </summary>
	public class FileLogger : TextLogger
	{
		#region Properties
		public FileStream Stream { get; }
		public string Name => Stream != null ? Stream.Name : null;
		#endregion

		#region Constructors
		public FileLogger(FileStream stream) :
			base(stream)
		{
			Stream = stream;
		}

		public FileLogger(string filename, FileMode mode = FileMode.Append) :
			this(new FileStream(filename, mode))
		{
		}

		#endregion

		#region Methods
		#endregion

	}

	#region UnitFileLogger
	public sealed class UnitFileLogger : ClassUnit
	{
		private UnitFileLogger() : base(typeof(FileLogger), UnitLogging._) { }
		public static readonly UnitFileLogger _ = new UnitFileLogger();
		public static UnitFileLogger Instance => _;
	}
	#endregion
}
