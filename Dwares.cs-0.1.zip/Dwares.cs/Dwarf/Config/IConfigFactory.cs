﻿using System;
using System.IO;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Config
{
	/// <summary>
	/// Interface IConfigFactory
	/// </summary>
	public interface IConfigFactory
	{
		#region Methods
		IConfig CreateFromFile(string filename);
		IConfig CreateFromStream(Stream stream);
		//TODO: CreateFromAsset, CreateFromText, CreateFromBinary etc.
		#endregion
	}

	#region UnitIConfigFactory
	public sealed class UnitIConfigFactory : InterfaceUnit
	{
		private UnitIConfigFactory() : base(typeof(IConfigFactory), UnitConfig._) { }
		public static readonly UnitIConfigFactory _ = new UnitIConfigFactory();
		public static UnitIConfigFactory Instance => _;
	}
	#endregion
}
