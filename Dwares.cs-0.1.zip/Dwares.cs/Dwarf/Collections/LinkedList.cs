﻿using System;
using System.Collections.Generic;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Collections
{
	/// <summary>
	/// Generic class LinkedList
	/// </summary>
	public class LinkedList<TLinked> : LinkedCollection<TLinked>, IList<TLinked>
		where TLinked : class, ILinked<TLinked>
	{
		#region Fields
		#endregion

		#region Properties
		public TLinked this[int index] {
			get { return Linked<TLinked>.GetAt(head, index); }
			set { Linked<TLinked>.Replace(ref head, index, value); }
		}

		#endregion

		#region Constructors
		public LinkedList(TLinked head = null) : base(head) { }
		#endregion

		#region Methods
		public int IndexOf(TLinked node) => Linked<TLinked>.GetIndex(head, node);

		public void Insert(int index, TLinked node)
		{
			Debug.Assert(node.Link == null);

			if (index < 0) {
				throw new IndexOutOfRangeException();
			}
			if (node == null) {
				throw new ArgumentNullException(nameof(node));
			}

			if (index == 0) {
				node.Link = head;
				head = node;
			} else {
				TLinked linked = this[index-1];
				node.Link = linked.Link;
				linked.Link = node;
			}
		}

		public void RemoveAt(int index)
		{
			if (index < 0) {
				throw new IndexOutOfRangeException();
			}

			TLinked node;
			if (index == 0) {
				node = head;
				head = node.Link;
			} else {
				TLinked linked = this[index-1];
				node = linked.Link;
				linked.Link = node.Link;
			}
			node.Link = null;
		}
		#endregion

	}

	#region UnitLinkedList
	public sealed class UnitLinkedList : ClassUnit
	{
		private UnitLinkedList() : base(typeof(LinkedList<>), UnitCollections._) { }
		public static readonly UnitLinkedList _ = new UnitLinkedList();
		public static UnitLinkedList Instance => _;
	}
	#endregion
}
