﻿using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Windows.Storage;
using Windows.System;
using Dwarf.Extensions;


namespace Dwarf.Platform
{
	public class StorageLocation : Location
	{
		public StorageLocation(StorageFolder folder, string path = null)
		{
			StorageFolder = folder ?? throw new ArgumentNullException(nameof(folder));
			Path = path;
		}

		public StorageLocation(StorageLocation baseLocation, string path)
		{
			BaseLocation = baseLocation ?? throw new ArgumentNullException(nameof(baseLocation));
			StorageFolder = baseLocation.StorageFolder;
			Path = path;
		}

		public new StorageLocation BaseLocation {
			get => base.BaseLocation as StorageLocation;
			set => base.BaseLocation = value;
		}

		public StorageFolder StorageFolder { get; private set; }
		public string StorageFolderPath {
			get {
				var path = StorageFolder.Path;
				if (String.IsNullOrEmpty(path)) {
					path = StorageFolder.Name;
				}
				return path;
			}
		}

		public override string Root => StorageFolder.Name;

		public override string AbsolutePath {
			get {
				if (BaseLocation != null) {
					return System.IO.Path.Combine(BaseLocation.AbsolutePath, Path);
				} else if (Path != null) {
					return System.IO.Path.Combine(StorageFolderPath, Path);
				} else {
					return StorageFolderPath;
				}
			}
		}

		public override string RelativePath {
			get {
				if (BaseLocation != null) {
					return System.IO.Path.Combine(BaseLocation.RelativePath, Path);
				} else if (Path != null) {
					return System.IO.Path.Combine(StorageFolderPath, Path);
				} else {
					return StorageFolderPath;
				}
			}
		}

		public string FullDisplayName {
			get {
				if (BaseLocation != null) {
					return System.IO.Path.Combine(BaseLocation.FullDisplayName, Path);
				} else if (Path != null) {
					return System.IO.Path.Combine(StorageFolder.DisplayName, Path);
				} else {
					return StorageFolder.DisplayName;
				}
			}
		}

		public override string DisplayName => GetShortPath(FullDisplayName, DisplayLength);

		public static StorageLocation GetKnownFolder(KnownFolderId folderId)
		{
			return new StorageLocation(folderId.GetFolder());
		}

		public static async Task<StorageLocation> GetKnownFolderAsync(User user, KnownFolderId folderId)
		{
			var folder = await KnownFolders.GetFolderForUserAsync(user, folderId);
			return new StorageLocation(folder);
		}

		public static StorageLocation Documents => LazyInitializer.EnsureInitialized(ref documents, () =>
			new StorageLocation(KnownFolders.DocumentsLibrary));
		static StorageLocation documents = null;

		public static StorageLocation LocalFolder => LazyInitializer.EnsureInitialized(ref localFolder, () => 
			new StorageLocation(ApplicationData.Current.LocalFolder));
		static StorageLocation localFolder = null;

		/*
		public StorageLocation SharedLocalFolder => LazyInitializer.EnsureInitialized(ref sharedLocalFolder, () =>
			new StorageLocation(ApplicationData.Current.SharedLocalFolder));
		StorageLocation sharedLocalFolder = null;

		public StorageLocation RoamingFolder => LazyInitializer.EnsureInitialized(ref roamingFolder, () =>
			new StorageLocation(ApplicationData.Current.RoamingFolder));
		StorageLocation roamingFolder = null;

		public StorageLocation TemporaryFolder => LazyInitializer.EnsureInitialized(ref temporaryFolder, () =>
			new StorageLocation(ApplicationData.Current.TemporaryFolder));
		StorageLocation temporaryFolder = null;

		public StorageLocation LocalCacheFolder => LazyInitializer.EnsureInitialized(ref localCacheFolder, () =>
			new StorageLocation(ApplicationData.Current.LocalCacheFolder));
		StorageLocation localCacheFolder = null;

		//public StorageLocation PublisherCacheFolder => LazyInitializer.EnsureInitialized(ref publisherCacheFolder, () =>
		//	new StorageLocation(ApplicationData.Current.GetPublisherCacheFolder(folderName)));
		//StorageLocation publisherCacheFolder = null;
		*/
	}
}
