﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dwarf.Data
{
	public interface IDbManifest
	{
		string ManifestTable { get; }

		Version Version { get; }
		string ContentType { get; }
		string ContentName { get; }
		IEnumerable<string> Tables { get; }
		IEnumerable<string> Metadata { get; }

		string GetSchema(string table);
		string GetMetadata(string name);
		void InitDb(IDb db);
	}
}
