﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Config
{
	/// <summary>
	/// Interface IConfigurable
	/// </summary>
	public interface IConfigurable
	{
		#region Properties
		/// <summary>
		/// Determines whether this instance is configured.
		/// </summary>
		/// <returns><c>true</c> if this instance is configured; otherwise, <c>false</c>.</returns>
		bool IsConfigured { get; }

		/// <summary>
		/// Gets the configuration.
		/// </summary>
		/// <value>
		/// The configuration.
		/// </value>
		IConfig Config { get; }
		#endregion

		/// <summary>
		/// Configures this instance from specified configuration.
		/// </summary>
		/// <param name="config">The configuration.</param>
		void Configure(IConfig config);

		/// <summary>
		/// Configures or reconfigures this instance and optionally it's children.
		/// </summary>
		/// <param name="config">The configuration.</param>
		/// <param name="configureChildren">if set to <c>true</c> configure children of this instance.</param>
		/// <param name="reconfigure">if set to <c>true</c> reconfigure this instance and it's children.</param>
		void Configure(IConfig config, bool configureChildren,  bool reconfigure);

		/// <summary>
		/// Reconfigures this instance and it's children from the same configuration.
		/// </summary>
		void Reconfigure();

		/// <summary>
		/// Sets <see cref="Config"/> to <c>null</c> and optionally reset all values to defaults.
		/// </summary>
		/// <param name="unconfigure">if <c>true</c> sets <see cref="IsConfigured"/> to false and reset default values.</param>
		void ResetConfig(bool unconfigure = false);
	}

	#region UnitIConfigurable
	public sealed class UnitIConfigurable : InterfaceUnit
	{
		private UnitIConfigurable() : base(typeof(IConfigurable), UnitConfig._) { }
		public static readonly UnitIConfigurable _ = new UnitIConfigurable();
		public static UnitIConfigurable Instance => _;
	}
	#endregion
}
