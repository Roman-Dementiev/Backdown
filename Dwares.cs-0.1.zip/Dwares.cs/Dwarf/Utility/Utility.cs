﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Utility
{
	#region Unit
	public sealed class UnitUtility : NamespaceUnit
	{
		private UnitUtility() : base("Utility", UnitDwarf._) { }
		public static readonly UnitUtility _ = new UnitUtility();
		public static UnitUtility Instance => _;
	}
	#endregion
}
