﻿using System;
using System.Collections;
using System.Collections.Generic;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Assets
{
	/// <summary>
	/// Class CultureAsset
	/// </summary>
	public class CultureAssets : BaseAssets
	{
		public static readonly object[] cCommonCultures = new object[1] { null };

		#region Fields
		protected Dictionary<string, object> assets = null;
		protected object[] cultures = null;
		#endregion

		#region Constructors
		public CultureAssets(object culture) :
			base(culture, false)
		{
			if (culture != null) {
				cultures = new object[1] { Culture };
			} else {
				cultures = cCommonCultures;
			}
		}
		#endregion

		#region Methods
		public override IEnumerable GetCultures() => cultures;

		public override bool HasAsset(string key, object culture = null)
		{
			if (assets != null && (culture == null || culture.Equals(Culture))) {
				return assets.ContainsKey(key);
			} else {
				return false;
			}
		}

		public override void AddAsset(string key, object asset, object culture = null)
		{
			if (culture == null || culture.Equals(Culture)) {
				if (assets == null) {
					assets = new Dictionary<string, object>();
				}
				assets[key] = asset;
			}
		}

		public override object GetAsset(string key, object culture = null)
		{
			if (assets != null) {
				return assets[key];
			} else {
				return null;
			}
		}

		public override void ReleaseAllAssets(bool dispose)
		{
			if (assets != null) {
				assets.Release(dispose);
				assets = null;
			}
		}

		public override void ReleaseCultureAssets(object culture, bool dispose)
		{
			if (culture == null || culture.Equals(Culture)) {
				ReleaseAllAssets(dispose);
			}
		}
		#endregion

	}

	#region UnitCultureAsset
	public sealed class UnitCultureAssets : ClassUnit
	{
		private UnitCultureAssets() : base(typeof(CultureAssets), UnitAssets._) { }
		public static readonly UnitCultureAssets _ = new UnitCultureAssets();
		public static UnitCultureAssets Instance => _;
	}
	#endregion
}
