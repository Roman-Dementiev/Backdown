﻿using System;
using Dwarf.Localization;
using Dwarf.ObjectModel;
using Dwarf.Platform;


namespace Azbooka
{
	public class DirectoryItem : LocalizedEntity, ILocalizable
	{
		public DirectoryItem(Type pageType, string uid) :
			base(uid)
		{
			PageType = pageType;
			DefaultName = uid;
			LocalizedName = Appx.GetString(uid);
			Icon = Appx.GetIcon(uid);
		}

		public Type PageType { get; }

		public void Localize()
		{
			LocalizedName = Appx.GetString(uid);
		}
	}
}
