﻿using System;
using System.ComponentModel;
using Dwarf.Localization;
using Dwarf.ObjectModel;


namespace Dwarf.Platform
{
	public class Choice :IChoice, INotifyPropertyChanged
	{
		public event PropertyChangedEventHandler PropertyChanged;

		public Choice() {}

		public string Uid {
			get => uid;
			set => uid.Set(value, NotifyLabelChanged);
		}
		PropertyValue<string> uid;

		public ICommand Command { get; set; }
		public virtual Bitmap ChoiceImage => Bitmap.Null;
		public virtual string ChoiceLabel =>  Uid != null ? Appx.GetString(Uid) : ToString();
		public virtual Bitmap PopupImage => ChoiceImage;
		public virtual string PopupLabel => ChoiceLabel;
		public virtual string ChoiceToolTip(ChoiceAppearance appearance) => appearance.DefaultChoiceTolTip(this);

		protected void NotifyLabelChanged()
		{
			PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(ChoiceLabel));
		}
	}

	public class ChoiceAdapter<TSource> : Choice, ISourced<TSource>
	{
		public ChoiceAdapter(TSource source)
		{
			Source = source;
		}

		public TSource Source { get; set; }
		public override string ToString() => Source != null ? Source.ToString() : base.ToString();
	}
}
