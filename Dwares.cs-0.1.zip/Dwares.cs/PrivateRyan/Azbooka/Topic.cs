﻿using System;
using Dwarf.ObjectModel;


namespace Azbooka
{
	public class Topic : ShelfEntity
	{
		public Topic(string uid) : base(uid) {}
	}
}

