﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing
{
	public delegate object TerminalFactory(int sym, char[] buffer, int start, int length);
	public delegate object NonterminalFactory(uint rule, Token[] tokens, int start, int length);

	/// <summary>
	/// Class TokenFactory
	/// </summary>
	public class TokenFactory : ITokenFactory
	{
		#region Fields
		protected TerminalFactory[] terminals = null;
		protected NonterminalFactory[] nonterminals = null;
		#endregion

		#region Constructors
		protected TokenFactory() { }

		public TokenFactory(uint terminalCount, uint rulesCount)
		{
			Init(terminalCount, rulesCount);
		}

		#endregion

		#region Methods
		protected void Init(uint terminalCount, uint rulesCount)
		{
			terminals = new TerminalFactory[terminalCount];
			nonterminals = new NonterminalFactory[rulesCount];
		}

		public object CreateTerminal(int sym, char[] buffer, int start, int length)
		{
			Debug.Assert(sym >= 0 && sym < terminals.Length);
			return terminals[sym](sym, buffer, start, length);
		}

		public object CreateNonterminal(uint rule, Token[] tokens, int start, int length)
		{
			Debug.Assert(rule < nonterminals.Length);
			return nonterminals[rule](rule, tokens, start, length);
		}
		#endregion

		#region Helper Methods
		public static object @null(int sym, char[] buffer, int start, int length) => null;
		public static object text(int sym, char[] buffer, int start, int length)
			=> new string(buffer, start, length);
		public static object @as<Type>(int sym, char[] buffer, int start, int length)
			=> Convert.ChangeType(new string(buffer, start, length), typeof(Type));

		public static object @null(uint rule, Token[] tokens, int start, int length) => null;
		public static object token0(uint rule, Token[] tokens, int start, int length) => tokens[start].Object;
		public static object token1(uint rule, Token[] tokens, int start, int length) => tokens[start + 1].Object;
		public static object token2(uint rule, Token[] tokens, int start, int length) => tokens[start + 2].Object;
		public static object token3(uint rule, Token[] tokens, int start, int length) => tokens[start + 3].Object;
		public static object token4(uint rule, Token[] tokens, int start, int length) => tokens[start + 4].Object;
		public static object token5(uint rule, Token[] tokens, int start, int length) => tokens[start + 5].Object;
		public static object token6(uint rule, Token[] tokens, int start, int length) => tokens[start + 6].Object;
		public static object token7(uint rule, Token[] tokens, int start, int length) => tokens[start + 7].Object;
		public static object token8(uint rule, Token[] tokens, int start, int length) => tokens[start + 8].Object;
		public static object token9(uint rule, Token[] tokens, int start, int length) => tokens[start + 9].Object;
		#endregion

	}

	#region UnitTokenFactory
	public sealed class UnitTokenFactory : ClassUnit
	{
		private UnitTokenFactory() : base(typeof(TokenFactory), UnitParsing._) { }
		public static readonly UnitTokenFactory _ = new UnitTokenFactory();
		public static UnitTokenFactory Instance => _;
	}
	#endregion
}
