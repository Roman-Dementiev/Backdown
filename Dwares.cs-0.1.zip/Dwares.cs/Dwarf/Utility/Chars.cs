﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Utility
{
	/// <summary>
	/// Utility class Chars
	/// </summary>
	public static class Chars
	{
		[Flags]
		public enum AsciiCategory
		{
			Printable = 0,
			Delimiter = 0x0001,
			Introducer = 0x0002,
			Shift = 0x0004,
			FormatEffector = 0x0008,
			InfoSeparator = 0x0010,
			Presentation = 0x0020,
			AreaDefinition = 0x0040,
			DeviceControl = 0x0080,
			Transmission = 0x0100,
			Misc = 0x0200,
			Reserved = 0x0400,
			ControlChar = 0x07FF,
			Whitespace = 0x1000
		}

		#region Methods
		public static bool IsAsciiPrintable(char ch)
		{
			return (ch >= 32 && ch < 128) || (ch >= '\xA0' && ch <= '\xFF');
		}

		public static bool IsAsciiWhitespace(char ch)
		{
			if (ch < ascii.Length) {
				return (ascii[ch].cat & AsciiCategory.Whitespace) != 0;
			} else {
				return false;
			}
		}

		public static bool IsAsciiControlChar(char ch, AsciiCategory cat = AsciiCategory.ControlChar)
		{
			if (ch < ascii.Length) {
				return (ascii[ch].cat & cat) != 0;
			} else {
				return false;
			}
		}

		public static bool IsPrintable(this char ch)
		{
			// TODO
			return IsAsciiPrintable(ch);
		}

		public static bool IsWhitespace(this char ch)
		{
			// TODO
			return IsAsciiWhitespace(ch);
		}

		public static bool IsControlChar(this char ch, AsciiCategory cat = AsciiCategory.ControlChar)
		{
			// TODO
			return IsControlChar(ch, cat);
		}


		public static string ToPrintable(this char ch, Encoding<char> encoding = null)
		{
			if (ch.IsPrintable()) {
				return String.Format("{0}", ch);
			} else if (encoding != null) {
				return encoding(ch);
			} else {
				return CEscapeEncoding(ch);
			}
		}

		public static string AsciiAbbreviation(char ch)
		{
			if (ch < ascii.Length) {
				return ascii[ch].abbr;
			}
			if (ch.IsPrintable()) {
				return String.Format("{0}", ch);
			} else if (ch < 265) {
				return String.Format("#{0:X2}", (ushort)ch);
			} else {
				return String.Format("#{0:X4}", (ushort)ch);
			}
		}

		public static string AsciiDescription(char ch)
		{
			if (ch < ascii.Length) {
				return ascii[ch].description;
			}
			if (ch.IsPrintable()) {
				return String.Format("{0}", ch);
			} else if (ch < 265) {
				return String.Format("#{0:X2}", (ushort)ch);
			} else {
				return String.Format("#{0:X4}", (ushort)ch);
			}
		}

		public static string CEscapeEncoding(char ch)
		{
			switch (ch) {
			case '\0': return "\\0";
			case '\a': return "\\a";
			case '\b': return "\\b";
//			case '\e': return "\\e";
			case '\f': return "\\f";
			case '\n': return "\\n";
			case '\r': return "\\r";
			case '\t': return "\\t";
			case '\v': return "\\v";
			case '\"': return "\\\"";
			}
			if (ch.IsPrintable()) {
				return String.Format("{0}", ch);
			} else if (ch < 265) {
				return String.Format("\\x{0:X2}", (ushort)ch);
			} else {
				return String.Format("\\x{0:X4}", (ushort)ch);
			}
		}

		public static string HtmlEncoding(char ch)
		{
			switch (ch) {
			case '\"': return "&quot;";
			case '&': return "&amp;";
			case '<': return "&lt;";
			case '>': return "&gt;";
			case '\x20AC': return "&euro;";
			}
			if (ch >= 0xA0 && ch < (0xA0 + htmlChars.Length)) {
				return htmlChars[ch - 0xA0];
			}  else if (ch.IsPrintable()) {
				return String.Format("{0}", ch);
			} else {
				return String.Format("&#{0};", (ushort)ch);
			}
		}
		#endregion

		struct AsciiChar
		{
			public string abbr;
			public string description;
			public AsciiCategory cat;

			public AsciiChar(string abbr, string description = null, AsciiCategory cat = AsciiCategory.Printable)
			{
				this.abbr = abbr;
				this.description = description ?? abbr;
				this.cat = cat;
			}
		}

		static AsciiChar[] ascii = {
			/*00*/ new AsciiChar("NULL","Null", AsciiCategory.Misc),
			/*01*/ new AsciiChar("SOH", "Start of Heading", AsciiCategory.Transmission),
			/*02*/ new AsciiChar("STX", "Start of Text", AsciiCategory.Transmission),
			/*03*/ new AsciiChar("EXT", "End of Text", AsciiCategory.Transmission),
			/*04*/ new AsciiChar("EOT", "End of Transaction", AsciiCategory.Transmission),
			/*05*/ new AsciiChar("ENQ", "Enquiry", AsciiCategory.Transmission),
			/*06*/ new AsciiChar("ACK", "Acknowledge", AsciiCategory.Transmission),
			/*07*/ new AsciiChar("BEL", "Bell", AsciiCategory.Misc),
			/*08*/ new AsciiChar("BS",	"Backspace", AsciiCategory.FormatEffector),
			/*09*/ new AsciiChar("TAB", "Horizontal Tabulation", AsciiCategory.FormatEffector|AsciiCategory.Whitespace),
			/*0A*/ new AsciiChar("LF", "Line Feed", AsciiCategory.FormatEffector|AsciiCategory.Whitespace),
			/*0B*/ new AsciiChar("VT", "Vertical Tabulation", AsciiCategory.FormatEffector|AsciiCategory.Whitespace),
			/*0C*/ new AsciiChar("FF", "Form Feed", AsciiCategory.FormatEffector|AsciiCategory.Whitespace),
			/*0D*/ new AsciiChar("SR", "Carriage Return", AsciiCategory.FormatEffector|AsciiCategory.Whitespace),
			/*0E*/ new AsciiChar("SO", "Shift Out", AsciiCategory.Shift),
			/*0F*/ new AsciiChar("SI", "Shift In", AsciiCategory.Shift),
			/*10*/ new AsciiChar("DLE", "Data Link Escape", AsciiCategory.Transmission),
			/*11*/ new AsciiChar("DC1", "Device Control 1", AsciiCategory.DeviceControl),
			/*12*/ new AsciiChar("DC2", "Device Control 2", AsciiCategory.DeviceControl),
			/*13*/ new AsciiChar("DC3", "Device Control 3", AsciiCategory.DeviceControl),
			/*14*/ new AsciiChar("DC4", "Device Control 4", AsciiCategory.DeviceControl),
			/*15*/ new AsciiChar("NAk", "Negative Acknowledge", AsciiCategory.Transmission),
			/*16*/ new AsciiChar("SYN", "Synchronous Idle", AsciiCategory.Transmission),
			/*17*/ new AsciiChar("ETB", "End of Transmission Block", AsciiCategory.Transmission),
			/*18*/ new AsciiChar("CAN", "Cancel", AsciiCategory.Misc),
			/*19*/ new AsciiChar("EM", "End of Medium", AsciiCategory.Misc),
			/*1A*/ new AsciiChar("SUB", "Substitute", AsciiCategory.Misc),
			/*1B*/ new AsciiChar("ESC", "Escape", AsciiCategory.Introducer),
			/*1C*/ new AsciiChar("FS", "File Separator", AsciiCategory.InfoSeparator),
			/*1D*/ new AsciiChar("GS", "Group Separator", AsciiCategory.InfoSeparator),
			/*1E*/ new AsciiChar("RS", "Record Separator", AsciiCategory.InfoSeparator),
			/*1F*/ new AsciiChar("US", "Unit Separator", AsciiCategory.InfoSeparator),
			/*20*/ new AsciiChar("SPACE", "Space", AsciiCategory.Whitespace),
			/*21*/ new AsciiChar("EXCL", "Exclamation point"),		// !
			/*22*/ new AsciiChar("DQUOTE", "Double quotes"),		// "
			/*23*/ new AsciiChar("NUMBER", "Number sign"),			// #
			/*24*/ new AsciiChar("DOLAR", "Dollar sign"),			// $
			/*25*/ new AsciiChar("PERCENT", "Percent sign"),		// %
			/*26*/ new AsciiChar("AMP", "Ampersand"),				// &
			/*27*/ new AsciiChar("QUOTE", "Single quote"),			// '
			/*28*/ new AsciiChar("LPAREN", "Opening parenthesis"),	// (
			/*29*/ new AsciiChar("RPAREN", "Closing parenthesis"),	// )
			/*2A*/ new AsciiChar("ASTERISK", "Asterisk"),			// *
			/*2B*/ new AsciiChar("PLUS", "Plus sign"),				// +
			/*2C*/ new AsciiChar("COMMA", "Comma"),					// ,
			/*2D*/ new AsciiChar("MINUS", "Minus sign"),			// -
			/*2E*/ new AsciiChar("PERIOD", "Period"),				// .
			/*2F*/ new AsciiChar("SLASH", "Slash"),					// /
			/*30*/ new AsciiChar("0", "Zero"),
			/*31*/ new AsciiChar("1", "One"),
			/*32*/ new AsciiChar("2", "Two"),
			/*33*/ new AsciiChar("3", "Three"),
			/*34*/ new AsciiChar("4", "Four"),
			/*35*/ new AsciiChar("5", "Five"),
			/*36*/ new AsciiChar("6", "Six"),
			/*37*/ new AsciiChar("7", "Seven"),
			/*37*/ new AsciiChar("8", "Eight"),
			/*39*/ new AsciiChar("9", "Nine"),
			/*3A*/ new AsciiChar("COLON", "Colon"),					// :
			/*3B*/ new AsciiChar("SEMI", "Semicolon"),				// ;
			/*3C*/ new AsciiChar("LT", "Less than sign"),			// <
			/*3D*/ new AsciiChar("EQ", "Equal sign"),				// =
			/*3E*/ new AsciiChar("GT", "Greater than sign"),		// >
			/*3F*/ new AsciiChar("QUEST", "Question sign"),			//
			/*40*/ new AsciiChar("AT", "At symbol"),				// @
			/*41*/ new AsciiChar("A"),
			/*42*/ new AsciiChar("B"),
			/*43*/ new AsciiChar("C"),
			/*44*/ new AsciiChar("D"),
			/*45*/ new AsciiChar("E"),
			/*46*/ new AsciiChar("F"),
			/*47*/ new AsciiChar("G"),
			/*48*/ new AsciiChar("H"),
			/*49*/ new AsciiChar("I"),
			/*4A*/ new AsciiChar("J"),
			/*4B*/ new AsciiChar("K"),
			/*4C*/ new AsciiChar("L"),
			/*4D*/ new AsciiChar("M"),
			/*4E*/ new AsciiChar("N"),
			/*4F*/ new AsciiChar("O"),
			/*50*/ new AsciiChar("P"),
			/*51*/ new AsciiChar("Q"),
			/*52*/ new AsciiChar("R"),
			/*53*/ new AsciiChar("S"),
			/*54*/ new AsciiChar("T"),
			/*55*/ new AsciiChar("U"),
			/*56*/ new AsciiChar("V"),
			/*57*/ new AsciiChar("W"),
			/*58*/ new AsciiChar("X"),
			/*59*/ new AsciiChar("Y"),
			/*5A*/ new AsciiChar("Z"),
			/*5B*/ new AsciiChar("LBRACKET", "Opening bracket"),	// [
			/*5C*/ new AsciiChar("BSLACH", "Backslash"),			//\
			/*5D*/ new AsciiChar("RBRACKET", "Closing bracket"),	// ]
			/*5E*/ new AsciiChar("CARET", "Caret"),					// ^
			/*5F*/ new AsciiChar("UNDER", "Underscore"),			// _
			/*60*/ new AsciiChar("GRAVE", "Grave accent"),			// `
			/*61*/ new AsciiChar("a"),
			/*62*/ new AsciiChar("b"),
			/*63*/ new AsciiChar("c"),
			/*64*/ new AsciiChar("d"),
			/*65*/ new AsciiChar("e"),
			/*66*/ new AsciiChar("f"),
			/*67*/ new AsciiChar("g"),
			/*68*/ new AsciiChar("h"),
			/*69*/ new AsciiChar("i"),
			/*6A*/ new AsciiChar("j"),
			/*6B*/ new AsciiChar("k"),
			/*6C*/ new AsciiChar("l"),
			/*6D*/ new AsciiChar("m"),
			/*6E*/ new AsciiChar("n"),
			/*0F*/ new AsciiChar("o"),
			/*70*/ new AsciiChar("p"),
			/*71*/ new AsciiChar("q"),
			/*72*/ new AsciiChar("r"),
			/*73*/ new AsciiChar("s"),
			/*74*/ new AsciiChar("t"),
			/*75*/ new AsciiChar("u"),
			/*76*/ new AsciiChar("v"),
			/*77*/ new AsciiChar("w"),
			/*78*/ new AsciiChar("x"),
			/*79*/ new AsciiChar("y"),
			/*7A*/ new AsciiChar("z"),
			/*7B*/ new AsciiChar("LBRACE", "Opening brace"),	// {
			/*7C*/ new AsciiChar("VBAR", "Vertical bar"),		// |
			/*7D*/ new AsciiChar("RBRACE", "Closing brace"),	// }
			/*7E*/ new AsciiChar("TILDE", "Tilde"),				// ~ (equivalency sign)
			/*7F*/ new AsciiChar("DEL", "Delete", AsciiCategory.Misc),
			/*80*/ new AsciiChar("PAD", "Padding Character", AsciiCategory.Reserved),
			/*81*/ new AsciiChar("HOP", "High Octet Preset", AsciiCategory.Reserved),
			/*82*/ new AsciiChar("BPH", "Break Permitted Here", AsciiCategory.Presentation),
			/*83*/ new AsciiChar("NBH", "No Break Here", AsciiCategory.Presentation),
			/*84*/ new AsciiChar("IND", "Index", AsciiCategory.FormatEffector),
			/*85*/ new AsciiChar("NEL", "Next Line", AsciiCategory.FormatEffector),
			/*86*/ new AsciiChar("SSA", "Start of Selected Area", AsciiCategory.AreaDefinition),
			/*87*/ new AsciiChar("ESA", "End of Selected Area", AsciiCategory.AreaDefinition),
			/*88*/ new AsciiChar("HTS", "Horizontal Tabulation Set", AsciiCategory.FormatEffector),
			/*89*/ new AsciiChar("HTJ", "Horizontal Tabulation with Justification", AsciiCategory.FormatEffector),
			/*8A*/ new AsciiChar("VTS", "Vertical Tabulation Set", AsciiCategory.FormatEffector),
			/*8B*/ new AsciiChar("PLD", "Partial Line Down", AsciiCategory.FormatEffector),
			/*8C*/ new AsciiChar("PLU", "Partial Line Up", AsciiCategory.FormatEffector),
			/*8D*/ new AsciiChar("RI", "Reverse Index", AsciiCategory.FormatEffector),
			/*8E*/ new AsciiChar("SS2", "Single Shift Two", AsciiCategory.Shift),
			/*8F*/ new AsciiChar("SS3", "Single Shift Three", AsciiCategory.Shift),
			/*90*/ new AsciiChar("DCS", "Device Control String", AsciiCategory.Delimiter),
			/*91*/ new AsciiChar("PU1", "Private Use One", AsciiCategory.Misc),
			/*92*/ new AsciiChar("PU2", "Private Use Two", AsciiCategory.Misc),
			/*93*/ new AsciiChar("STS", "Set Transmit State", AsciiCategory.Misc),
			/*94*/ new AsciiChar("CCH", "Cancel Character", AsciiCategory.Misc),
			/*95*/ new AsciiChar("MW", "Message Waiting", AsciiCategory.Misc),
			/*96*/ new AsciiChar("SPA", "Start of Guarded Protected Area", AsciiCategory.AreaDefinition),
			/*97*/ new AsciiChar("EPA", "End of Guarded Protected Area", AsciiCategory.AreaDefinition),
			/*98*/ new AsciiChar("SOS", "Start of String", AsciiCategory.Delimiter),
			/*99*/ new AsciiChar("SGCI", "Single Graphic Character Introducer", AsciiCategory.Reserved),
			/*9A*/ new AsciiChar("CSI", "Single Character Introducer", AsciiCategory.Introducer),
			/*9B*/ new AsciiChar("CSI", "Control Sequence Introducer", AsciiCategory.Introducer),
			/*9C*/ new AsciiChar("ST", "String Terminator", AsciiCategory.Delimiter),
			/*9D*/ new AsciiChar("OSC", "Operating System Command", AsciiCategory.Delimiter),
			/*9E*/ new AsciiChar("PM", "Privacy Message", AsciiCategory.Delimiter),
			/*9F*/ new AsciiChar("APC", "Application Program Command", AsciiCategory.Delimiter),
			/*A0*/ new AsciiChar("NBSP", "No-Break space", AsciiCategory.Whitespace),
			/*A1*/ new AsciiChar("IEXCL", "Inverted exclamation"),			// ¡
			/*A2*/ new AsciiChar("CENT", "Cent sign"),						// ¢
			/*A3*/ new AsciiChar("POUBD", "Pound sign"),					// £
			/*A4*/ new AsciiChar("CURREN", "Currency sign"),				// ¤
			/*A5*/ new AsciiChar("YEN", "Yen sign"),						// ¥
			/*A6*/ new AsciiChar("BRVBAR", "Broken vertical bar"),			// ¦
			/*A7*/ new AsciiChar("SECT", "Section sign"),					// §
			/*A8*/ new AsciiChar("UMLAUT", "Spacing diaeresis"),			// ¨
			/*A9*/ new AsciiChar("COPY", "Copyright sign"),					// ©
			/*AA*/ new AsciiChar("ORDF", "Feminine ordinal indicator"),		// ª
			/*AB*/ new AsciiChar("LAQUOTE", "Left double angle quotes"),	// «
			/*AC*/ new AsciiChar("NOT", "Not sign"),						// ¬
			/*AD*/ new AsciiChar("SHY", "Soft hyphen"),						// soft hyphen
			/*AE*/ new AsciiChar("REG", "Registered trade mark sign"),		// ®
			/*AF*/ new AsciiChar("MACR", "spacing macron"),					// spacing macron (overline)
			/*B0*/ new AsciiChar("DEG", "degree sign"),						// °
			/*B1*/ new AsciiChar("PLUSMIN", "Plus-or-minus sign"),			// ±
			/*B2*/ new AsciiChar("SUP2", "Superscript two"),				// ² (squared)
			/*B3*/ new AsciiChar("SUP3", "Superscript three"),				// ³ (cubed)
			/*B4*/ new AsciiChar("ACUTE", "Acute accent"),					// ´
			/*B5*/ new AsciiChar("MICRO", "Micro sign"),					// µ
			/*B6*/ new AsciiChar("PARA", "Paragraph sign"),					// ¶ (pilcrow sign)
			/*B7*/ new AsciiChar("MIDDOT", "Middle dot"),					// · (Georgian comma)
			/*B8*/ new AsciiChar("CEDIL", "Spacing cedilla"),				// ¸
			/*B9*/ new AsciiChar("SUP1", "Superscript one"),				// ¹
			/*BA*/ new AsciiChar("ORDM", "Masculine ordinal indicator"),	// º
			/*BB*/ new AsciiChar("RAQUOTE", "Right double angle quotes"),	// »
			/*BC*/ new AsciiChar("FRAC14", "Fraction one quarter"),			// ¼
			/*BD*/ new AsciiChar("FRAC12", "Fraction one half"),			// ½
			/*BE*/ new AsciiChar("FRAC34", "Fraction three quarters"),		// ¾
			/*BF*/ new AsciiChar("IQUEST", "Inverted question mark")			// ¿
		};

		static string[] htmlChars = {
			/*A0*/ "&nbsp;",	// Non-breaking space
			/*A1*/ "&iexcl;",	// ¡
			/*A2*/ "&cent;",	// ¢
			/*A3*/ "&pound;",	// £
			/*A4*/ "&curren;",	// ¤
			/*A5*/ "&yen;",		// ¥
			/*A6*/ "&brvbar;",	// ¦
			/*A7*/ "&sect;",	// §
			/*A8*/ "&uml;",		// ¨
			/*A9*/ "&copy;",	// ©
			/*AA*/ "&ordf;",	// ª
			/*AB*/ "&laquo;",	// «
			/*AC*/ "&not;",		// ¬
			/*AD*/ "&shy;",		// soft hyphen
			/*AE*/ "&reg;",		// ®
			/*AF*/ "&macr;",	// spacing macron - overline
			/*B0*/ "&deg;",		// °
			/*B1*/ "&plusmn;",	// ±
			/*B2*/ "&sup2;",	// ²
			/*B3*/ "&sup3;",	// ³
			/*B4*/ "&acute;",	// ´
			/*B5*/ "&micro;",	// µ
			/*B6*/ "&para;",	// ¶
			/*B7*/ "&middot;",	//·
			/*B8*/ "&cedil;",	// ¸
			/*B9*/ "&sup1;",	// ¹
			/*BA*/ "&ordm;",	// º
			/*BB*/ "&raquo;",	// »
			/*BC*/ "&frac14;",	// ¼
			/*BD*/ "&frac12;",	// ½
			/*BE*/ "&frac34;",	// ¾
			/*BF*/ "&iquest;",	// ¿
			/*C0*/ "&Agrave;",	// À
			/*C1*/ "&Aacute'",	// Á
			/*C2*/ "&Acirc;",	// Â
			/*C3*/ "&Atilde;",	// Ã
			/*C4*/ "&Auml;",	// Ä
			/*C5*/ "&Aring;",	// Å
			/*C6*/ "&AElig;",	// Æ
			/*C7*/ "&Ccedil;",	// Ç
			/*C8*/ "&Egrave;",	//·È
			/*C9*/ "&Eacute;",	// É
			/*CA*/ "&Ecirc;",	// Ê
			/*CB*/ "&Euml;",	// Ë
			/*CC*/ "&Igrave;",	// Ì
			/*CD*/ "&Iacute;",	// Í
			/*CE*/ "&Icirc;",	// Î
			/*CF*/ "&Iuml;",	// Ï
			/*D0*/ "&ETH;",		// Ð
			/*D1*/ "&Ntilde;",	// Ñ
			/*D2*/ "&Ograve;",	// Ò
			/*D3*/ "&Oacute;",	// Ó
			/*D4*/ "&Ocirc;",	// Ô
			/*D5*/ "&Otilde;",	// Õ
			/*D6*/ "&Ouml;",	// Ö
			/*D7*/ "&times;",	// ×
			/*D8*/ "&Oslash;",	//·Ø
			/*D9*/ "&Ugrave;",	// Ù
			/*DA*/ "&Uacute;",	// Ú
			/*DB*/ "&Ucirc;",	// Û
			/*DC*/ "&Uuml;",	// Ü
			/*DD*/ "&Yacute;",	// Ý
			/*DE*/ "&THORN;",	// Þ
			/*DF*/ "&szlig;",    // ß
			/*E0*/ "&agrave;",	// à
			/*E1*/ "&aacute;",	// á
			/*E2*/ "&acirc;",	// â
			/*E3*/ "&atilde;",	// ã
			/*E4*/ "&auml;",	// ä
			/*E5*/ "&aring;",	// å
			/*E6*/ "&aelig;",	// æ
			/*E7*/ "&ccedil;",	// ç
			/*E8*/ "&egrave;",	//·è
			/*E9*/ "&eacute;",	// é
			/*EA*/ "&ecirc;",	// ê
			/*EB*/ "&euml;",	// ë
			/*EC*/ "&igrave;",	// ì
			/*ED*/ "&iacute;",	// í
			/*EE*/ "&icirc;",	// î
			/*EF*/ "&iuml;",	// ï
			/*F0*/ "&eth;",		// ð
			/*F1*/ "&ntilde;",	// ñ
			/*F2*/ "&ograve;",	// ò
			/*F3*/ "&oacute;",	// ó
			/*F4*/ "&ocirc;",	// ô
			/*F5*/ "&otilde;",	// õ
			/*F6*/ "&ouml;",	// ö
			/*F7*/ "&divide;",	// ÷
			/*F8*/ "&oslash;",	//·ø
			/*F9*/ "&ugrave;",	// ù
			/*FA*/ "&uacute;",	// ú
			/*FB*/ "&ucirc;",	// û
			/*FC*/ "&uuml;",	// ü
			/*FD*/ "&yacute;",	// ý
			/*FE*/ "&thorn;",	// þ
			/*FF*/ "&yuml;"		// ÿ
		};
	}

	#region UnitChars	
	public sealed class UnitChars : UtilityUnit
	{
		private UnitChars() : base(typeof(Chars), UnitUtility._) { }
		public static readonly UnitChars _ = new UnitChars();
		public static UnitChars Instance => _;
	}
	#endregion
}
