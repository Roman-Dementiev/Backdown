﻿using System;
using System.Collections;
using System.Collections.Generic;
using Dwarf.Extensions;


namespace Dwarf
{
	public delegate int SortOrder(object obj1, object obj2);
	public delegate int SortOrder<TObject>(TObject item1, TObject item2);

	public enum SortPolicy
	{
		NullAndEmptyNotAllowed,
		NullAndEmptyAtStart,
		NullAndEmptyAtEnd,
		NullNotAllowedEmptyAtStart,
		NullNotAllowedEmptyAtEnd,
		NullAndEmptyHandledByOrder,

		Default = NullAndEmptyNotAllowed
	};

	public static class Sort
	{
		public static ArrayList GetSorted(IEnumerable items, IComparer comparer)
		{
			var list = items.ToArrayList();
			list.Sort(comparer);
			return list;
		}

		public static List<TItem> GetSorted<TItem>(IEnumerable<TItem> items, IComparer<TItem> comparer)
		{
			var list = items.ToList();
			list.Sort(comparer);
			return list;
		}


		public static ArrayList GetSorted(IEnumerable items, SortOrder order, SortPolicy policy = SortPolicy.Default)
			=> GetSorted(items, GetDefaultComparer(order, policy));

		public static List<TItem> GetSorted<TItem>(IEnumerable<TItem> items, SortOrder<TItem> order, SortPolicy policy = SortPolicy.Default)
			=> GetSorted(items, GetDefaultComparer(order, policy));

		public static List<string> GetSortedStrings(IEnumerable<string> items, SortOrder<string> order, SortPolicy policy = SortPolicy.Default)
			=> GetSorted(items, GetStringComparer(order, policy));


		public static void SortList<TItem>(IList<TItem> items, IComparer<TItem> comparer, bool inPlace = false)
		{
			if (inPlace)
			{
				// TODO
				//QuickSortInPlace(items, policy);
				//return;
			}

			var list = GetSorted(items, comparer);

			items.Clear();
			items.AddItems(list);
		}

		public static void SortList<TItem>(IList<TItem> items, SortOrder<TItem> order, SortPolicy policy = SortPolicy.Default, bool inPlace=false)
			=> SortList(items, GetDefaultComparer(order, policy));


		public static void SortList(ArrayList items, SortOrder order,SortPolicy policy = SortPolicy.Default)
			=> items.Sort(GetDefaultComparer(order, policy));

		public static void SortList<TItem>(List<TItem> items, SortOrder<TItem> order, SortPolicy policy = SortPolicy.Default)
			=>  items.Sort(GetDefaultComparer(order, policy));


		public static void SortArray<TItem>(TItem[] items, SortOrder<TItem> order, SortPolicy policy = SortPolicy.Default)
			=> Array.Sort(items, GetDefaultComparer(order, policy));

		public static void SortStrings(IList<string> strings, SortOrder<string> order, SortPolicy policy = SortPolicy.Default, bool inPlace = false)
		{
			if (inPlace)
			{
				// TODO
				//QuickSortInPlace(strings, policy);
				//return;
			}

			List<string> list = GetSortedStrings(strings, order, policy);

			strings.Clear();
			strings.AddItems(list);
		}

		public static void SortStrings(List<string> strings, SortOrder<string> order, SortPolicy policy = SortPolicy.Default)
			=>  strings.Sort(GetStringComparer(order, policy));

		public static void SortStrings(string[] strings, SortOrder<string> order, SortPolicy policy = SortPolicy.Default)
			=>  Array.Sort(strings, GetStringComparer(order, policy));



		public static Comparer GetDefaultComparer(SortPolicy policy = SortPolicy.Default) 
			=> GetDefaultComparer(null, policy);

		public static Comparer GetDefaultComparer(SortOrder order, SortPolicy policy = SortPolicy.Default)
		{
			switch (policy)
			{
				default:
					return new NullNotAllowed(order);

				case SortPolicy.NullAndEmptyAtStart:
					return new NullAtStart(order);

				case SortPolicy.NullAndEmptyAtEnd:
					return new NullAtEnd(order);

				case SortPolicy.NullAndEmptyHandledByOrder:
					return new Comparer(order ?? throw new ArgumentNullException(nameof(order)));
			}
		}

		public static Comparer<TItem> GetDefaultComparer<TItem>(SortOrder<TItem> order, SortPolicy policy = SortPolicy.Default)
		{
			switch (policy)
			{
				default:
					return new NullNotAllowed<TItem>(order);

				case SortPolicy.NullAndEmptyAtStart:
					return new NullAtStart<TItem>(order);

				case SortPolicy.NullAndEmptyAtEnd:
					return new NullAtEnd<TItem>(order);

				case SortPolicy.NullAndEmptyHandledByOrder:
					return new Comparer<TItem>(order ?? throw new ArgumentNullException(nameof(order)));
			}
		}

		public static Comparer<string> GetStringComparer(SortPolicy policy = SortPolicy.Default)
			=> GetStringComparer(null, policy);

		public static Comparer<string> GetStringComparer(SortOrder<string> order, SortPolicy policy = SortPolicy.Default)
		{
			if (order == null) {
				order = CaseSensitiveOrder;
			}

			switch (policy)
			{
				default:
					return new NullAndEmptyNotAllowed(order);

				case SortPolicy.NullAndEmptyAtStart:
					return new NullAndEmptyAtStart(order);

				case SortPolicy.NullAndEmptyAtEnd:
					return new NullAndEmptyAtEnd(order);

				case SortPolicy.NullNotAllowedEmptyAtStart:
					return new EmptyAtStart(order);

				case SortPolicy.NullNotAllowedEmptyAtEnd:
					return new EmptyAtEnd(order);

				case SortPolicy.NullAndEmptyHandledByOrder:
					return new Comparer<string>(order ?? throw new ArgumentNullException(nameof(order)));
			}
		}

		public static int DefaultOrder(object obj1, object obj2)
		{
			if (obj1 is IComparable comparable1) {
				return comparable1.CompareTo(obj1);
			}
			if (obj2 is IComparable comparable2) {
				return -comparable2.CompareTo(obj2);
			}
			return obj1.ToString().CompareTo(obj1.ToString());
		}

		public static int DefaultGenericOrder<TObject>(TObject obj1, TObject obj2)
		{
			return DefaultOrder(obj1, obj2);
		}

		public static int CaseSensitiveOrder(string str1, string str2) => String.Compare(str1, str2, false);
		public static int IgnoringCaseOrder(string str1, string str2) => String.Compare(str1, str2, true);
		public static int OrdinalOrder(string str1, string str2) => String.CompareOrdinal(str1, str2);


		public class Comparer: IComparer
		{
			SortOrder order;
			public Comparer(SortOrder order = null) {
				this.order = order ?? DefaultOrder;
			}

			public virtual int Compare(object obj1, object obj2) {
				return order(obj1, obj2);
			}
		}

		internal class NullNotAllowed : Comparer
		{
			public NullNotAllowed(SortOrder order = null) : base(order) { }

			public override int Compare(object obj1, object obj2)
			{
				if (obj1 == null) throw new ArgumentNullException(nameof(obj1));
				if (obj2 == null) throw new ArgumentNullException(nameof(obj2));

				return base.Compare(obj1, obj2);
			}
		}

		internal class NullAtStart : Comparer
		{
			public NullAtStart(SortOrder order = null) : base(order) { }

			public override int Compare(object obj1, object obj2)
			{
				if (obj1 == null) {
					return (obj2 == null) ? 0 : -1;
				}
				if (obj2 == null) {
					return 1;
				}

				return base.Compare(obj1, obj2);
			}
		}

		internal class NullAtEnd : Comparer
		{
			public NullAtEnd(SortOrder order = null) : base(order) { }

			public override int Compare(object obj1, object obj2)
			{
				if (obj1 == null) {
					return (obj2 == null) ? 0 : 1;
				}
				if (obj2 == null) {
					return -1;
				}

				return base.Compare(obj1, obj2);
			}
		}

		public class Comparer<TObject> : IComparer<TObject>
		{
			SortOrder<TObject> order;
			public Comparer(SortOrder<TObject> order = null)
			{
				this.order = order ?? DefaultGenericOrder;
			}

			public virtual int Compare(TObject obj1, TObject obj2)
			{
				return order(obj1, obj2);
			}
		}

		internal class NullNotAllowed<TObject> : Comparer<TObject>
		{
			public NullNotAllowed(SortOrder<TObject> order = null) : base(order) { }

			public override int Compare(TObject obj1, TObject obj2)
			{
				if (obj1 == null) throw new ArgumentNullException(nameof(obj1));
				if (obj2 == null) throw new ArgumentNullException(nameof(obj2));

				return base.Compare(obj1, obj2);
			}
		}

		internal class NullAtStart<TObject> : Comparer<TObject>
		{
			public NullAtStart(SortOrder<TObject> order = null) : base(order) { }

			public override int Compare(TObject obj1, TObject obj2)
			{
				if (obj1 == null) {
					return (obj2 == null) ? 0 : -1;
				}
				if (obj2 == null) {
					return 1;
				}

				return base.Compare(obj1, obj2);
			}
		}

		internal class NullAtEnd<TObject> : Comparer<TObject>
		{
			public NullAtEnd(SortOrder<TObject> order = null) : base(order) { }

			public override int Compare(TObject obj1, TObject obj2)
			{
				if (obj1 == null) {
					return (obj2 == null) ? 0 : 1;
				}
				if (obj2 == null) {
					return -1;
				}

				return base.Compare(obj1, obj2);
			}
		}

		public class StringComparer : Comparer<string>
		{
			public StringComparer(SortOrder<string> order = null) : 
				base(order ?? CaseSensitiveOrder)
			{ }
		}

		internal class NullAndEmptyNotAllowed : StringComparer
		{
			public NullAndEmptyNotAllowed(SortOrder<string> order = null) : base(order) { }

			public override int Compare(string str1, string str2)
			{
				if (String.IsNullOrEmpty(str1)) throw new ArgumentNullException(nameof(str1));
				if (String.IsNullOrEmpty(str2)) throw new ArgumentNullException(nameof(str2));

				return base.Compare(str1, str2);
			}
		}

		internal class NullAndEmptyAtStart : StringComparer
		{
			public NullAndEmptyAtStart(SortOrder<string> order = null) : base(order) { }

			public override int Compare(string str1, string str2)
			{
				if (String.IsNullOrEmpty(str1)) {
					return String.IsNullOrEmpty(str2) ? 0 : -1;
				}
				if (String.IsNullOrEmpty(str2)) {
					return 1;
				}

				return base.Compare(str1, str2);
			}
		}

		internal class NullAndEmptyAtEnd : StringComparer
		{
			public NullAndEmptyAtEnd(SortOrder<string> order = null) : base(order) { }

			public override int Compare(string str1, string str2)
			{
				if (String.IsNullOrEmpty(str1)) {
					return String.IsNullOrEmpty(str2) ? 0 : 1;
				}
				if (String.IsNullOrEmpty(str2)) {
					return -1;
				}

				return base.Compare(str1, str2);
			}
		}

		internal class EmptyAtStart : StringComparer
		{
			public EmptyAtStart(SortOrder<string> order = null) : base(order) { }

			public override int Compare(string str1, string str2)
			{
				if (str1 == null) throw new ArgumentNullException(nameof(str1));
				if (str2 == null) throw new ArgumentNullException(nameof(str2));

				if (str1.Length == 0) {
					return str2.Length == 0 ? 0 : -1;
				}
				if (str2.Length == 0) {
					return 1;
				}
				return base.Compare(str1, str2);
			}
		}

		internal class EmptyAtEnd : StringComparer
		{
			public EmptyAtEnd(SortOrder<string> order = null) : base(order) { }

			public override int Compare(string str1, string str2)
			{
				if (str1 == null) throw new ArgumentNullException(nameof(str1));
				if (str2 == null) throw new ArgumentNullException(nameof(str2));

				if (str1.Length == 0) {
					return str2.Length == 0 ? 0 : 1;
				}
				if (str2.Length == 0) {
					return -1;
				}

				return base.Compare(str1, str2);
			}
		}

	}
}
