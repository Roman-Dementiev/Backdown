﻿using System;
using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using Dwarf.Assets;
using Dwarf.Collections;
using Dwarf.Utility;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing.Gold
{
	/// <summary>
	/// Class GTable
	/// </summary>
	public class GTable : Grammar
	{
		#region Constants
		public static readonly string cHeaderPrefix = "GOLD Parser Tables/";
		public static readonly string cHeaderV1 = "cHeaderPrefix" + "v1.0";
		public static readonly string cHeaderV5 = "cHeaderPrefix" + "v5.0";
		#endregion

		List<ArrayList> groupRecords = null;

		#region Constructors
		public GTable(string filename)
		{
			ReadFile(filename);
		}

		public GTable(Stream stream)
		{
			Read(stream);
		}
		#endregion

		#region Methods
		public void ReadFile(string filename)
		{
			using (FileStream stream = new FileStream(filename, FileMode.Open, FileAccess.Read)) {
				Read(stream);
			}
		}

		public void ReadAsset(string assetName)
		{
			byte[] asset = AssetMgr.GetBinary(assetName);
			if (asset != null) {
				Read(new MemoryStream(asset));
			}
		}

		public void Read(Stream input)
		{
			groupRecords = new List<ArrayList>();

			using (BinaryReader reader = new BinaryReader(input, Encoding.Unicode)) {
				try {
					string header = reader.ReadCString();
					if (header.StartsWith(cHeaderPrefix)) {
						Version = header.Substring(cHeaderPrefix.Length);
					} else {
						new NotValidGrammarTable().Throw();
					}

					ArrayList record = new ArrayList();

					while (input.Position < input.Length)
					{
						if (input.ReadByte() != 77) { // 'M'
							new NotValidGrammarTable(Messages.InvalidTableRecord).Throw();
						}

						ushort count = reader.ReadUInt16();
						for (int i = 0; i < count; i++)
						{
							byte b = reader.ReadByte();
							switch (b)
							{
							case 69: // 'E' = Empty
								record.Add(null);
								break;

							case 98: // 'b' = Byte
								record.Add(reader.ReadByte());
								break;

							case 66: // 'B' = Boolean
								record.Add(reader.ReadBoolean());
								break;

							case 73: // 'I' = Integer
								record.Add(reader.ReadUInt16());
								break;

							case 83: // 'S' = String
								record.Add(reader.ReadCString());
								break;

							default:
								new NotValidGrammarTable(Messages.InvalidTableEntry).Throw();
								break;
							}
						}

						AddRecord(record);
						record.Clear();
					}

					foreach (ArrayList groupRec in groupRecords)
					{
						ushort index = GetEntry<ushort>(groupRec[1]);
						string name = GetEntry<string>(groupRec[2]);
						ushort containerIndex = GetEntry<ushort>(groupRec[3]);
						ushort startIndex = GetEntry<ushort>(groupRec[4]);
						ushort endIndex = GetEntry<ushort>(groupRec[5]);
						ushort advanceMode = GetEntry<ushort>(groupRec[6]);
						ushort endingMode = GetEntry<ushort>(groupRec[7]);
						int nestingCount = groupRec.Count - 8;

						CheckIndex(Groups, index);
						if (containerIndex >= Symbols.Length || startIndex >= Symbols.Length || endIndex >= Symbols.Length) {
							new NotValidGrammarTable(Messages.InvalidSymbolInGroup).Throw();
						}
						Symbol container = Symbols[containerIndex];
						Symbol start = Symbols[startIndex];
						Symbol end = Symbols[endIndex];

						Group group = new Group(index, name, container, start, end, advanceMode, endingMode, nestingCount);
						Groups[index] = group;
						container.Group = group;
						start.Group = group;
						end.Group = group;
					}
				}
				catch (DwarfException exc) {
					throw exc;
				}
				catch (Exception exc) {
					new GrammarTableException(exc).Throw();
				}
			}
		}

		public static TType GetEntry<TType>(object entry)
		{
			if (entry.GetType() != typeof(TType)) {
				new NotValidGrammarTable(Messages.InvalidTableEntry).Throw();
			}
			return (TType)entry;
		}

		public static void CheckIndex<T>(T[] table, uint index)
		{
			if (table == null) {
				new GrammarTableException(Messages.TableCountsMissing).Throw();
			} else if (index >= table.Length) {
				new GrammarTableException(Messages.TableIndexOutOfRange).Throw();
			} else if (table[index] != null) {
				new GrammarTableException(Messages.DuplicateTableIndex).Throw();
			}
		}

		/// <summary>
		/// Adds the record.
		/// </summary>
		/// <param name="record">The record.</param>
		public void AddRecord(ArrayList record)
		{
			byte recordType = GetEntry<byte>(record[0]);
			switch (recordType)
			{
			case 80: // 'p' = Parameters v1.0
				Parameters = new List<Grammar.Parameter>(5);
				Parameters.Add(new Parameter("Name", GetEntry<string>(record[1])));
				Parameters.Add(new Parameter("Version", GetEntry<string>(record[2])));
				Parameters.Add(new Parameter("Author", GetEntry<string>(record[3])));
				Parameters.Add(new Parameter("Case Sensitive?", GetEntry<bool>(record[4])));
				Parameters.Add(new Parameter("Start Symbol", GetEntry<ushort>(record[5])));
				break;

			case 112: // 'P' = Property
				if (Parameters == null) {
					Parameters = new List<Parameter>();
				}
				ushort index = GetEntry<ushort>(record[1]);
				string name  = GetEntry<string>(record[2]);
				string value = GetEntry<string>(record[3]);
				Parameters.AddAt(index, new Grammar.Parameter(name, value));
				break;

			case 84: // 'T' = Table Counts v1.0
				ushort symbolCount  = GetEntry<ushort>(record[1]);
				ushort charSetCount = GetEntry<ushort>(record[2]);
				ushort ruleCount    = GetEntry<ushort>(record[3]);
				ushort dfaCount     = GetEntry<ushort>(record[4]);
				ushort lalrCount    = GetEntry<ushort>(record[5]);

				Symbols = new Symbol[symbolCount];
				Groups = new Group[0];
				CharSets = new CharSet[charSetCount];
				Rules = new Rule[ruleCount];
				DfaStates = new DfaState[dfaCount];
				LalrStates = new LalrState[lalrCount];
				break;

			case 116: // 't = Table Counts
				symbolCount         = GetEntry<ushort>(record[1]);
				charSetCount        = GetEntry<ushort>(record[2]);
				ruleCount           = GetEntry<ushort>(record[3]);
				dfaCount            = GetEntry<ushort>(record[4]);
				lalrCount           = GetEntry<ushort>(record[5]);
				ushort groupCount   = GetEntry<ushort>(record[6]);

				Symbols = new Grammar.Symbol[symbolCount];
				Groups = new Grammar.Group[groupCount];
				CharSets = new Grammar.CharSet[charSetCount];
				Rules = new Grammar.Rule[ruleCount];
				DfaStates = new Grammar.DfaState[dfaCount];
				LalrStates = new Grammar.LalrState[lalrCount];
				break;

			case 67: // 'C' = Character Set v1.0
				index = GetEntry<ushort>(record[1]);
				value = GetEntry<string>(record[2]);
				CheckIndex(CharSets, index);
				CharSets[index] = new Grammar.CharSet(index, value);
				break;

			case 99: // 'c' = Character Set
				index               = GetEntry<ushort>(record[1]);
				ushort unicodePlane = GetEntry<ushort>(record[2]);
				ushort rangeCount   = GetEntry<ushort>(record[3]);
				Grammar.CharSet charSet = new Grammar.CharSet(index, unicodePlane, rangeCount);
				for (int i = 5, range = 0; range < rangeCount; range++) {
					charSet.Ranges[range].start = GetEntry<ushort>(record[i++]);
					charSet.Ranges[range].end   = GetEntry<ushort>(record[i++]);
				}
				CheckIndex(CharSets, index);
				CharSets[index] = charSet;
				break;

			case 83: // 'S' = Symbols
				index       = GetEntry<ushort>(record[1]);
				name        = GetEntry<string>(record[2]);
				ushort kind = GetEntry<ushort>(record[3]);
				CheckIndex(Symbols, index);
				Symbols[index] = new Grammar.Symbol(index, name, kind);
				break;

			case 103: // 'g' = Group
				var groupRecord = new ArrayList(record);
				groupRecords.Add(groupRecord);
				break;

			case 82: // 'R' = Rules
				index       = GetEntry<ushort>(record[1]);
				ushort head = GetEntry<ushort>(record[2]);
				Grammar.Rule rule = new Grammar.Rule(index, head, record.Count - 4);
				for (int i = 4, sym = 0; i < record.Count; i++, sym++) {
					rule.Symbols[sym] = GetEntry<ushort>(record[i]);
				}
				CheckIndex(Rules, index);
				Rules[index] = rule;
				break;

			case 73: // 'I' = Initial States
				InitialDfaState = GetEntry<ushort>(record[1]);
				InitialLalrState = GetEntry<ushort>(record[2]);
				break;

			case 68: // 'D' = DFA States
				index              = GetEntry<ushort>(record[1]);
				bool isAcceptState = GetEntry<bool>(record[2]);
				ushort acceptIndex = GetEntry<ushort>(record[3]);
				int edgeCount      = (record.Count - 5) / 3;
				Grammar.DfaState dfa = new Grammar.DfaState(index, isAcceptState, acceptIndex, edgeCount);
				for (int edge = 0, i = 5; edge < edgeCount; edge++, i++) {
					dfa.Edges[edge].charsetIndex = GetEntry<ushort>(record[i++]);
					dfa.Edges[edge].targetIndex = GetEntry<ushort>(record[i++]);
				}
				CheckIndex(DfaStates, index);
				DfaStates[index] = dfa;
				break;

			case 76: // 'L' = LALR States
				index = GetEntry<ushort>(record[1]);
				int actionCount = (record.Count - 3) / 4;
				Grammar.LalrState lalr = new Grammar.LalrState(index, actionCount);
				for (int action = 0, i = 3; action < actionCount; action++, i++) {
					lalr.Actions[action].symbol = GetEntry<ushort>(record[i++]);
					lalr.Actions[action].action = GetEntry<ushort>(record[i++]);
					lalr.Actions[action].target = GetEntry<ushort>(record[i++]);
				}
				CheckIndex(LalrStates, index);
				LalrStates[index] = lalr;
				break;

			default:
				Log.Warning(UnitGTable._, "Unknown record type {0} ('{1}'); ignored.",
							recordType, (char)recordType);
				break;
			}
		}

		#endregion
	}

	#region UnitGTable
	public sealed class UnitGTable : ClassUnit
	{
		private UnitGTable() : base(typeof(GTable), UnitGold._) { }
		public static readonly UnitGTable _ = new UnitGTable();
		public static UnitGTable Instance => _;
	}
	#endregion
}
