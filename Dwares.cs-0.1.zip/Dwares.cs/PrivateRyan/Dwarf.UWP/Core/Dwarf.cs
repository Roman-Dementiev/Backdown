﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dwarf
{
	public enum None { _ }

	public interface INull {
		Type Type();
	}

	class Null<T> : INull {
		public Type Type() => typeof(T);
	}

	public static class Null
	{
		static Null<T> As<T>() => new Null<T>();
	}
}
