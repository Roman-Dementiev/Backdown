﻿using System;
using System.ComponentModel;


namespace Dwarf.ObjectModel
{
	public class ObservableEntity : Entity, INotifyPropertyChanged
	{
		public event PropertyChangedEventHandler PropertyChanged;

		public ObservableEntity(string uid) : base(uid) {}

		public ObservableEntity(string uid, ObservableEntity entity) :
			base(uid, entity)
		{ }

		public override void NotifyPropertyChanged(string propertyName)
		{
			PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
		}
	}
}
