﻿#if false
using System;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Input;
using Dwarf.UWP;


namespace Dwarf.UI
{
	public class TextField : StackPanel
	{
		static Thickness noBorder = new Thickness(0);
		static Thickness hasBorder = new Thickness(1);

		TextBlock view;
		TextBox edit;

		public TextField()
		{
			view = new TextBlock();
			edit = new TextBox();
			edit.TextChanged += this.OnTextChanged;
			edit.BorderThickness = noBorder;
			edit.PlaceholderText = "Enter something";
			EditHasBoreder = false;
			SetEditable(false);
		}

		void SetEditable(bool editable)
		{
			if (editable) {
				Children.Remove(view);
				Children.Add(edit);
			} else {
				Children.Remove(edit);
				Children.Add(view);
			}
		}

		public bool IsEditable {
			get => isEditable;
			set {
				if (value != isEditable) {
					isEditable = value;
					SetEditable(value);
				}
			}
		}
		bool isEditable = false;

		public string Text {
			get => edit.Text;
			set { edit.Text = value; view.Text = value; }
		}

		public bool EditHasBoreder {
			get => !edit.BorderThickness.Equals(noBorder);
			set {
				if (value != EditHasBoreder) {
					EditBorderThickness = value ? hasBorder : noBorder;
				}
			}
		}

		public Thickness EditBorderThickness {
			get => edit.BorderThickness;
			set => edit.BorderThickness = value;
		}

		public string PlaceholderText {
			get => edit.PlaceholderText;
			set => edit.PlaceholderText = value;
		}

		public InputScope InputScope {
			get => edit.InputScope;
			set => edit.InputScope = value;
		}

		public InputScopeNameValue InputScopeNameValue {
			get => InputScope.DefaultScopeNameValue();
			set => InputScope = value.ToInputScope();
		}



		public void Focus()
		{
			if (isEditable) {
				edit.Focus(FocusState.Programmatic);
			} else {
				view.Focus(FocusState.Programmatic);
			}
		}

		private void OnTextChanged(object sender, TextChangedEventArgs e)
		{
			TextChanged?.Invoke(sender, e);
		}
		public event TextChangedEventHandler TextChanged;
	}
}
#endif
