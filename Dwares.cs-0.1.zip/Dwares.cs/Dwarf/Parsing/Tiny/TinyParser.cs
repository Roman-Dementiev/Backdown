﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing.Tiny
{
	/// <summary>
	/// Class TinyParser
	/// </summary>
	public class TinyParser : Parsing.LALRParser, ILalrStates, IRules
	{
		#region Constants
		public const ushort cShift  = 0 << 14;
		public const ushort cReduce = 1 << 14;
		public const ushort cGoto   = 2 << 14;
		public const ushort cAccept = 3 << 14;
		public const ushort cActionMask = 0xC000;
		public const ushort cTargetMask = 0x3FFF;
		#endregion

		#region Fields
		protected ushort[][] stateTable;
		protected ushort[][] rulesTable;
		#endregion

		#region Constructors
		public TinyParser() { }

		public TinyParser(Symbols symbols, ILexer lexer, ushort[][] rulesTable,
						ushort[][] lalrStateTable, uint initilaLalrState)
		{
			Init(symbols, lexer, rulesTable, lalrStateTable, initilaLalrState);
		}

		public TinyParser(Symbols symbols, char[][] charSetTable, ushort[][] rulesTable,
						ushort[][] dfaStateTable, uint initialDfaState,
						ushort[][] lalrStateTable, uint initilaLalrState)
		{
			Init(symbols, charSetTable, dfaStateTable, initialDfaState,
				rulesTable, lalrStateTable, initilaLalrState);
		}

		public void Init(Symbols symbols, ILexer lexer, ushort[][] rulesTable,
						ushort[][] lalrStateTable, uint initilaLalrState)
		{
			stateTable = lalrStateTable;
			this.rulesTable = rulesTable;
			Init(symbols, lexer, this, this, initilaLalrState);
		}

		public void Init(Symbols symbols, 
						char[][] charSetTable, ushort[][] dfaStateTable, uint initialDfaState,
						ushort[][] rulesTable, ushort[][] lalrStateTable, uint initilaLalrState)
		{
			TinyDFA dfa = new TinyDFA(charSetTable, dfaStateTable, initialDfaState);
			ILexer lexer;
			if (Optimize) {
				lexer = dfa;
			} else {
				lexer = new DFA(dfa, dfa, initialDfaState);
			}
			Init(symbols, lexer, rulesTable, lalrStateTable, initialDfaState);
		}
		#endregion

		#region Properties
		public int RulesCount => rulesTable.Length;
		public int StateCount => stateTable.Length;
		public uint ShiftAction  => cShift;
		public uint ReduceAction => cReduce;
		public uint GotoAction   => cGoto;
		public uint AcceptAction => cAccept;

		public static bool Optimize { get; set; } = true;
		#endregion

		#region Methods
		public int GetHeadSymbol(uint rule)
		{
			Debug.Assert(rule < rulesTable.Length);
			return rulesTable[rule][0];
		}

		public int GetRuleLength(uint rule)
		{
			Debug.Assert(rule < rulesTable.Length);
			return rulesTable[rule].Length - 1;
		}

		public int GetRuleSymbol(uint rule, uint index)
		{
			Debug.Assert(rule < rulesTable.Length);
			return rulesTable[rule][index + 1];
		}

		public bool IsTrimable(uint rule)
		{
			Debug.Assert(rule < rulesTable.Length);
			return rulesTable[rule].Length == 2;
		}

		public int ActionCount(uint state)
		{
			Debug.Assert(state < stateTable.Length);
			return stateTable[state].Length / 2;
		}

		public int ActionSymbol(uint state, uint action)
		{
			Debug.Assert(state < stateTable.Length);
			ushort[] actions = stateTable[state];

			Debug.Assert(2*action < actions.Length);
			return actions[2 * action];
		}

		public uint ActionType(uint state, uint action)
		{
			Debug.Assert(state < stateTable.Length);
			ushort[] actions = stateTable[state];

			Debug.Assert(2*action + 1 < actions.Length);
			return (ushort)(actions[2*action+1] & cActionMask);
		}

		public uint ActionTarget(uint state, uint action)
		{
			Debug.Assert(state < stateTable.Length);
			ushort[] actions = stateTable[state];

			Debug.Assert(2*action+1 < actions.Length);
			return (ushort)(actions[2*action+1] & cTargetMask);
		}

		public static int FindAction(ushort[] actions, int sym)
		{
			for (int index = 0; index < actions.Length; index += 2) {
				if (actions[index] == sym)
					return index;
			}
			return -1;
		}

		public override object Process()
		{
			if (!Optimize || HasOnShiftOrReduce) {
				return base.Process();
			}

			for (;;)
			{
				Token token = GetLookahead();
				currentState = stateStack[stateStackTop];
				ushort[] actions = stateTable[currentState];
				int actionIndex = FindAction(actions, lookahead.Symbol);
				if (actionIndex < 0) {
					SyntaxError();
					return null;
				}

				ushort action = (ushort)(actions[actionIndex + 1] & cActionMask);
				ushort target = (ushort)(actions[actionIndex + 1] & cTargetMask);
				switch (action)
				{
				case cAccept:
					Accept(PeekToken().Object);
					return Result;

				case cShift:
					PushState(target);
					PushToken(lookahead);
					lookahead = null;
					continue;

#if DEBUG
				case cReduce:
					break;

				default:
					Error(new InvalidParserTable(UnitLALRParser._, currentState, lookahead.Symbol, action));
					return Result;
#endif
				}

				// Reduce
				int sym = rules.GetHeadSymbol(target);
				Debug.Assert(symbols.IsNonterminal(sym));
				token = PeekToken();
				if (TrimReductions && rulesTable[target].Length == 2) {
					token.Symbol = sym;
					PopStates(1);
				} else {
					int count = rulesTable[target].Length - 1;
					int start = tokenStackTop + 1 - count;
					Debug.Assert(start >= 0);
					object obj = nonterminalFactory(target, tokenStack, start, count);
					token = new Token(sym, obj);
					token.Position = tokenStack[start].Position;
					PopStates(count);
					PopTokens(count);
					PushToken(token);
				}

				currentState = PeekState();

				// Goto
				actions = stateTable[currentState];
				actionIndex = FindAction(actions, sym);
#if DEBUG
				if (actionIndex < 0) {
					Error(new InvalidParserTable(UnitLALRParser._, currentState, sym));
					return Result;
				}
#endif

#if DEBUG
				action = (ushort)(actions[actionIndex + 1] & cActionMask);
				if (action != states.GotoAction) {
					Error(new InvalidParserTable(UnitLALRParser._, currentState, sym, action));
					return Result;
				}
#endif
				target = (ushort)(actions[actionIndex + 1] & cTargetMask);
				PushState(target);
			}

		//	return Result;
		}

		#endregion

	}

	#region UnitTinyParser
	public sealed class UnitTinyParser : ClassUnit
	{
		private UnitTinyParser() : base(typeof(TinyParser), UnitTiny._) { }
		public static readonly UnitTinyParser _ = new UnitTinyParser();
		public static UnitTinyParser Instance => _;
	}
	#endregion
}
