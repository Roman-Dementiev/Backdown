﻿using System;
using System.Reflection;
using Dwarf.Config;
using Dwarf.Utility;
using Dwarf.Logging;
#pragma warning disable RCS1060, RCS1023


namespace Dwarf
{
	/// <summary>
	/// Unit kinds
	/// </summary>
	public enum UnitKind
	{
		/// <summary>
		/// Root unit
		/// </summary>
		Root,

		/// <summary>
		/// Namespace unit
		/// </summary>
		Namespace,

		/// <summary>
		/// Interface unit
		/// </summary>
		Interface,

		/// <summary>
		/// Class unit
		/// </summary>
		Class,

		/// <summary>
		/// Utility unit
		/// </summary>
		Utility
	}

	/// <summary>
	/// Represent unit
	/// </summary>
	public class Unit : GConfigurable<Unit>
	{
		public const char cSeparator = '.';

		/// <summary>
		/// The instance of Root unit
		/// </summary>
		private static readonly Unit root = new Unit();

		#region Events
		public delegate void EventHandler(Unit unit);

		public static event EventHandler OnInitialize;
		public static event EventHandler OnConfigure;
		private static LogLevel logEvents = LogLevel.None;

		public static LogLevel LogEvents
		{
			get { return logEvents; }
			set {
				if (value == logEvents)
					return;
				if (logEvents != LogLevel.None) {
					OnInitialize -= LogInitialize;
					OnConfigure -= LogConfigure;
				}
				if (value != LogLevel.None) {
					OnInitialize += LogInitialize;
					OnConfigure += LogConfigure;
				}
				logEvents = value;
			}
		}
		#endregion

		#region Constructors
		/// <summary>
		/// Initializes a new instance of the <see cref="Unit" /> class.
		/// </summary>
		/// <param name="name">Name of the unit.</param>
		/// <param name="kind">Kind of the unit.</param>
		/// <param name="type">Type information for the unit.</param>
		/// <param name="parent">The parent class unit for nested types; 
		/// otherwise namespace unit or <c>null</c> for global namespaces.</param>
		protected Unit(string name, UnitKind kind, System.Type type, Unit parent)
		{
			Name = name;
			Kind = kind;
			Type = type;
			Cookie = null;
			Parent = parent ?? root;

			Parent.GetChildren().Add(this);
			OnInitialize?.Invoke(this);
		}


		/// <summary>
		/// Private constructor for root unit
		/// </summary>
		private Unit()
		{
			Kind = UnitKind.Root;
			Name = String.Empty;
			Type = null;
			Cookie = null;
			Parent = null;

//			LogEvents = LogLevel.DebugOnly;
		}
		#endregion

		#region Properties
		/// <summary>
		/// Fully qualified name of this unit
		/// </summary>
		public string FullName {
			get {
				if (Parent == null || Parent == root) {
					return Name;
				} else {
					return Parent.FullName + cSeparator + Name;
				}
			}
		}

		/// <summary>
		/// Unqualified name of this unit
		/// </summary>
		public string Name { get; }

		/// <summary>
		/// Kind of this unit.
		/// </summary>
		public UnitKind Kind { get; }

		/// <summary>
		/// Type of this unit, <c>null</c> for Root and Namespace
		/// </summary>
		public System.Type Type { get; }

		/// <summary>
		/// Gets or sets the user defined data for this unit.
		/// </summary>
		/// <value>
		/// The cookie.
		/// </value>
		public object Cookie { get; set; }

		/// <summary>
		/// Gets the parent class for nested class unit; otherwise namespace or root unit;
		/// </summary>
		/// <value>
		/// The parent.
		/// </value>
		public Unit Parent { get; }

		/// <summary>
		/// Namespace of this unit or <c>null</c> for root and global namespaces.
		/// </summary>
		public NamespaceUnit Namespace {
			get {
				if (Parent == null || Parent == root) {
					return null;
				}
				if (Parent is NamespaceUnit) {
					return Parent as NamespaceUnit;
				} else {
					return Parent.Namespace;
				}
			}
		}

		/// <summary>
		/// Gets the instance of Root unit.
		/// </summary>
		/// <value>
		/// The root.
		/// </value>
		public static Unit Root => root;

		/// <summary>
		/// Gets a value indicating whether this instance is root.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is root; otherwise, <c>false</c>.
		/// </value>
		public bool IsRoot => (Kind == UnitKind.Root);
		
		/// <summary>
		/// Gets a value indicating whether this instance is namespace.
		/// </summary>
		/// <value>
		/// <c>true</c> if this instance is namespace; otherwise, <c>false</c>.
		/// </value>
		public bool IsNamespace => (Kind == UnitKind.Namespace);

		/// <summary>
		/// Gets a value indicating whether this instance is interface.
		/// </summary>
		/// <value>
		/// <c>true</c> if this instance is interface; otherwise, <c>false</c>.
		/// </value>
		public bool IsInterface => (Kind == UnitKind.Interface);

		/// <summary>
		/// Gets a value indicating whether this instance is class.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is class; otherwise, <c>false</c>.
		/// </value>
		public bool IsClass => (Kind == UnitKind.Class);

		/// <summary>
		/// Gets a value indicating whether this instance is utility.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is utility; otherwise, <c>false</c>.
		/// </value>
		public bool IsUtility => (Kind == UnitKind.Utility);
		#endregion

		#region Methods
		/// <summary>
		/// Returns a <see cref="System.String" /> that represents this instance.
		/// </summary>
		/// <returns>
		/// The full name of the unit.
		/// </returns>
		public override string ToString() => FullName;

		/// <summary>
		/// Configures this instance from specified configuration.
		/// </summary>
		/// <param name="config">The configuration.</param>
		public override void Configure(IConfig config)
		{
			base.Configure(config);
			OnConfigure?.Invoke(this);
		}

		/// <summary>
		/// Determines whether this unit has a child with specified name.
		/// </summary>
		/// <param name="name">The name.</param>
		/// <returns><c>true</c> if this unit has such child; <c>false</c> otherwise</returns>
		public bool HasChild(string name)
		{
			if (String.IsNullOrEmpty(name)) {
				throw new ArgumentNullException(nameof(name));
			}

			if (Children != null) {
				foreach (Unit child in Children) {
					if (child.Name == name) {
						return true;
					}
				}
			}
			return false;
		}

		/// <summary>
		/// Gets the child by name.
		/// </summary>
		/// <param name="name">The name.</param>
		/// <returns>The child; <c>null</c> if it does not exists.</returns>
		public Unit GetChild(string name)
		{
			if (String.IsNullOrEmpty(name)) {
				throw new ArgumentNullException(nameof(name));
			}

			if (Children != null) {
				foreach (Unit child in Children) {
					if (child.Name == name) {
						return child;
					}
				}
			}
			return null;
		}

		/// <summary>
		/// Determines whether this unit contains a unit with specified partial name.
		/// </summary>
		/// <param name="partiallName">The partial name.</param>
		/// <returns><c>true</c> if this unit has such unit; <c>false</c> otherwise</returns>
		public bool HasUnit(string partialName)
		{
			if (String.IsNullOrEmpty(partialName)) {
				throw new ArgumentNullException(nameof(partialName));
			}

			string[] names = SplitName(partialName);
			if (names == null) {
				throw new ArgumentException("Invalid partialName in Unit.HasUnit()", partialName);
			}

			if (Children == null)
				return false;

			Unit unit = this;
			for (int i = 0; i < names.Length; i++) {
				unit = unit.GetChild(names[i]);
				if (unit == null)
					return false;
			}

			return true;
		}

		/// <summary>
		/// Gets the unit by its partial name.
		/// </summary>
		/// <param name="partialName">The partial name.</param>
		/// <returns>The unit; <c>null</c> if it does not exists.</returns>
		public Unit GetUnit(string partialName)
		{
			if (String.IsNullOrEmpty(partialName)) {
				throw new ArgumentNullException(nameof(partialName));
			}

			string[] names = SplitName(partialName);
			if (names == null) {
				throw new ArgumentException("Invalid partialName in Unit.GetUnit()", partialName);
			}

			if (Children == null)
				return null;

			Unit unit = this;
			for (int i = 0; i < names.Length; i++) {
				unit = unit.GetChild(names[i]);
				if (unit == null)
					break;
			}

			return unit;
		}

		/// <summary>
		/// Determines whether a unit with specified full name exists.
		/// </summary>
		/// <param name="fullName">The full name.</param>
		/// <returns><c>true</c> if such unit exists; <c>false</c> otherwise</returns>
		public static bool Exists(string fullName)
		{
			return root.HasUnit(fullName);
		}

		/// <summary>
		/// Gets the unit by its full name.
		/// </summary>
		/// <param name="fullName">The full name.</param>
		/// <returns>The unit; <c>null</c> if it does not exists.</returns>
		public static Unit Get(string fullName)
		{
			return root.GetUnit(fullName);
		}

		public static void InitAssemblyUnits<TUnit>(Assembly assembly) where TUnit : Unit
		{
			Reflection.InitSingletons(assembly, typeof(TUnit));
		}

		public static void InitAssemblyUnits(Assembly assembly)
		{
			Reflection.InitSingletons(assembly, typeof(Unit));
		}

		public static void InitDwarfUnits<TUnit>() where TUnit : Unit
		{
			Assembly assembly = Assembly.GetExecutingAssembly();
			Reflection.InitSingletons(assembly, typeof(TUnit), true);
		}

		public static void InitDwarfUnits()
		{
			Assembly assembly = Assembly.GetExecutingAssembly();
			Reflection.InitSingletons(assembly, typeof(Unit), true);
		}

		public static string[] SplitName(string name)
		{
			string[] names = name.Split(cSeparator);
			if (names.Length == 0)
				return null;

			for (int i = 0; i < names.Length; i++) {
				if (String.IsNullOrWhiteSpace(names[i])) {
					return null;
				}

				names[i] = names[i].Trim();
			}
			return names;
		}

		public static void LogInitialize(Unit unit)
			=> Log.Write(logEvents, (string)null, "Initializing unit {0}", unit.FullName);

		public static void LogConfigure(Unit unit)
			=> Log.Write(logEvents, (string)null, "Configuring unit {0]", unit.FullName);
		#endregion
	}


	/// <summary>
	/// Represent unit for namespace
	/// </summary>
	public class NamespaceUnit : Unit
	{
		/// <summary>
		/// Initializes a new instance of NamespaceUnit.
		/// </summary>
		/// <param name="name">Unqualified name of the unit</param>
		/// <param name="ns">Namespace of the unit or <c>null</c></param>
		public NamespaceUnit(string name, NamespaceUnit ns) :
			base(name, UnitKind.Namespace, null, ns)
		{
		}
	}

	/// <summary>
	/// Represent unit for interface
	/// </summary>
	public class InterfaceUnit : Unit
	{
		/// <summary>
		/// Initializes a new instance of InterfaceUnit.
		/// </summary>
		/// <param name="type">Type information for the unit.</param>
		/// <param name="parent">The parent class unit for nested interface; otherwise namespace unit or <c>null</c>.</param>
		public InterfaceUnit(Type type, Unit parent) :
			base(type.Name, UnitKind.Interface, type, parent)
		{
		}
	}

	/// <summary>
	/// Represent unit for class
	/// </summary>
	public class ClassUnit : Unit
	{
		/// <summary>
		/// Initializes a new instance of ClassUnit.
		/// </summary>
		/// <param name="type">Type information for the unit.</param>
		/// <param name="parent">The parent class unit for nested class; otherwise namespace unit or <c>null</c>.</param>
		public ClassUnit(Type type, Unit parent) :
			base(type.Name, UnitKind.Class, type, parent)
		{
		}
	}

	/// <summary>
	/// Represent unit for utility (static) class
	/// </summary>
	public class UtilityUnit : Unit
	{
		/// <summary>
		/// Initializes a new instance of UtilityUnit.
		/// </summary>
		/// <param name="type">Type information for the unit.</param>
		/// <param name="parent">The parent class unit for nested class; otherwise namespace unit or <c>null</c>.</param>
		public UtilityUnit(Type type, Unit parent) :
			base(type.Name, UnitKind.Utility, type, parent)
		{
		}
	}

}
