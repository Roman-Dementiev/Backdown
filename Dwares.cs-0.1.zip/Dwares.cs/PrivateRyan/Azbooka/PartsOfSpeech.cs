﻿using System;
using System.Collections.Generic;
using System.Threading;
using Dwarf.ObjectModel;
using Dwarf.Extensions;
using Dwarf.Platform;


namespace Azbooka
{
	public class PoS : Entity, IChoice
	{
		public PoS(string uid, string abbr, string name) :
			base(uid)
		{
			var split = uid.Split('-');
			if (split.Length > 1) {
				Tag = split[1];
				LanguageTag = split[0];
			} else {
				Tag = uid;
				LanguageTag = String.Empty;
			}
			Abbr = abbr ?? throw new ArgumentNullException(nameof(abbr));
			Name = name ?? throw new ArgumentNullException(nameof(name));
		}

		public string Tag { get; }
		public string LanguageTag { get; }
		public string Abbr { get; }
		public ICommand Command { 
			get => null;
			set => throw new NotImplementedException();
		}

		public Language Language => LazyInitializer.EnsureInitialized(ref language, () => Languages.GetOrAdd(LanguageTag));
		Language language = null;

		public Bitmap ChoiceImage => Bitmap.Null;
		public string ChoiceLabel => Abbr;
		public Bitmap PopupImage => Bitmap.Null;
		public string PopupLabel => Name;
		public virtual string ChoiceToolTip(ChoiceAppearance appearance) => appearance.DefaultChoiceTolTip(this);
	}

	public class LanguagePoSList : List<PoS>
	{
		public LanguagePoSList(string languageTag)
		{
			LanguageTag = languageTag;
		}

		public string LanguageTag { get; }

		public PoS GetPoS(string tag)
		{
			foreach (var PoS in this) {
				if (PoS.Tag == tag) 
					return PoS;
			}
			return null;
		}
	}

	public partial class PartsOfSpeech : Dictionary<string, LanguagePoSList>
	{
		const string cGeneralTag = "@";

		public PartsOfSpeech(AzbookaDb Db)
		{
			LoadFromResources();
//			this[cGeneralTag] = generalPoS;

			if (Db != null) {
				var data = Db.GetPoS();
				if (data.Count > 0) {
					foreach (var PoS in data)
					{
						LanguagePoSList languagePoS;
						if (!TryGetValue(PoS.LanguageTag, out languagePoS)) {
							languagePoS = new LanguagePoSList(PoS.LanguageTag);
							this[PoS.LanguageTag] = languagePoS;
						}
						languagePoS.Add(PoS);
					}
				}
			}

			if (ContainsKey(cGeneralTag)) {
				generalPoS = this[cGeneralTag];
			} else {
				generalPoS = LoadFromResources(cGeneralTag);
				this[cGeneralTag] = generalPoS;
			}
		}

		public LanguagePoSList GeneralPoS => Abc.Instance.PartsOfSpeech.generalPoS;
		LanguagePoSList generalPoS;

		public static LanguagePoSList GetLanguagePoSList(string languageTag)
		{
			return Abc.Instance.PartsOfSpeech.GetValue(languageTag);
		}

		public static PoS GetPoS(string languageTag, string tag)
		{
			var list = GetLanguagePoSList(languageTag);
			return list?.GetPoS(tag);
		}
	}
}
