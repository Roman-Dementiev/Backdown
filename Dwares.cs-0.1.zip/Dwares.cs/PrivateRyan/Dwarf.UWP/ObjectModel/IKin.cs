﻿using System;
using System.Collections.Generic;


namespace Dwarf.ObjectModel
{
	public interface IKin
	{
		IKin Parent { get; }
		IEnumerable<IKin> Children { get; }
	}

	public interface IKin<TKin> : IKin
	{
		new TKin Parent { get; }
		new IEnumerable<TKin> Children { get; }
	}

	public static partial class Extensions
	{
		public static int KinLevel(this IKin kin)
		{
			int level = 0;
			while (kin.Parent != null) {
				level++;
				kin = kin.Parent;
			}
			return level;
		}
	}
}
