﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Dwarf.Extensions
{
	public static class Enumerable
	{
		public static int GetCount(this IEnumerable enumerable)
		{
			if (enumerable is ICollection collection) {
				return collection.Count;
			}

			int count = 0;
			foreach (var item in enumerable) {
				count++;
			}
			return count;
		}

		public static List<object> GetRange(this IList list, int start) => GetRange(list, start, list.Count - start);

		public static List<object> GetRange(this IList list, int start, int count)
		{
			var range = new List<object>();
			for (int i = 0, index = start; i < count; i++) {
				range.Add(list[index++]);
			}
			return range;
		}

		public static List<TItem> GetRange<TItem>(this IList<TItem> list, int start) => GetRange(list, start, list.Count - start);

		public static List<TItem> GetRange<TItem>(this IList<TItem> list, int start, int count)
		{
			var range = new List<TItem>();
			for (int i = 0, index = start; i < count; i++) {
				range.Add(list[index++]);
			}
			return range;
		}

		public static void AddRange(this IList list, IEnumerable enumerable)
		{
			foreach (var item in enumerable)
			{
				list.Add(item);
			}
		}

		public static void AddItems<TItem>(this ICollection<TItem> collection, IEnumerable<TItem> enumerable)
		{
			foreach (var item in enumerable) {
				collection.Add(item);
			}
		}

		public static void AddItems<TItem>(this IList list, IEnumerable enumerable, bool skipIfWrongType = true)
		{
			foreach (var obj in enumerable)
			{
				if (skipIfWrongType) {
					if (obj is TItem item) {
						list.Add(item);
					}
				} else {
					list.Add((TItem)obj);
				}
			}
		}

		public static ArrayList ToArrayList(this IEnumerable enumerable)
		{
			if (enumerable is ICollection collection) {
				return new ArrayList(collection);
			}

			var list = new ArrayList();
			list.AddRange(enumerable);
			return list;
		}

		public static List<TItem> ToList<TItem>(this IEnumerable enumerable, bool skipIfWrongType = true)
		{
			if (enumerable is ICollection<TItem> collection) {
				return new List<TItem>(collection);
			}

			var list = new List<TItem>();
			list.AddRange(enumerable);
			return list;
		}

		public static List<TItem> ToList<TItem>(this IEnumerable<TItem> enumerable)
		{
			if (enumerable is ICollection<TItem> collection) {
				return new List<TItem>(collection);
			}

			var list = new List<TItem>();
			list.AddRange(enumerable);
			return list;
		}

		public static IEnumerable<TItem> AsEnumerable<TItem>(this TItem obj) where TItem : class
		{
			return new SingleEnumarable<TItem>(obj);
		}

		internal class SingleEnumarable<T> : IEnumerable<T> where T : class
		{
			T obj;

			internal SingleEnumarable(T obj)
			{
				this.obj = obj;
			}

			public IEnumerator<T> GetEnumerator()
			{
				return new Emumerator(obj);
			}

			IEnumerator IEnumerable.GetEnumerator()
			{
				return new Emumerator(obj);
			}

			class Emumerator : IEnumerator<T>
			{
				T obj;
				T current;
				bool atStart;

				public Emumerator(T obj)
				{
					this.obj = obj;
					current = null;
					atStart = true;
				}
				public void Dispose() { }

				public T Current => current;
				object IEnumerator.Current => current;

				public bool MoveNext()
				{
					if (atStart) {
						current = obj;
						atStart = false;
						return true;
					} else {
						current = null;
						return false;
					}
				}

				public void Reset()
				{
					current = null;
					atStart = true;
				}
			}
		}
	}
}
