﻿using System;
using Windows.UI.Xaml.Controls;
using Dwarf.ObjectModel;


namespace Azbooka
{
	public partial class Abc
	{
		public MainPage MainPage { get; set; }
		public Frame ContentFrame => MainPage.ContentFrame;
		public Page ContentPage => MainPage.ContentPage;

		EntityCollection<DirectoryItem> InitDirectory()
		{
			return new EntityCollection<DirectoryItem> {
				new DirectoryItem(typeof(DictionaryPage), "Dictionary"),
				new DirectoryItem(typeof(PhrasebookPage), "Phrasebook"),
				new DirectoryItem(typeof(BlankPage), "Thesaurus"),
				new DirectoryItem(typeof(BlankPage), "Grammar"),
				new DirectoryItem(typeof(BookshelfPage), "Bookshelf"),
				new DirectoryItem(typeof(BlankPage), "Quiz")
			};

			//secondary = new EntityCollection<DirectoryItem>();
			//secondary.Add(new DirectoryItem("Settings"));
			//secondary.Add(new DirectoryItem("About"));
		}
	}
}
