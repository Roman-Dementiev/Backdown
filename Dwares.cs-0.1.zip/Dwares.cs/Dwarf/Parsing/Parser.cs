﻿using System;
using System.IO;
using Dwarf.Config;
using Dwarf.Utility;

namespace Dwarf.Parsing
{
	/// <summary>
	/// Abstract class Parser
	/// </summary>
	/// <seealso cref="Dwarf.Utility.TextProcessor" />
	/// <seealso cref="Dwarf.Parsing.IParser" />
	public abstract class Parser : TextProcessor, IParser
	{
		#region Events
		public delegate void AcceptEventHandler(object sender, object result);
		public event AcceptEventHandler OnAccept;
		#endregion

		#region Properties
		/// <summary>
		/// Gets or sets a value indicating whether input was parsed successfully.
		/// </summary>
		/// <value>
		///   <c>true</c> if input was parsed successfully; otherwise, <c>false</c>.
		/// </value>
		public bool Accepted { get; protected set; } = false;
		#endregion

		#region Constructor
		/// <summary>
		/// Initializes a new instance of the <see cref="Parser"/> class.
		/// Sets error handler to <see cref="DwarfException.Log"/>.
		/// </summary>
		protected Parser()
		{
			OnError += DwarfException.Log;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="Parser"/> class.
		/// </summary>
		/// <param name="errorHandler">The error handler.</param>
		protected Parser(ExceptionHandler errorHandler)
		{
			if (errorHandler != null) {
				OnError += errorHandler;
			}
		}
		#endregion

		#region Methods
		/// <summary>
		/// Prepare for processing specified buffer.
		/// </summary>
		/// <param name="source">The buffer.</param>
		public override void Prepare(TextReader source)
		{
			base.Prepare(source);
			Accepted = false;
		}

		/// <summary>
		/// Parses input from the specified reader.
		/// </summary>
		/// <param name="reader">The reader.</param>
		/// <returns>The parsed object.</returns>
		public virtual object Parse(TextReader reader)
		{
			return Try(reader);
		}

		/// <summary>
		/// Parses the specified stream.
		/// </summary>
		/// <param name="stream">The stream.</param>
		/// <returns>The parsed object.</returns>
		public virtual object Parse(Stream stream)
		{
			using (StreamReader reader = new StreamReader(stream)) {
				return Parse(reader);
			}
		}

		/// <summary>
		/// Parses the specified text.
		/// </summary>
		/// <param name="text">The text.</param>
		/// <returns>The parsed object.</returns>
		public virtual object ParseText(string text)
		{
			using (StringReader reader = new StringReader(text)) {
				return Parse(reader);
			}
		}

		/// <summary>
		/// Parses the specified buffer.
		/// </summary>
		/// <param name="buffer">The buffer.</param>
		/// <returns>The parsed object.</returns>
		public virtual object ParseData(byte[] buffer)
		{
			using (MemoryStream stream = new MemoryStream(buffer)) {
				return Parse(stream);
			}
		}

		/// <summary>
		/// Parses the file.
		/// </summary>
		/// <param name="path">The path.</param>
		/// <summary>
		/// Parses the file with the specified path.
		/// </summary>
		/// <param name="path">The path.</param>
		/// <returns>The parsed object.</returns>
		public virtual object ParseFile(string path)
		{
			using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read)) {
				return Parse(stream);
			}
		}

		/// <summary>
		/// Validates input from the specified reader.
		/// </summary>
		/// <param name="reader">The reader.</param>
		/// <returns><c>true</c> if input is valid; otherwise <c>false</c></returns>
		public virtual bool Validate(TextReader reader)
		{
			Parse(reader);
			return Accepted;
		}

		/// <summary>
		/// Validates the input from the specified stream.
		/// </summary>
		/// <param name="stream">The stream.</param>
		/// <returns><c>true</c> if input is valid; otherwise <c>false</c></returns>
		public virtual bool Validate(Stream stream)
		{
			using (StreamReader reader = new StreamReader(stream)) {
				return Validate(reader);
			}
		}

		/// <summary>
		/// Validates the specified text.
		/// </summary>
		/// <param name="text">The text.</param>
		/// <returns><c>true</c> if input is valid; otherwise <c>false</c></returns>
		public virtual bool Validate(string text)
		{
			using (StringReader reader = new StringReader(text)) {
				return Validate(reader);
			}
		}

		/// <summary>
		/// Validates the specified buffer.
		/// </summary>
		/// <param name="buffer">The buffer.</param>
		/// <returns><c>true</c> if input is valid; otherwise <c>false</c></returns>
		public virtual bool Validate(byte[] buffer)
		{
			using (MemoryStream stream = new MemoryStream(buffer)) {
				return Validate(stream);
			}
		}

		/// <summary>
		/// Validates the file with the specified path.
		/// </summary>
		/// <param name="path">The path.</param>
		/// <returns><c>true</c> if input is valid; otherwise <c>false</c></returns>
		public virtual bool ValidateFile(string path)
		{
			using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read)) {
				return Validate(stream);
			}
		}

		protected void Accept(object result)
		{
			Result = result;
			Accepted = true;
			OnAccept?.Invoke(this, result);
		}

		protected override DwarfException UnknownError(Exception exc)
		{
			return new ParserInternalError(UnitParser._, exc);
		}
		#endregion
	}

	#region UnitBaseParser
	#pragma warning disable RCS1060, RCS1023
	public sealed class UnitParser : ClassUnit
	{
		private UnitParser() : base(typeof(Parser), UnitParsing._) { }
		public static readonly UnitParser _ = new UnitParser();
		public static UnitParser Instance => _;
	}
	#endregion
}
