﻿using System;
using Windows.UI.Xaml.Media.Imaging;
using Dwarf.Extensions;


namespace Dwarf.Platform
{
	public class BitmapBuffer : IBitmapLoader
	{
		byte[] buffer;

		public BitmapBuffer(byte [] buffer)
		{
			this.buffer = buffer ?? throw new ArgumentNullException(nameof(buffer));
		}

		public BitmapImage LoadBitmapImage()
		{
			var image = new BitmapImage();
			image.LoadFromBuffer(buffer);
			return image;
		}

		public bool CanLoadData() => true;
		public byte[] LoadBitmapData() => buffer;

	}
}
