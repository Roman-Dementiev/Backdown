﻿using System;
using System.Collections.Generic;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Config
{
	/// <summary>
	/// Class Configurable
	/// </summary>
	/// <seealso cref="Dwarf.Config.GConfigurable{Dwarf.Config.IConfigurable}" />
	public class Configurable : GConfigurable<IConfigurable>
	{
	}

	/// <summary>
	/// Generic class GConfigurable
	/// </summary>
	public class GConfigurable<T> : IConfigurable where T : IConfigurable
	{
		#region Properties
		/// <summary>
		/// Determines whether this instance is configured.
		/// </summary>
		public bool IsConfigured { get; protected set; } = false;

		/// <summary>
		/// Gets the configuration.
		/// </summary>
		/// <value>
		/// The configuration.
		/// </value>
		public IConfig Config { get; protected set; } = null;

		/// <summary>
		/// Gets children of this instance
		/// </summary>
		/// <value>
		/// List of children or <c>null</c> if there is no ones.
		/// </value>
		public List<T> Children { get; protected set; } = null;
		#endregion

		#region Methods
		/// <summary>
		/// Gets children of this instance. Create empty list if there is no ones.
		/// </summary>
		/// <value>
		/// List of dependencies
		/// </value>
		public List<T> GetChildren()
		{
			if (Children == null) {
				Children = new List<T>();
			}
			return Children;
		}

		/// <summary>
		/// Configures this instance from specified configuration.
		/// </summary>
		/// <param name="config">The configuration.</param>
		public virtual void Configure(IConfig config)
		{
			Config = config;
			IsConfigured = true;
		}

		/// <summary>
		/// Configures or reconfigures this instance and optionally it's children.
		/// </summary>
		/// <param name="config">The configuration.</param>
		/// <param name="configureChildren">if set to <c>true</c> configure children of this instance.</param>
		/// <param name="reconfigure">if set to <c>true</c> reconfigure this instance and it's children.</param>
		public virtual void Configure(IConfig config, bool configureChildren, bool reconfigure)
		{
			if (reconfigure) {
				if (config == null)
					config = Config;
			} else {
				if (config == Config)
					return;
			}

			Configure(config);

			if (configureChildren && Children != null) {
				foreach (IConfigurable child in Children) {
					child.Configure(config, true, reconfigure);
				}
			}
		}

		public void Reconfigure()
		{
			Configure(null, true, true);
		}

		/// <summary>
		/// Sets <see cref="Config"/> to <c>null</c> and optionally reset all values to defaults.
		/// </summary>
		/// <param name="unconfigure">if <c>true</c> sets <see cref="IsConfigured"/> to false and reset default values.</param>
		public virtual void ResetConfig(bool unconfigure)
		{
			Config = null;
			if (unconfigure) {
				IsConfigured = false;
			}

			if (Children != null) {
				foreach (IConfigurable child in Children) {
					child.ResetConfig(unconfigure);
				}
			}
		}
		#endregion
	}

	#region UnitConfigurable
	public sealed class UnitConfigurable : ClassUnit
	{
		private UnitConfigurable() : base(typeof(Configurable), UnitConfig._) { }
		public static readonly UnitConfigurable _ = new UnitConfigurable();
		public static UnitConfigurable Instance => _;
	}
	#endregion

	#region UnitGConfigurable
	public sealed class UnitGConfigurable : ClassUnit
	{
		private UnitGConfigurable() : base(typeof(GConfigurable<>), UnitConfig._) { }
		public static readonly UnitGConfigurable _ = new UnitGConfigurable();
		public static UnitGConfigurable Instance => _;
	}
	#endregion
}
