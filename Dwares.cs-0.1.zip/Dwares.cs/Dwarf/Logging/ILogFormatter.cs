﻿using System;

namespace Dwarf.Logging
{
	/// <summary>
	/// Interface ILogFormatter
	/// </summary>
	public interface ILogFormatter
	{
		#region Properties
		/// <summary>
		/// Gets or sets the number of spaces in an indent.
		/// </summary>
		/// <value>
		/// The number of spaces in an indent.
		/// </value>
		uint IndentSize { get; set; }

		/// <summary>
		/// Gets or sets the indent level.
		/// </summary>
		/// <value>
		/// The indent level.
		/// </value>
		uint IndentLevel { get; }
		#endregion

		#region Methods
		/// <summary>
		/// Increases the current IndentLevel by one.
		/// </summary>
		void Indent();

		/// <summary>
		/// Decreases the current IndentLevel by one.
		/// </summary>
		void Unindent();

		/// <summary>
		/// Formats the message.
		/// </summary>
		/// <param name="level">The level.</param>
		/// <param name="source">The source.</param>
		/// <param name="message">The message.</param>
		/// <returns></returns>
		string Format(LogLevel level, string source, string message);

		/// <summary>
		/// Formats the message using specified format and arguments.
		/// </summary>
		/// <param name="level">Log level.</param>
		/// <param name="source">The source.</param>
		/// <param name="format">The format string.</param>
		/// <param name="args">The arguments.</param>
		/// <returns></returns>
		string Format(LogLevel level, string source, string format, params object[] args);
		#endregion
	}

	#region UnitILogFormatter
	#pragma warning disable RCS1060, RCS1023
	public sealed class UnitILogFormatter : InterfaceUnit
	{
		private UnitILogFormatter() : base(typeof(ILogFormatter), UnitLogging._) {}
		public static readonly UnitILogFormatter _ = new UnitILogFormatter();
		public static UnitILogFormatter Instance => _;
	}
	#endregion
}
