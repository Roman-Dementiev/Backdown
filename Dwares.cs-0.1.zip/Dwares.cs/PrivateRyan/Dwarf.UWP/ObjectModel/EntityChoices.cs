﻿using System;
using System.Collections;
using System.Collections.Generic;
using Dwarf.Collections;
using Dwarf.Platform;


namespace Dwarf.ObjectModel
{
	public class EntityChoices<TEntity> : Choices<TEntity> where TEntity : class, IEntity
	{
		public EntityChoices(IList<TEntity> source, SelectChoice select = SelectChoice.First) : base(source, select) { }

		protected override IChoice CreateAdapter(TEntity entity)
		{
			return new EntityChoice<TEntity>(entity);
		}
	}


	public class EntityChoice<TEntity> : IChoice, ISourced<TEntity> where TEntity : IEntity
	{
		public EntityChoice(TEntity entity)
		{
			Source = entity;
		}

		public TEntity Source { get; set; }
		public ICommand Command { get; set; }

		public Bitmap ChoiceImage => Source.Icon;
		public string ChoiceLabel => Source.Name;
		public Bitmap PopupImage => Source.Icon;
		public string PopupLabel => Source.Name;
		public virtual string ChoiceToolTip(ChoiceAppearance appearance) => appearance.DefaultChoiceTolTip(this);
	}
}
