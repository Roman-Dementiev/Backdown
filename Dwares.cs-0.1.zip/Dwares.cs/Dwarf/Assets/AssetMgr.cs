﻿using System;
using System.Collections;
using Dwarf.Utility;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Assets
{
	/// <summary>
	/// Class AssetMgr
	/// </summary>
	public class AssetMgr : Manager<AssetMgr, object, IAssets, MultiCulturalAssets>, IAssets
	{
		#region Fields
		private static object defaultCulture = null;
		private static object languageCulture = null;
		#endregion)

		#region Constructors
		public AssetMgr()
		{
			source = new CommonAssets();
		}

		public AssetMgr(IAssets assets)
		{
			source = assets;
		}

		public AssetMgr(object culture, bool multiCultural = false)
		{
			if (culture != null) {
				source = new CultureAssets(culture);
			} else if (multiCultural) {
				source = new MultiCulturalAssets();
			} else {
				source = new CommonAssets();
			}
		}

		public AssetMgr(MakeCurrentMode mode, IAssets assets = null) :
			this(assets)
		{
			MakeCurrent(mode);
		}

		public AssetMgr(MakeCurrentMode mode, object culture, bool multiCultural = false) :
			this(culture, multiCultural)
		{
			MakeCurrent(mode);
		}
		#endregion

		#region Properties
		public static object DefaultCulture {
			get { return defaultCulture; }
			set {
				if (!KeepAllCultures && defaultCulture != null &&
					defaultCulture != languageCulture &&
					!defaultCulture.Equals(value))
				{
					ReleaseCulture(defaultCulture, false);
				}
				defaultCulture = value;
			}
		}

		public static object LanguageCulture {
			get { return languageCulture; }
			set {
				if (!KeepAllCultures && languageCulture != null &&
					languageCulture != defaultCulture &&
					!languageCulture.Equals(value))
				{
					ReleaseCulture(languageCulture, false);
				}
				languageCulture = value;
			}
		}

		public static string Language {
			get { return languageCulture?.ToString(); }
			set { LanguageCulture = value; }
		}

		public static bool KeepAllCultures { get; set; } = false;

		public object Culture => source?.Culture;

		public bool IsMultiCultural => source != null ? source.IsMultiCultural : false;

		public object this[string key, Type type, object culture = null] {
			get { return GetAsset(key, type, culture); }
			set { AddAsset(key, value, culture); }
		}

		#endregion

		#region Methods
		public virtual object GetDefaultCulture(Type type = null)
		{
			if (type == typeof(string) && languageCulture != null) {
				return languageCulture;
			} else {
				return defaultCulture;
			}
		}

		public IEnumerable GetCultures()
			=> source?.GetCultures();

		public virtual bool HasAsset(string key, object culture = null)
			=> source != null && source.HasAsset(key, culture ?? GetDefaultCulture());

		public virtual object GetAsset(string key, object culture = null) 
			=> source?.GetAsset(key, culture ?? GetDefaultCulture());

		public virtual object GetAsset(string key, Type type, object culture = null)
			=> BaseAssets.GetAsset(this, key, type, culture ?? GetDefaultCulture(type));

		public virtual void AddAsset(string key, object asset, object culture = null)
			=> GetSource().AddAsset(key, asset, culture ?? GetDefaultCulture());

		public virtual void AddString(string key, string value, object culture = null)
			=> AddAsset(key, value ?? String.Empty, culture ?? GetDefaultCulture());

		public virtual void ReleaseAllAssets(bool dispose)
			=> source?.ReleaseAllAssets(dispose);

		public virtual void ReleaseCultureAssets(object culture, bool dispose)
			=> source?.ReleaseCultureAssets(culture, dispose);


		#endregion

		#region Static Methods
		public static object GetAsset(string key, Type type) =>
			GetManaged(mgr => mgr.GetAsset(key, type, null));

		public static TAsset GetAsset<TAsset>(string key) where TAsset : class =>
			GetAsset(key, typeof(TAsset)) as TAsset;

		public static string GetString(string key, bool useKeyAsDefault = true) =>
			GetAsset<string>(key) ?? (useKeyAsDefault ? key : null);

		public static byte[] GetBinary(string key) =>
			GetAsset<byte[]>(key);

		public static void SetDefaultString(string key, string value) =>
			Default.AddString(key, value);

		public static void SetDefaultStrings(params string[] keysAndValues)
		{
			AssetMgr mgr = Default;
			if (keysAndValues != null) {
				for (int i = 1; i < keysAndValues.Length; i += 2) {
					mgr.AddString(keysAndValues[i-1], keysAndValues[i]);
				}
			}
		}

		public static void ReleaseAll(bool dispose) =>
			ForEach(Current, mgr => mgr.ReleaseAllAssets(dispose));

		public static void ReleaseCulture(object culture, bool dispose) =>
			ForEach(Current, mgr => mgr.ReleaseCultureAssets(culture, dispose));

		#endregion
	}

	#region UnitAssetMgr
	public sealed class UnitAssetMgr : ClassUnit
	{
		private UnitAssetMgr() : base(typeof(AssetMgr), UnitAssets._) { }
		public static readonly UnitAssetMgr _ = new UnitAssetMgr();
		public static UnitAssetMgr Instance => _;
	}
	#endregion
}
