﻿using System;
using System.Threading;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml;
using Windows.UI;
using Dwarf.Localization;

namespace Dwarf.UI
{
	public static class UI
	{
		public static FrameworkElement Element(UIElement view, string name, bool required = false) => Reflection.GetPropertyValue(view, name, required) as FrameworkElement;
		public static Image Image(UIElement view, string name, bool required = false) => Reflection.GetPropertyValue(view, name, required) as Image;
		public static TextBlock TextBlock(UIElement view, string name, bool required = false) => Reflection.GetPropertyValue(view, name, required) as TextBlock;


		public static class Colors {
			public static Color None => Color.FromArgb(0, 0, 0, 0);
			public static Color Transparent => Color.FromArgb(0, 0xFF, 0xFF, 0xFF);
			public static Color Black => Color.FromArgb(0xFF, 0, 0, 0);
			public static Color White => Color.FromArgb(0xFF, 0xFF, 0xFF, 0xFF);
		}

		public static bool IsTransparenz(Color color) => color.A == 0;


		public static class Brushes {
			//public static SolidColorBrush Transparent => System.Windows.Media.Brushes.Transparent;
			public static SolidColorBrush Transparent => LazyInitializer.EnsureInitialized(ref transparent, () => new SolidColorBrush(Colors.Transparent));
			public static SolidColorBrush transparent;

			public static SolidColorBrush Black => LazyInitializer.EnsureInitialized(ref black, () => new SolidColorBrush(Colors.Black));
			public static SolidColorBrush black;

			public static SolidColorBrush White => LazyInitializer.EnsureInitialized(ref white, () => new SolidColorBrush(Colors.White));
			public static SolidColorBrush white;
		}

		public static Color BrushColor(Brush brush)
		{
			if (brush is SolidColorBrush solid) {
				return solid.Color;
			} else {
				return Colors.None;
			}
		}

		public static bool IsNullBrush(Brush brush)
		{
			if (brush == null) {
				return true;
			} else if (brush is SolidColorBrush solid) {
				return solid.Color == Colors.None;
			} else {
				return false;
			}
		}

		public static bool IsTransparent(Brush brush, bool notFull = false)
		{
			if (brush == null) {
				return !notFull;
			} else if (brush is SolidColorBrush solid) {
				return solid.Color.A == 0;
			} else {
				return false;
			}
		}


		const string DefaultFontFamilyName = "Segoe UI";
		const string SymbolFontFamilyName = "Segoe UI Symbol";
		const string AssetsFontFamilyName = "Segoe MDL2 Assets";

		public static FontFamily DefaultFontFamily => LazyInitializer.EnsureInitialized(ref defaultFontFamily, () => new FontFamily(DefaultFontFamilyName));
		static FontFamily defaultFontFamily;

		public static FontFamily SymboslFontFamily => LazyInitializer.EnsureInitialized(ref symbolsFontFamily, () => new FontFamily(SymbolFontFamilyName));
		static FontFamily symbolsFontFamily;

		public static FontFamily AssetsFontFamily => LazyInitializer.EnsureInitialized(ref assetsFontFamily, () => new FontFamily(AssetsFontFamilyName));
		static FontFamily assetsFontFamily;

		public static bool IsDefaultFontFamily(FontFamily fontFamily) => fontFamily != null && fontFamily.Source == DefaultFontFamilyName;
		public static bool IsSymbolFontFamily(FontFamily fontFamily) => fontFamily != null && fontFamily.Source == SymbolFontFamilyName;
		public static bool IsAssetsFontFamily(FontFamily fontFamily) => fontFamily != null && fontFamily.Source == AssetsFontFamilyName;


		public static DependencyProperty RegisterDependencyProperty<TComponent, TValue>(string name, TValue defaultValue = default(TValue)) =>
			DependencyProperty.Register(name, typeof(TValue), typeof(TComponent), new PropertyMetadata(defaultValue));

		public static DependencyProperty RegisterAttachedProperty<TComponent, TValue>(string name, TValue defaultValue = default(TValue)) =>
			DependencyProperty.RegisterAttached(name, typeof(TValue), typeof(TComponent), new PropertyMetadata(defaultValue));


		public static TSettingsFlyout LocalizedSettingsFlyout<TSettingsFlyout>(bool addToLocalizer) where TSettingsFlyout : SettingsFlyout, new()
		{
			TSettingsFlyout flyout = new TSettingsFlyout();
			Localizer.Instance.AddHandler(typeof(TSettingsFlyout), typeof(SettingsFlyout));
			if (addToLocalizer) {
				Localizer.AddTarget(flyout);
			} else {
				Localizer.Localize(flyout);
			}
			return flyout;
		}

		public static TSettingsFlyout ShowSettingsFlyout<TSettingsFlyout>() where TSettingsFlyout : SettingsFlyout, new()
		{
			var flyout = LocalizedSettingsFlyout<TSettingsFlyout>(false);
			flyout.ShowIndependent();
			return flyout;
		}
	}
}
