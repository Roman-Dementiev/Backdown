﻿using System;
using System.ComponentModel;
using Windows.UI.Xaml.Controls;
using Dwarf.ObjectModel;


namespace Azbooka
{
	public sealed partial class EntityView : UserControl, IPropertyObserver
	{
		public EntityView()
		{
			this.InitializeComponent();
		}

		public Border Indent => indent;
		public Image Image => image;
		public TextBlock Label => label;

		public void OnPropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			var entity = sender as IEntity;
			if (entity == null)
				return;

			if (e.PropertyName == nameof(Entity.Name)) {
				label.Text = entity.ToString();
			} else if (e.PropertyName == nameof(Entity.Icon)) {
				image.Source = entity.Icon;
			}
		}
	}
}
