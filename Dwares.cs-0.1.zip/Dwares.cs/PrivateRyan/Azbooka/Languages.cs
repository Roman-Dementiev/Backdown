﻿using System;
using System.Collections.Generic;
using System.Threading;
using Dwarf.Platform;
using Dwarf.ObjectModel;


namespace Azbooka
{
	public partial class Languages : EntityCollection<Language>
	{
		public const string tagUnknown = "--";
		public const string nameUnknown = "??";

		public Languages() { }

		public Languages(IEnumerable<Language> items, bool deepCopy) :
			base(items)
		{}

		public bool HasLanguage(string tag)
		{
			return GetLanguage(tag) != null;
		}

		public Language GetLanguage(string tag)
		{
			foreach (var lang in this) {
				if (lang.Tag == tag)
					return lang;
			}
			return null;
		}

		//public Language Add(string tag)
		//{
		//	var language = GetLanguage(tag);
		//	if (language != null)
		//		return language;

		//	language = GetKnown(tag);
		//	if (language == null) {
		//		language = new Language(tag);
		//		language.CopyFrom(Unknown);
		//	}
		//	Add(language);
		//	return language;
		//}

		private static Languages AllKnown => LazyInitializer.EnsureInitialized(ref allKnown, InitAllKnown);
		static Languages allKnown = null;

		public static Language Unknown = LazyInitializer.EnsureInitialized(ref unknown, InitUnknown);
		static Language unknown = null;

		public static IEnumerable<Language> Known => AllKnown;
		public static bool IsKnown(string tag) => AllKnown.HasLanguage(tag);
		public static Language GetKnown(string tag) => AllKnown.GetLanguage(tag);
		public static void AddToKnown(Language language) => AllKnown.Add(language);

		public static Language GetOrAdd(string tag)
		{
			if (String.IsNullOrEmpty(tag))
				return null;

			var language = GetKnown(tag);
			if (language == null) {
				language = new Language(tag, Unknown);
				AddToKnown(language);
			}
			return language;
		}

	}
}
