﻿using System;
using System.Data;

namespace Dwarf.Data
{
	public static class Extensions
	{
		public static void SetCommandText(this IDbCommand command, string format, params object[] args)
		{
			command.CommandText = String.Format(format, args);
		}
	}
}
