﻿using System;
using Dwarf.Config;
using Dwarf.Assets;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing.Gold
{
	class GrammarAssetNotFound : DwarfException
	{
		public GrammarAssetNotFound(string assetName) :
			base(UnitGold._, null, true, Messages.GrammarAssetNotFound, assetName)
		{ }
	}

	class GrammarTableException : DwarfException
	{
		public GrammarTableException(string message, bool useAssets = true, Exception innerExc = null) :
			base(UnitGold._, message, useAssets, innerExc)
		{ }

		public GrammarTableException(Exception innerExc = null) :
			base(UnitGold._, Messages.GrammarTableException, true, innerExc)
		{ }
	}

	class NotValidGrammarTable : GrammarTableException
	{
		public NotValidGrammarTable(string message, bool useAssets = true, Exception innerExc = null) :
			base(message, useAssets, innerExc)
		{ }

		public NotValidGrammarTable(Exception innerExc = null) :
			base(Messages.NotValidGrammarTable, true, innerExc)
		{ }
	}

	class GroupError : UnnexpectedEOF
	{
		public GroupError() :
			base(UnitGold._, Messages.UnclosedGroup, true)
		{ }
	}

	public static class Messages
	{
		public static readonly string GrammarAssetNotFound = nameof(GrammarAssetNotFound);
		public static readonly string GrammarTableException	= nameof(GrammarTableException);
		public static readonly string NotValidGrammarTable	= nameof(NotValidGrammarTable);
		public static readonly string InvalidTableRecord	= nameof(InvalidTableRecord);
		public static readonly string UnknownTableRecord	= nameof(UnknownTableRecord);
		public static readonly string InvalidTableEntry		= nameof(InvalidTableEntry);
		public static readonly string InvalidSymbolInGroup	= nameof(InvalidSymbolInGroup);
		public static readonly string TableCountsMissing	= nameof(TableCountsMissing);
		public static readonly string TableIndexOutOfRange	= nameof(TableIndexOutOfRange);
		public static readonly string DuplicateTableIndex	= nameof(DuplicateTableIndex);
		public static readonly string UnclosedGroup			= nameof(UnclosedGroup);
	}

	#region UnitGold
	public sealed class UnitGold : NamespaceUnit
	{
		private UnitGold() : base("Gold", UnitParsing._)
		{
#if INIT_DEFAULT_MESSAGES
			AssetMgr.SetDefaultStrings(
				Messages.GrammarAssetNotFound, "Error while reading grammar table.",
				Messages.GrammarTableException, "Error while reading grammar table.",
				Messages.NotValidGrammarTable, "File is not valid grammar table.",
				Messages.InvalidTableRecord, "Invalid record in grammar table.",
				Messages.UnknownTableRecord, "Unknown record in grammar table.",
				Messages.InvalidTableEntry, "Invalid entry in grammar table.",
				Messages.InvalidSymbolInGroup, "Invalid symbol index in group.",
				Messages.TableCountsMissing, "Missing table counts record in grammar table.",
				Messages.TableIndexOutOfRange, "Index in grammar table is out of range.",
				Messages.DuplicateTableIndex, "Duplicate index in grammar table.",
				Messages.UnclosedGroup, "Unclosed group."
			);
#endif
		}
		public static readonly UnitGold _ = new UnitGold();
		public static UnitGold Instance => _;
	}
	#endregion
}
