﻿using System;
using System.Collections;
using System.Collections.Generic;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Collections
{
	/// <summary>
	/// Utility class Extensions
	/// </summary>
	public static class Extensions
	{
		public static int GetCount(this IEnumerable enumarable)
		{
			//var array = enumerable as Array;
			//if (array != null) {
			//	return array.Length;
			//}

			var collection = enumarable as ICollection;
			if (collection != null) {
				return collection.Count;
			}

			int count = 0;
			foreach (object obj in enumarable) {
				count++;
			}
			return count;
		}

		public static void AddAt<T>(this IList<T> list, int index, T element)
		{
			if (index < 0) {
				throw new System.IndexOutOfRangeException();
			}
			AddAt(list, (uint)index, element);
		}

		public static void AddAt<T>(this IList<T> list, uint index, T element)
		{
			if (index < list.Count) {
				list[(int)index] = element;
			} else {
				while (index > list.Count) {
					list.Add(default(T));
				}
				list.Add(element);
			}
		}

	}

	#region Unit
	public sealed class UnitCollections : NamespaceUnit
	{
		private UnitCollections() : base("Collections", UnitDwarf._) { }
		public static readonly UnitCollections _ = new UnitCollections();
		public static UnitCollections Instance => _;
	}
	#endregion

	#region UnitExtensions
	public class UnitExtensions : UtilityUnit
	{
		UnitExtensions() : base(typeof(Extensions), UnitCollections._) { }
		public static readonly UnitExtensions _ = new UnitExtensions();
		public static UnitExtensions Instance => _;
	}
	#endregion
}
