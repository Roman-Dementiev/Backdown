﻿using System;
using System.Collections;
using System.Collections.Generic;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Collections
{
	/// <summary>
	/// Generic class LinkedCollection
	/// </summary>
	public abstract class LinkedCollection<TLinked> : ICollection<TLinked>, IReleasable
		where TLinked : class, ILinked<TLinked>
	{
		#region Fields
		protected TLinked head;
		protected int count = 0;
		#endregion


		#region Properties
		public bool IsEmpty => head == null;
		public int Count => count >= 0 ? count : Linked<TLinked>.GetCount(head);
		public bool IsReadOnly => false;
		#endregion

		#region Constructors
		public LinkedCollection(TLinked head)
		{
			Debug.Assert(head == null || head.Link == null);
			this.head = head;
		}

		#endregion

		#region Methods
		public virtual void Clear() {
			head = null;
		}

		public virtual void ReleaseContent(bool dispose)
		{
			Linked<TLinked>.ForEach(head, linked => linked.Release(dispose));
			head = null;
		}

		public bool Contains(TLinked node)
			=> Linked<TLinked>.Contains(head, node);

		public virtual void Add(TLinked node)
		{
			if (node == null) {
				throw new ArgumentNullException(nameof(node));
			}
			Linked<TLinked>.LinkIn(ref head, node, null);
		}

		public virtual bool Remove(TLinked node)
		{
			if (node == null) {
				throw new ArgumentNullException(nameof(node));
			}
			return Linked<TLinked>.Unlink(ref head, node);
		}

		public IEnumerator<TLinked> GetEnumerator()
			=> new Enumerator(head);

		IEnumerator IEnumerable.GetEnumerator()
			=> new Enumerator(head);

		public TLinked FindFirst(Func<TLinked, bool> func)
			=> Linked<TLinked>.FindFirst(head, func);

		public TLinked FindLast(Func<TLinked, bool> func)
			=> Linked<TLinked>.FindLast(head, func);

		public List<TLinked> FindAll(Func<TLinked, bool> func)
			=> Linked<TLinked>.FindAll(head, func);

		public TResult GetFirst<TResult>( Func<TLinked, TResult> func) where TResult : class
			=> Linked<TLinked>.GetFirst(head, func);

		public TResult GetLast<TResult>(Func<TLinked, TResult> func) where TResult : class
			=> Linked<TLinked>.GetLast(head, func);

		public List<TResult> GetAll<TResult>(Func<TLinked, TResult> func) where TResult : class
			=> Linked<TLinked>.GetAll(head, func);

		public void ForEach(Action<TLinked> action)
			=> Linked<TLinked>.ForEach(head, action);

		void ICollection<TLinked>.CopyTo(TLinked[] array, int arrayIndex)
		{
			TLinked node = head;
			for (int i = arrayIndex; node != null && i < array.Length; i++, node = node.Link) {
				array[i] = node;
			}
		}
		#endregion

		class Enumerator : IEnumerator<TLinked>
		{
			bool started = false;
			private TLinked head;
			private TLinked current = null;
			public TLinked Current => current;
			object IEnumerator.Current => current;

			public Enumerator(TLinked head) {
				this.head = head;
			}
			public bool MoveNext() {
				current = started ? current?.Link : head;
				started = true;
				return current != null;
			}
			public void Reset() {
				started = false;
			}
			public void Dispose() { }
		}
	}

	#region UnitLinkedCollection
	public sealed class UnitLinkedCollection : ClassUnit
	{
		private UnitLinkedCollection() : base(typeof(LinkedCollection<>), UnitCollections._) { }
		public static readonly UnitLinkedCollection _ = new UnitLinkedCollection();
		public static UnitLinkedCollection Instance => _;
	}
	#endregion
}
