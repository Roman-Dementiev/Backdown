﻿using System;
using System.Reflection;
using Dwarf.Config;
using Dwarf.Assets;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf
{
	/// <summary>
	/// Utility class Reflection
	/// </summary>
	public static class Reflection
	{
		static readonly Type[] cNoParams = new Type[0];
		static readonly string cInstance = "Instance";

		public class Method
		{
			protected object target;
			protected MethodInfo method;

			public Method(object target, MethodInfo method)
			{
				if (target == null) {
					throw new ArgumentNullException(nameof(target));
				}
				if (method == null) {
					throw new ArgumentNullException(nameof(method));
				}

				this.target = target;
				this.method = method;
			}

			public void Invoke(params object[] args)
			{
				method.Invoke(target, args);
			}
		}

		public class GMethod<TReturType> : Method
		{
			public GMethod(object target, MethodInfo method) :
				base(target, method)
			{}

			public new TReturType Invoke(params object[] args)
			{
				return (TReturType)method.Invoke(target, args);
			}
		}

		#region Methods
		public static bool HasMethod(object target, string methodName, Type[] argTypes, Type returnType=null) =>
			GetMethod(target, methodName, argTypes, returnType, false) != null;

		public static bool HasMethod(object target, string methodName, Type returnType = null, params Type[] argTypes) =>
			GetMethod(target, methodName, argTypes ?? cNoParams, returnType, false) != null;
	

		public static MethodInfo GetMethod(object target, string methodName, Type[] argTypes, Type returnType = null, bool required = false)
		{
			if (target == null) {
				throw new ArgumentNullException(nameof(target));
			}
			if (methodName == null) {
				throw new ArgumentNullException(nameof(methodName));
			}

			Type type = target as Type;
			if (type == null) {
				type = target.GetType();
			}

			MethodInfo methodInfo;
			if (argTypes == null) {
				try {
					methodInfo = type.GetMethod(methodName);
				} catch (AmbiguousMatchException) {
					methodInfo = type.GetMethod(methodName, cNoParams);
				}
			} else {
				methodInfo = type.GetMethod(methodName, argTypes);
			}

			if (methodInfo == null) {
				if (required) {
					new MethodNotFound(methodName).Throw();
				}
				return null;
			}

			if (returnType != null && methodInfo.ReturnType != returnType) {
				new MethodReturnTypeMissmatch(methodName, returnType).Throw();
			}

			return methodInfo;
		}

		public static MethodInfo GetMethod(object target, string methodName, Type returnType = null, params Type[] argTypes) =>
			GetMethod(target, methodName, argTypes ?? cNoParams, returnType, false);

		public static MethodInfo GetNoParamsMethod(object target, string methodName, Type returnType, bool required) =>
			GetMethod(target, methodName, cNoParams, returnType, required);


		public static object InvokeMethod(object target, string methodName, Type[] argTypes, object[] args, bool required = false)
		{
			MethodInfo methodInfo = GetMethod(target, methodName, argTypes, null, required);
			return methodInfo?.Invoke(target, args);
		}

		public static TReturn InvokeMethod<TReturn>(object target, string methodName, Type[] argTypes, object[] args, bool required = false)
		{
			MethodInfo methodInfo = GetMethod(target, methodName, argTypes, typeof(TReturn), required);
			if (methodInfo != null) {
				return (TReturn)methodInfo.Invoke(target, args);
			} else {
				return default(TReturn);
			}
		}

		public static object InvokeMethod(object target, string methodName, bool required = true)
		{
			MethodInfo methodInfo = GetMethod(target, methodName, cNoParams, null, required);
			return methodInfo?.Invoke(target, null);
		}

		public static PropertyInfo GetProperty(object target, string propertyName, bool required = false)
		{
			Type type = target as Type;
			if (type == null) {
				type = target.GetType();
			}

			PropertyInfo propertyInfo = type.GetProperty(propertyName);
			if (required && propertyInfo == null) {
				new PropertyNotFound(propertyName).Throw();
			}
			return propertyInfo;
		}

		public static object GetPropertyValue(object target, string propertyName, Type type = null)
		{
			PropertyInfo propertyInfo = GetProperty(target, propertyName, true);
			return GetPropertyValue(target, propertyInfo, type);
		}

		public static void SetPropertyValue(object target, object value, string propertyName, Type type = null)
		{
			PropertyInfo propertyInfo = GetProperty(target, propertyName, true);
			SetPropertyValue(target, value, propertyInfo, type);
		}

		public static object GetPropertyValue(object target, PropertyInfo propertyInfo, Type type=null)
		{
			if (target == null) {
				throw new ArgumentNullException(nameof(target));
			}
			if (propertyInfo == null) {
				throw new ArgumentNullException(nameof(propertyInfo));
			}
			if (type != null && propertyInfo.PropertyType != type) {
				new PropertyTypeMissmatch(propertyInfo.Name, type.FullName).Throw();
			}
			if (propertyInfo.GetMethod == null) {
				new PropertyIsNotReadable(propertyInfo.Name).Throw();
			}

			return propertyInfo.GetMethod.Invoke(target, null);
		}

		public static void SetPropertyValue(object target, object value, PropertyInfo propertyInfo, Type type = null)
		{
			if (target == null) {
				throw new ArgumentNullException(nameof(target));
			}
			if (propertyInfo == null) {
				throw new ArgumentNullException(nameof(propertyInfo));
			}
			if (type != null && propertyInfo.PropertyType != type) {
				new PropertyTypeMissmatch(propertyInfo.Name, type.FullName).Throw();
			}
			if (propertyInfo.SetMethod == null) {
				new PropertyIsNotWritable(propertyInfo.Name).Throw();
			}

			propertyInfo.SetMethod.Invoke(target, new object[] { value });
		}

		public static TValue GetPropertyValue<TValue>(object target, string propertyName)
		{
			return (TValue)GetPropertyValue(target, propertyName, typeof(TValue));
		}

		public static void SetPropertyValue<TValue>(object target, TValue value, string propertyName)
		{
			SetPropertyValue(target, value, propertyName, typeof(TValue));
		}

		public static TValue GetPropertyValue<TValue>(object target, PropertyInfo propertyInfo)
		{
			return (TValue)GetPropertyValue(target, propertyInfo, typeof(TValue));
		}

		public static void SetPropertyValue<TValue>(object target, TValue value, PropertyInfo propertyInfo)
		{
			SetPropertyValue(target, value, propertyInfo, typeof(TValue));
		}


		public static object CreateGenericInstance(Type genericType, Type paramType, object[] args)
		{
			Type type = genericType.MakeGenericType(paramType);
			return Activator.CreateInstance(type, args);
		}

		public static object CreateGenericInstance<TGeneric, TParam>(object[] args)
		{
			return CreateGenericInstance(typeof(TGeneric), typeof(TParam), args);
		}

		public static object CreateGeneric(Type genericType, Type paramType, params object[] args)
		{
			return CreateGenericInstance(genericType, paramType, args);
		}

		public static object CreateGeneric<TGeneric, TParam>(params object[] args)
		{
			return CreateGenericInstance(typeof(TGeneric), typeof(TParam), args);
		}

		public static TSingletton GetSingletonInstance<TSingletton>() where TSingletton : class
		{
			return GetSingletonInstance(typeof(TSingletton)) as TSingletton;
		}

		public static object GetSingletonInstance(Type type)
		{
			PropertyInfo properyInfo = type.GetProperty(cInstance);
			if (properyInfo == null) {
				throw new PropertyNotFound(cInstance);
			}

			return GetPropertyValue(type, properyInfo);
		}

		public static void InitSingletons(Assembly assembly, Type baseType = null, bool subclassesOnly=false, params Type[] interfaces)
		{
			if (baseType == null) {
				baseType = typeof(object);
				subclassesOnly = false;
			}

			foreach (Type type in assembly.GetTypes())
			{
				if (type == baseType) {
					if (subclassesOnly)
						continue;
				} else {
					if (!type.IsSubclassOf(baseType))
						continue;
				}

				if (interfaces != null && !type.HasInterfaces(interfaces))
					continue;

				PropertyInfo propertyInfo = GetProperty(type, cInstance);
				if (propertyInfo != null) {
					object instance = GetPropertyValue(type, propertyInfo);
					if (instance == null) {
						new CantInitSingleton(type).Throw();
					}
				}
			}
		}

		public static bool HasInterface(this Type type, Type interfaceType)
		{
			Type[] typeInterfaces = type.GetInterfaces();
			return Array.IndexOf(typeInterfaces, interfaceType) >= 0;
		}

		public static bool HasInterfaces(this Type type, params Type[] interfaces)
		{
			Type[] typeInterfaces = type.GetInterfaces();
			foreach (Type interfaceType in interfaces) {
				if (Array.IndexOf(typeInterfaces, interfaceType) < 0) {
					return false;
				}
			}
			return true;
		}
		#endregion

		#region Exceptions
		public class MethodNotFound : DwarfException
		{
			public MethodNotFound(string method, Exception innerExc = null) :
				base(UnitReflection._, innerExc, true, Messages.MethodNotFound, method)
			{ }
		}

		public class MethodReturnTypeMissmatch : DwarfException
		{
			public MethodReturnTypeMissmatch(string method, Type expectedType) :
				base(UnitReflection._, null, true, Messages.MethodTypeMissmatch, method, expectedType.Name)
			{ }
		}

		public class PropertyNotFound : DwarfException
		{
			public PropertyNotFound(string property, Exception innerExc = null) :
				base(UnitReflection._, innerExc, true, Messages.PropertyNotFound, property)
			{ }
		}

		public class PropertyIsNotReadable : DwarfException
		{
			public PropertyIsNotReadable(string property, Exception innerExc = null) :
				base(UnitReflection._, innerExc, true, Messages.PropertyIsNotReadable, property)
			{ }
		}

		public class PropertyIsNotWritable : DwarfException
		{
			public PropertyIsNotWritable(string property, Exception innerExc = null) :
				base(UnitReflection._, innerExc, true, Messages.PropertyIsNotWritable, property)
			{ }
		}

		public class PropertyTypeMissmatch : DwarfException
		{
			public PropertyTypeMissmatch(string property, string expectedType, Exception innerExc = null) :
				base(UnitReflection._, innerExc, true, Messages.PropertyTypeMissmatch, property, expectedType)
			{ }
		}

		public class CantInitSingleton : DwarfException
		{
			public CantInitSingleton(Type type, Exception innerExc = null) :
				base(UnitReflection._, innerExc, true, Messages.CantInitSingleton, type.FullName)
			{ }
		}
		#endregion

		public static class Messages
		{
			public const string MethodNotFound			= nameof(MethodNotFound);
			public const string MethodTypeMissmatch		= nameof(MethodTypeMissmatch);
			public const string PropertyNotFound		= nameof(PropertyNotFound);
			public const string PropertyIsNotReadable	= nameof(PropertyIsNotReadable);
			public const string PropertyIsNotWritable	= nameof(PropertyIsNotWritable);
			public const string PropertyTypeMissmatch	= nameof(PropertyTypeMissmatch);
			public const string CantInitSingleton		= nameof(CantInitSingleton);
		}
	}

	#region UnitReflection	
	public sealed class UnitReflection : ClassUnit
	{
		private UnitReflection() : base(typeof(Reflection), UnitDwarf._)
		{
#if INIT_DEFAULT_MESSAGES
			AssetMgr.SetDefaultStrings(
				Reflection.Messages.MethodNotFound,        "Unknown method {0}.",                        // method name
				Reflection.Messages.MethodTypeMissmatch,   "Wrong type for method {0}; expected {1}.",   // method name, expected types
				Reflection.Messages.PropertyNotFound,      "Unknown property {0}.",                      // property name
				Reflection.Messages.PropertyIsNotReadable, "Property {0} is not readable.",              // property name
				Reflection.Messages.PropertyIsNotWritable, "Property {0} is not writable.",              // property name
				Reflection.Messages.PropertyTypeMissmatch, "Wrong type for property {0}; expected {1}.", // property name, expected type
				Reflection.Messages.CantInitSingleton,     "Can not create instance of {0}."             // type
			);
#endif
		}
		public static readonly UnitReflection _ = new UnitReflection();
		public static UnitReflection Instance => _;
	}
#endregion
}
