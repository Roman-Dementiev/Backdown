﻿using System;
using System.Data;


namespace Dwarf.Data
{
	public interface IDb
	{
		IDbConnection Connection { get; }
		bool IsOpen { get; }
		void Open(string initCmd = null);
		void Close();

		IDbCommand Command(string commandText=null);
		Query ExecuteQuery(string commandText=null);
	}
}
