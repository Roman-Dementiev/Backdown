﻿using System;
using Microsoft.Data.Sqlite;


namespace Dwarf.Data.Sqlite
{
	public class SqliteDb : Db<SqliteConnection, SqliteCommand, SqliteQuery>
	{
		public SqliteDb(string filename, bool open = false) :
			base(String.Format("Data Source={0}", filename), filename, open)
		{ }

		public SqliteDb(string connectionString, string filename, bool open = false) :
			base(connectionString, filename, open)
		{ }

		public override bool IdentitySpupported(IdentityType type) => (type == IdentityType.Global);

		public override object GetIdentity(IdentityType type = IdentityType.Global, string table = null)
		{
			if (type != IdentityType.Global)
				return null;

			using (var command = new SqliteCommand(SELECT_last_insert_rowid, Connection))
			{
				return command.ExecuteScalar();
			}
		}

		public long LastInsertedRowId => GetLastInsertedRowId(Connection);

		public static long GetLastInsertedRowId(SqliteConnection connection)
		{
			using (var command = new SqliteCommand(SELECT_last_insert_rowid, connection))
			{
				object rowid = command.ExecuteScalar();
				return (rowid != null) ? (long)rowid : -1;
			}
		}

		const string SELECT_last_insert_rowid = "SELECT last_insert_rowid()";
	}
}
