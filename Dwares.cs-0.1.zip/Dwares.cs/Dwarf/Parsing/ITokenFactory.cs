﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing
{
	/// <summary>
	/// Interface ITokenFactory
	/// </summary>
	public interface ITokenFactory
	{
		#region Methods
		object CreateTerminal(int sym, char[] buffer, int start, int length);
		object CreateNonterminal(uint rule, Token[] tokens, int start, int length);
		#endregion
	}

	#region UnitITokenFactory
	public sealed class UnitITokenFactory : InterfaceUnit
	{
		private UnitITokenFactory() : base(typeof(ITokenFactory), UnitParsing._) { }
		public static readonly UnitITokenFactory _ = new UnitITokenFactory();
		public static UnitITokenFactory Instance => _;
	}
	#endregion
}
