/// <reference path="Sandbox.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var BarkLevel;
    (function (BarkLevel) {
        BarkLevel[BarkLevel["Silent"] = 0] = "Silent";
        BarkLevel[BarkLevel["Fatal"] = 1] = "Fatal";
        BarkLevel[BarkLevel["Error"] = 2] = "Error";
        BarkLevel[BarkLevel["Warning"] = 3] = "Warning";
        BarkLevel[BarkLevel["Message"] = 4] = "Message";
        BarkLevel[BarkLevel["Verbose"] = 5] = "Verbose";
        BarkLevel[BarkLevel["Debug"] = 6] = "Debug";
        BarkLevel[BarkLevel["Trace"] = 7] = "Trace";
        BarkLevel[BarkLevel["Noise"] = 8] = "Noise";
    })(BarkLevel = exports.BarkLevel || (exports.BarkLevel = {}));
    ;
    exports.defaultBarkFormatOptions = {
        level: false,
        timestamp: true,
        source: true
    };
    function defaultBarkFormat(bark, options) {
        var opt = options ? options : exports.defaultBarkFormatOptions;
        var s = "";
        if (bark.level && opt.level) {
            var levelStr = BarkLevel[bark.level];
            s += "[" + levelStr + "]";
        }
        if (bark.timestamp && opt.timestamp) {
            var timeStr = bark.timestamp.toLocaleString();
            s += "[" + timeStr + "]";
        }
        if (bark.message) {
            if (s.length > 0)
                s += ": ";
            s += bark.message;
        }
        if (bark.source && opt.source) {
            s += " (";
            if (typeof bark.source === "string") {
                s += this.source;
            }
            else {
                s += "file: " + bark.source.file + ", line: " + bark.source.line;
            }
            s += ")";
        }
        return s;
    }
    exports.defaultBarkFormat = defaultBarkFormat;
    var Bark = (function () {
        function Bark(level, message, source, timestamp) {
            if (source === void 0) { source = null; }
            if (timestamp === void 0) { timestamp = new Date(); }
            this.level = level;
            this.message = message;
            this.source = source;
            this.timestamp = timestamp;
        }
        Bark.prototype.toString = function () {
            return defaultBarkFormat(this);
        };
        return Bark;
    }());
    exports.Bark = Bark;
    var Silent = (function () {
        function Silent() {
        }
        Object.defineProperty(Silent.prototype, "tail", {
            get: function () { return null; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Silent.prototype, "level", {
            get: function () { return BarkLevel.Silent; },
            set: function (that) { },
            enumerable: true,
            configurable: true
        });
        Silent.prototype.setLevel = function (that, forAll) {
            if (forAll === void 0) { forAll = true; }
        };
        Silent.prototype.woof = function (param, leading) { };
        Silent.prototype.bark = function (bark, level, source) { };
        Silent.prototype.fatal = function () { };
        Silent.prototype.error = function () { };
        Silent.prototype.warning = function () { };
        Silent.prototype.message = function () { };
        Silent.prototype.verbose = function () { };
        Silent.prototype.debug = function () { };
        Silent.prototype.trace = function () { };
        Silent.prototype.group = function () { };
        Silent.prototype.groupEnd = function () { };
        return Silent;
    }());
    Silent.instance = new Silent();
    exports.Silent = Silent;
    var ADwog = (function () {
        function ADwog(tail) {
            this.tail = tail;
        }
        Object.defineProperty(ADwog.prototype, "format", {
            get: function () {
                return this.ownFormat ? this.ownFormat : ADwog.commonFormat ? ADwog.commonFormat : defaultBarkFormat;
            },
            set: function (that) {
                this.ownFormat = that;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ADwog.prototype, "level", {
            get: function () {
                return this.ownLevel ? this.ownLevel : ADwog.commonLevel ? ADwog.commonLevel : BarkLevel.Noise;
            },
            set: function (value) {
                this.ownLevel = value;
            },
            enumerable: true,
            configurable: true
        });
        ADwog.prototype.bark = function (bark, level, source) {
            if (!level || level <= this.level) {
                if (typeof bark === 'string') {
                    this.doBark(new Bark(level, bark, source));
                }
                else {
                    this.doBark(bark);
                }
            }
            if (this.tail) {
                this.tail.bark(bark, level, source);
            }
        };
        ADwog.prototype.doBark = function (bark) {
            this.woof(this.format(bark));
        };
        ADwog.prototype.fatal = function (message, source) {
            this.bark(message, BarkLevel.Fatal, source);
        };
        ADwog.prototype.error = function (message, source) {
            this.bark(message, BarkLevel.Error, source);
        };
        ADwog.prototype.warning = function (message, source) {
            this.bark(message, BarkLevel.Warning, source);
        };
        ADwog.prototype.message = function (message, source) {
            this.bark(message, BarkLevel.Message, source);
        };
        ADwog.prototype.verbose = function (message, source) {
            this.bark(message, BarkLevel.Verbose, source);
        };
        ADwog.prototype.debug = function (message, source) {
            this.bark(message, BarkLevel.Debug, source);
        };
        ADwog.prototype.trace = function (message, source) {
            this.bark(message, BarkLevel.Trace, source);
        };
        ADwog.prototype.noise = function (message, source) {
            this.bark(message, BarkLevel.Noise, source);
        };
        return ADwog;
    }());
    ADwog.commonLevel = BarkLevel.Message;
    exports.ADwog = ADwog;
    var Barks = (function (_super) {
        __extends(Barks, _super);
        function Barks(tail) {
            var _this = _super.call(this, tail) || this;
            _this.barks = [];
            return _this;
        }
        Barks.prototype.woof = function (param, leading) {
            var message = (param === undefined) ? "undefined" : (param === null) ? "null" : param.toString();
            if (leading && leading.length > 0) {
                message = leading + ": " + message;
            }
            var bark = new Bark(BarkLevel.Noise, message, null, null);
            bark.cookie = param;
            this.doBark(bark);
        };
        Barks.prototype.doBark = function (bark) {
            this.barks.push(bark);
        };
        Barks.prototype.clear = function () {
            this.barks = [];
        };
        Barks.prototype.takeBarks = function () {
            var ret = this.barks;
            this.clear();
            return ret;
        };
        Barks.prototype.toString = function () {
            return Sandbox.toText(this.barks, this.barks, { textBreaks: "\n" });
        };
        Barks.prototype.takeAsString = function () {
            var s = this.toString();
            this.clear();
            return s;
        };
        // TODO?
        Barks.prototype.group = function (header) { };
        Barks.prototype.groupEnd = function () { };
        return Barks;
    }(ADwog));
    exports.Barks = Barks;
    var Console = (function (_super) {
        __extends(Console, _super);
        function Console() {
            return _super.call(this) || this;
        }
        Object.defineProperty(Console, "instance", {
            get: function () {
                if (!Console._intstance) {
                    Console._intstance = new Console();
                }
                return Console._intstance;
            },
            enumerable: true,
            configurable: true
        });
        Console.prototype.woof = function (param, leading) {
            if (leading) {
                console.log(leading + ": %O", param);
            }
            else {
                console.log(param);
            }
        };
        Console.prototype.doBark = function (bark) {
            var msg = this.format(bark);
            switch (bark.level) {
                case BarkLevel.Fatal:
                case BarkLevel.Error:
                    console.error(msg);
                    break;
                case BarkLevel.Warning:
                    console.warn(msg);
                    break;
                case BarkLevel.Message:
                case BarkLevel.Verbose:
                    console.info(msg);
                    break;
                case BarkLevel.Debug:
                case BarkLevel.Trace:
                    console.trace(msg);
                    break;
                default:
                    console.log(msg);
            }
        };
        Console.prototype.group = function (header) {
            console.group(header);
        };
        Console.prototype.groupEnd = function () {
            console.groupEnd();
        };
        return Console;
    }(ADwog));
    exports.Console = Console;
    var _dwog = Silent.instance;
    function getDwog() {
        return _dwog;
    }
    exports.getDwog = getDwog;
    function setDwog(that) {
        var ret = _dwog;
        _dwog = that ? that : Silent.instance;
        return ret;
    }
    exports.setDwog = setDwog;
    function getLevel() {
        return ADwog.commonLevel;
    }
    exports.getLevel = getLevel;
    function setLevel(level) {
        var ret = ADwog.commonLevel;
        ADwog.commonLevel = level;
        return ret;
    }
    exports.setLevel = setLevel;
    function getFormat() {
        return ADwog.commonFormat;
    }
    exports.getFormat = getFormat;
    function setFormat(format) {
        var ret = ADwog.commonFormat;
        ADwog.commonFormat = format;
        return ret;
    }
    exports.setFormat = setFormat;
    function fatal(message) {
        _dwog.fatal(message);
    }
    exports.fatal = fatal;
    function error(message) {
        _dwog.error(message);
    }
    exports.error = error;
    function warning(message) {
        _dwog.warning(message);
    }
    exports.warning = warning;
    function message(message) {
        _dwog.message(message);
    }
    exports.message = message;
    function verbose(message) {
        _dwog.verbose(message);
    }
    exports.verbose = verbose;
    function debug(message) {
        _dwog.debug(message);
    }
    exports.debug = debug;
    function trace(message) {
        _dwog.trace(message);
    }
    exports.trace = trace;
    function noise(message) {
        _dwog.bark(message);
    }
    exports.noise = noise;
    function woof(param, leading) {
        _dwog.woof(param, leading);
    }
    exports.woof = woof;
    function group(header) {
        _dwog.group(header ? header : "");
    }
    exports.group = group;
    function groupEnd() {
        _dwog.groupEnd();
    }
    exports.groupEnd = groupEnd;
    function isBarkLevel(level) {
        return typeof level !== 'boolean';
    }
    exports.test = {
        header: function (grouping, leading, opt) {
            if (!opt)
                opt = exports.test.options;
            if (grouping) {
                group(leading ? leading : "");
            }
            else if (leading && opt.leading) {
                woof(leading);
            }
        },
        footer: function (grouping, opt) {
            if (!opt)
                opt = exports.test.options;
            if (grouping) {
                groupEnd();
            }
            else if (opt.footer) {
                woof(opt.footer);
            }
        },
        forSamples: function (forEach, grouping, leading, before, after, opt) {
            exports.test.header(grouping, leading, opt);
            if (before) {
                before(opt);
            }
            for (var sample in exports.test.samples) {
                if (exports.test.samples.hasOwnProperty(sample)) {
                    forEach(sample, exports.test.samples[sample]);
                }
            }
            if (after) {
                after(opt);
            }
            exports.test.footer(grouping, opt);
        },
        showSamples: function (grouping, leading, opt) {
            if (grouping) {
                woof(exports.test.samples, leading);
            }
            else {
                exports.test.header(grouping, leading, opt);
                woof(exports.test.samples);
                exports.test.footer(grouping, opt);
            }
        },
        samplesTypes: function (grouping, leading, before, after, opt) {
            exports.test.forSamples(function (sample, value) {
                woof("typeof test.samples." + sample + " = " + typeof value);
            }, grouping, leading, before, after, opt);
        },
        samplesAsStrings: function (grouping, leading, before, after, opt) {
            exports.test.forSamples(function (sample, value) {
                woof("test.samples." + sample + " = " + value);
            }, grouping, leading, before, after, opt);
        },
        samplesWoofs: function (grouping, leading, before, after, opt, withNames) {
            if (withNames === void 0) { withNames = true; }
            exports.test.forSamples(function (name, value) {
                if (withNames) {
                    woof(value, name);
                }
                else {
                    woof(value);
                }
            }, grouping, leading, before, after, opt);
        },
        levels: function (grouping, leading, opt) {
            if (!opt)
                opt = exports.test.options;
            if (typeof leading === 'undefined')
                leading = "Levels tests";
            exports.test.header(grouping, leading);
            fatal("Fatal");
            error("Error");
            warning("Warning");
            message("Message");
            verbose("Verbose");
            debug("Debug");
            trace("Trace");
            noise("Noise");
            exports.test.footer(grouping, null);
        },
        runLevels: function (opt) {
            if (!opt)
                opt = exports.test.options;
            var leading = "Levels test [" + getLevel() + "]']";
            exports.test.levels(opt.groupLevels, leading, opt);
        },
        forLevel: function (level, run, opt) {
            function callRun(level, opt) {
                opt.testLevel = level;
                setLevel(level);
                return run(opt);
            }
            if (!opt)
                opt = exports.test.options;
            var _optLevel = opt.testLevel;
            try {
                if (isBarkLevel(level)) {
                    return callRun(level, opt);
                }
                else if (level === true) {
                    return {
                        fatal: callRun(BarkLevel.Fatal, opt),
                        error: callRun(BarkLevel.Error, opt),
                        warning: callRun(BarkLevel.Warning, opt),
                        message: callRun(BarkLevel.Message, opt),
                        verbose: callRun(BarkLevel.Verbose, opt),
                        debug: callRun(BarkLevel.Debug, opt),
                        trace: callRun(BarkLevel.Trace, opt),
                        noise: callRun(BarkLevel.Noise, opt),
                    };
                }
                else {
                    return run(opt);
                }
            }
            finally {
                opt.testLevel = _optLevel;
            }
        },
        basics: function (grouping, leading, before, after, opt, groupSamples) {
            if (groupSamples === void 0) { groupSamples = false; }
            if (!opt)
                opt = exports.test.options;
            if (typeof leading === 'undefined')
                leading = "Basic tests";
            exports.test.header(grouping, leading);
            if (opt.showSamples) {
                exports.test.showSamples(groupSamples, "Test samples", opt);
            }
            if (opt.showTypes) {
                exports.test.samplesTypes(groupSamples, "Samples types", before, after, opt);
            }
            if (opt.showStrings) {
                exports.test.samplesAsStrings(groupSamples, "Samples as strings", before, after, opt);
            }
            if (opt.woofsWithNames) {
                exports.test.samplesWoofs(groupSamples, "Samples as woofs (named)", before, after, opt);
            }
            if (opt.woofsWithoutNames) {
                exports.test.samplesWoofs(groupSamples, "Samples as woofs (no names)", before, after, opt, false);
            }
            exports.test.footer(grouping, null);
        },
        groups: function (grouping, leading, opt) {
            if (!opt)
                opt = exports.test.options;
            if (typeof leading === 'undefined')
                leading = "Groups tests";
            exports.test.basics(grouping, leading, null, null, opt, true);
        },
        run: function (opt) {
            if (!opt)
                opt = exports.test.options;
            try {
                if (opt.groupAll) {
                    group("Dwog tests");
                }
                if (opt.showBasics) {
                    exports.test.basics(opt.groupBasics, "Basic tests (plain)");
                }
                if (opt.showGroups) {
                    exports.test.groups(opt.groupGroups, "Basic tests (grouped)");
                }
                if (opt.showLevels) {
                    exports.test.forLevel(false, exports.test.runLevels);
                }
                if (opt.groupAll) {
                    groupEnd();
                }
            }
            catch (exc) {
                console.error("Exception in Dwog.test.run(): %o", exc);
            }
        },
        runToDwog: function (dwog, opt, run) {
            if (!run)
                run = exports.test.run;
            var _dwog = getDwog();
            try {
                if (dwog) {
                    setDwog(dwog);
                }
                run(opt);
            }
            finally {
                setDwog(_dwog);
            }
        },
        runToConsole: function (opt, run) {
            exports.test.runToDwog(Console.instance, opt, run);
        },
        runToBarks: function (opt, run) {
            var barks = new Barks();
            exports.test.runToDwog(barks, opt, run);
            return barks.takeBarks();
        },
        runToString: function (opt, run) {
            var barks = new Barks();
            exports.test.runToDwog(barks, opt, run);
            return barks.takeAsString();
        },
        options: {
            leading: true,
            footer: '----',
            showSamples: true,
            showTypes: true,
            showStrings: true,
            woofsWithNames: true,
            woofsWithoutNames: false,
            showBasics: false,
            showGroups: true,
            showLevels: true,
            groupBasics: true,
            groupGroups: true,
            groupLevels: true,
            groupAll: true,
            testLevel: null
        },
        samples: {
            "undefined": undefined,
            "null": null,
            "true": true,
            "false": false,
            "Boolean": new Boolean(false),
            "number": 1,
            "Number": new Number(1),
            "string": "String literal",
            "String": new String("String object"),
            "object (empty)": {},
            "object (with properties) ": {
                field: true,
                method: function () { }
            },
            "Object": new Object(),
            "array": [1, 2, 3],
            "Array": new Array(1, 2, 3),
            "array (nested)": [[1, 2], [3, 4]],
            "Array (nested)": new Array(new Array(1, 2), new Array(3, 4)),
            "Date()": new Date(),
            "Date(0)": new Date(0)
        }
    };
});
//# sourceMappingURL=Dwog.js.map