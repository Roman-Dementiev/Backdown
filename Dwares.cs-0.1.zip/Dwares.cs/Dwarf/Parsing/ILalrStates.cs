﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing
{
	/// <summary>
	/// Interface ILALRStates
	/// </summary>
	public interface ILalrStates
	{
		#region Properties
		int StateCount { get; }
		uint ShiftAction { get; }
		uint ReduceAction { get; }
		uint GotoAction { get; }
		uint AcceptAction { get; }
		#endregion

		#region Methods
		int ActionCount(uint state);
		int ActionSymbol(uint state, uint action);
		uint ActionType(uint state, uint action);
		uint ActionTarget(uint state, uint action);
		#endregion
	}

	#region UnitILalrStates
	public sealed class UnitILalrStates : InterfaceUnit
	{
		private UnitILalrStates() : base(typeof(ILalrStates), UnitParsing._) { }
		public static readonly UnitILalrStates _ = new UnitILalrStates();
		public static UnitILalrStates Instance => _;
	}
	#endregion
}
