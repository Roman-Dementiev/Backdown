﻿using System;
using System.IO;
using System.Collections.Generic;
using Dwarf.Utility;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing.Gold
{
	/// <summary>
	/// Class GoldLexer
	/// </summary>
	public class GoldLexer : ILexer
	{
		#region Fields
		private DFA dfa;
		private GoldSymbols symbols;
		private Stack<Grammar.Group> groupStack;
		private DwarfException error;
		#endregion

		#region Properties
		public Symbols Symbols => symbols;
		public ICharSets CharSets => dfa.CharSets;
		public IDfaStates States => dfa.States;
		public Lookahead Lookahead => dfa.Lookahead;
		public TextPosition Position => dfa.Position;
		public char[] Buffer => dfa.Buffer;
		public DwarfException Error => error;
		#endregion

		#region Constructors
		public GoldLexer(Grammar grammar, GoldSymbols symbols)
		{
			Init(grammar, symbols, null);
		}

		public GoldLexer(GoldSymbols symbols, DFA dfa)
		{
			Init(null, symbols, dfa);
		}

		protected void Init(Grammar grammar, GoldSymbols symbols, DFA dfa)
		{
			if (dfa == null) {
				GoldCharSets charSets = new GoldCharSets(grammar);
				GoldDfaStates dfaStates = new GoldDfaStates(grammar);
				this.dfa = new DFA(charSets, dfaStates, grammar.InitialDfaState);
			} else {
				this.dfa = dfa;
			}
			this.symbols = symbols;

			groupStack = new Stack<Grammar.Group>();
		}
		#endregion

		#region Methods
		public void Prepare(TextReader source)
		{
			dfa.Prepare(source);
			groupStack.Clear();
			error = null;
		}

		public int LookaheadToken(out int start, out int length)
		{
			start = dfa.Lookahead.LookaheadLength;
			length = 0;
			int sym;
			for (;;)
			{
				int tokenStart, tokenLength;
				sym = dfa.LookaheadToken(out tokenStart, out tokenLength);
				if (sym == Symbols.cEOF) {
					if (groupStack.Count > 0) {
						groupStack.Clear();
						error = new GroupError();
						return Symbols.cError;
					}
					return Symbols.cEOF;
				}
				if (sym == Symbols.cError) {
					error = dfa.Error;
					return Symbols.cError;
				}

				bool nestGroup;
				Grammar.Symbol symbol = null;
				if (symbols.IsGroupStart(sym)) {
					symbol = symbols.GrammarSymbol(sym);
					if (groupStack.Count == 0) {
						nestGroup = true;
					} else {
						ushort[] nesting = groupStack.Peek().Nesting;
						int found = Array.IndexOf(nesting, symbol.Group.Index);
						nestGroup = found >= 0; 
					}
				} else {
					nestGroup = false;
				}

				if (nestGroup) {
					groupStack.Push(symbol.Group);
				}
				else if (groupStack.Count == 0) {
					break;
				}
				else if (groupStack.Peek().End.Index == sym)
				 {
					Grammar.Group group = groupStack.Pop();
					if (group.EndingMode == Grammar.Group.cEndingOpen) {
						dfa.Lookahead.LookaheadLength = tokenStart;
					}

					if (groupStack.Count == 0) {
						sym = group.Container.Index;
						break;
					}
				}
				else {
					if (groupStack.Peek().AdvanceMode == Grammar.Group.cAdvanceChar) {
						dfa.Lookahead.LookaheadLength = tokenStart + 1;
					}
				}
			}

			length = dfa.Lookahead.LookaheadLength - start;
			return sym;
		}
		#endregion

		public void ConsumeLookahead()
		{
			dfa.ConsumeLookahead();
		}
	}

	#region UnitGoldLexer
	public sealed class UnitGoldLexer : ClassUnit
	{
		private UnitGoldLexer() : base(typeof(GoldLexer), UnitGold._) { }
		public static readonly UnitGoldLexer _ = new UnitGoldLexer();
		public static UnitGoldLexer Instance => _;
	}
	#endregion
}
