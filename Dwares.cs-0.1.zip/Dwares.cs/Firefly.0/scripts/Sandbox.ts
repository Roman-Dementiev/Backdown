﻿namespace Sandbox
{
	type StringOrFunc = string | ((any) => string);

	interface ToTextArgs
	{
		textPrefix?: StringOrFunc;
		textSuffix?: StringOrFunc;
		textBreaks?: StringOrFunc;
		itemPrefix?: StringOrFunc;
		itemSuffix?: StringOrFunc;
		itemString?: StringOrFunc;
	};

	function stringOrFunc(source: any, sf: StringOrFunc, useToString?: boolean) : string
	{
		if (!sf) {
			return useToString ? source.toString() : "";
		}

		if (typeof sf === 'string') {
			return sf;
		} else {
			return sf(source);
		}
	}

	export function toText(source: any, items: any[], args?: ToTextArgs) : string
	{
		if (!args) args = {};

		let str = "";
		str += stringOrFunc(source, args.textPrefix);

		if (items) {
			for (let i = 0; i < items.length; i++)
			{
				str += stringOrFunc(source, args.textBreaks);

				let item = items[i];
				str += stringOrFunc(item, args.itemPrefix);
				str += stringOrFunc(item, args.itemString, true);
				str += stringOrFunc(item, args.itemSuffix);
			}
		}

		if (args.textSuffix) {
			str += stringOrFunc(source, args.textSuffix);
		}

		return str;
	}
};


