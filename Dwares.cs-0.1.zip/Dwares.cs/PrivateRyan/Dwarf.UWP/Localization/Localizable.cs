﻿using System;
using System.Collections.Generic;


namespace Dwarf.Localization
{
	public class Localizable : List<object>, ILocalizable
	{
		public virtual void Localize()
		{
			foreach (var obj in this) {
				Localizer.Localize(obj);
			}
		}
	}
}
