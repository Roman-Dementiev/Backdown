﻿using System;
using System.ComponentModel;
using Dwarf.Platform;


namespace Dwarf.ObjectModel
{
	public class Entity : Referenced, IEntity
	{
		protected Entity() { }

		public Entity(string uid)
		{
			this.uid = uid ?? throw new ArgumentNullException(uid);
		}

		public Entity(string uid, Entity entity) :
			this(uid)
		{
			CopyFrom(entity);
		}

		public override string ToString() => Name;

		public int Id {
			get => id;
			set => id = value;
		}
		protected int id = -1;

		public virtual bool IsUsed {
			get => RefCount > 0;
		}

		public string Uid {
			get => uid;
			protected set => uid = value;
		}
		protected string uid;

		public string Name {
			get => name;
			set => name.Set(value, () => NotifyPropertyChanged(nameof(Name)));
		}
		protected PropertyValue<string> name;

		public Bitmap Icon {
			get => icon;
			set => icon.Set(value, () => NotifyPropertyChanged(nameof(Icon)));
		}
		protected BitmapPropertyValue icon;


		public void CopyFrom(Entity entity)
		{
			if (uid == null) {
				uid = entity.uid;
			}
			name = entity.name;
			icon = entity.icon;
		}

		public virtual void NotifyPropertyChanged(string propertyName) { }
	}
}
