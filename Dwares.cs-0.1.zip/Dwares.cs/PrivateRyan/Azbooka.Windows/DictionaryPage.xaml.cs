﻿using System;
using System.Collections.Generic;
using System.Threading;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Dwarf.Platform;
using Dwarf.ObjectModel;
using Dwarf.UI;


namespace Azbooka
{
	/// <summary>
	/// An empty page that can be used on its own or navigated to within a Frame.
	/// </summary>
	public sealed partial class DictionaryPage : Page
	{
		EntityChoices<Language> languages;
		Language currentLanguage;
		SortedStringCollection words;
		EntityListViewHelper<Meaning> helper;
		Word selectedWord = null;
		Word originalWord = null;
		Word editingWord = null;


		public DictionaryPage()
		{
			this.InitializeComponent();

			helper = new EntityListViewHelper<Meaning>() { AdjustWidth  = -10 };
			helper.AttachTo(meaningList);

			languages = new EntityChoices<Language>(ViewModel.ActiveLanguages);
			languages.CurrentChoiceChanged += Languages_CurrentChoiceChanged;

			//currentLanguage = languages.SetCurrent(UILanguages.Current, true);
			languages.SetCurrent(UILanguages.Current, true);
			languageCombo.Choices = languages;
		}

		public Abc ViewModel => Abc.Instance;

		public string Title => Appx.GetString(_Title);
		const string _Title = "Dictionary";

		//public LocalizableUI LocalizableUI => LazyInitializer.EnsureInitialized(
		//	ref localizableUI, () => new LocalizableUI() {
		//	});
		//LocalizableUI localizableUI;

		RelayCommand NewWordCommand => RelayCommand.LazyInit(ref newWordCommand, NewWord, () => !IsEditing);
		RelayCommand newWordCommand = null;

		RelayCommand EditWordCommand => RelayCommand.LazyInit(ref editWordCommand, EditWord, () => !IsEditing && HasSelectedWord);
		RelayCommand editWordCommand = null;

		RelayCommand DeleteWordCommand => RelayCommand.LazyInit(ref deleteWordCommand, DeleteWord, () => !IsEditing && HasSelectedWord);
		RelayCommand deleteWordCommand = null;

		public RelayCommand SaveWordCommand => RelayCommand.LazyInit(ref saveCommand, () => EndEditing(true), EditingWordNotEmpty);
		RelayCommand saveCommand;

		public RelayCommand CancelWordCommand => RelayCommand.LazyInit(ref cancelCommand, () => EndEditing(false), () => IsEditing);
		RelayCommand cancelCommand;

		RelayCommand AddMeaningCommand => RelayCommand.LazyInit(ref addMeaningCommand, AddMeaning, EditingWordNotEmpty);
		RelayCommand addMeaningCommand;

		bool HasSelectedWord => selectedWord != null;
		bool IsEditing => editingWord != null;

		bool EditingWordNotEmpty()
		{
			if (IsEditing) {
				return wordField.Text.Length > 0;
			} else {
				return false;
			}
		}

		void NewWord()
		{
			StartEditing(null);
		}

		void EditWord()
		{
			if (selectedWord != null) {
				StartEditing(selectedWord);
			}
		}

		void DeleteWord()
		{

		}

		void AddMeaning()
		{
			if (editingWord == null)
				return;

			var newMeaning = new Meaning(editingWord) {
				IsEditable = true,
				PoS = PartsOfSpeech.GetPoS(editingWord.LanguageTag, "noun")
			};
			editingWord.Meanings.Insert(editingWord.Meanings.Count - 1, newMeaning);
		}


		void StartEditing(Word word)
		{
			if (IsEditing)
				return;

			if (word != null) {
				originalWord = word;
				editingWord = new Word(word, deepCopy:true, isEditable:true);
			} else {
				originalWord = null;
				editingWord = new Word(currentLanguage.Tag);
			}

			wordField.Text = editingWord.Text ?? String.Empty;
			wordField.IsEnabled = true;
			editPanel.Visibility = Visibility.Visible;

			editingWord.Meanings.Add(new AddMeaningPlaceHolder(editingWord, AddMeaningCommand));
			meaningList.ItemsSource = editingWord.Meanings;

			UpdateCommands();

			if (word == null) {
				wordField.Focus(FocusState.Programmatic);
			}
		}

		void EndEditing(bool save, Word navigateToWord = null) 
		{
			if (IsEditing)
			{
				var word = editingWord;
				editingWord = null; // avoid reentering

				if (save && !String.IsNullOrEmpty(word.Text))
				{
					word.Meanings.RemoveAt(word.Meanings.Count-1);
					word.IsEditable = false;

					if (navigateToWord == null) {
						navigateToWord = word;
					}

					if (originalWord != null) {
						ViewModel.UpdateWord(word, originalWord);
						if (word.Text != originalWord.Text) {
							words.Remove(originalWord.Text);
							words.Add(word.Text);
							selectedWord = word;
							wordList.SelectedItem = word.Text;
						}
					} else {
						ViewModel.AddWord(word);
						words.Add(word.Text);

						if (word.Text != wordList.SelectedItem as string) {
							wordList.SelectedItem = word.Text;
							if (wordList.SelectedItem != null) {
								navigateToWord = null;
							}
						}
					}
				}
				else {
					if (navigateToWord == null) {
						navigateToWord = originalWord ?? selectedWord;
					}
				}

				originalWord = null;
				wordField.IsEnabled = false;
				editPanel.Visibility = Visibility.Collapsed;

				UpdateCommands();
				NavigateToWord(navigateToWord);
			}
			else if (navigateToWord != null) {
				NavigateToWord(navigateToWord);
			}
		}

		void UpdateCommands()
		{
			NewWordCommand.RaiseCanExecuteChanged();
			EditWordCommand.RaiseCanExecuteChanged();
			DeleteWordCommand.RaiseCanExecuteChanged();
			SaveWordCommand.RaiseCanExecuteChanged();
			CancelWordCommand.RaiseCanExecuteChanged();
		}

		void NavigateToWord(Word word)
		{
			if (word == null) {
				wordField.Text = String.Empty;
				meaningList.ItemsSource = null;
			} else {
				wordField.Text = word.Text;
				meaningList.ItemsSource = word.Meanings;
			}
		}

		protected override void OnNavigatedFrom(NavigationEventArgs e)
		{
			EndEditing(false);
		}

		private void wordList_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			string text = wordList.SelectedItem as string;
			if (text != null) {
				if (selectedWord == null || selectedWord.Text != text) {
					selectedWord = ViewModel.GetWord(currentLanguage, text);
				}
			} else {
				selectedWord = null;
			}
			EndEditing(false, selectedWord);

			UpdateCommands();
		}

		private void Languages_CurrentChoiceChanged(IChoices sender)
		{
			EndEditing(false);

			currentLanguage = languages.Current;

			words = ViewModel.GetWords(currentLanguage);
			wordList.ItemsSource = words;

		}

		private void languageCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			//EndEditing(false);

			//currentLanguage = languages.Current;

			//words = ViewModel.GetWords(currentLanguage);
			//wordList.ItemsSource = words;
		}

		private void word_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (editingWord != null) {
				editingWord.Text = wordField.Text;
			}
			SaveWordCommand.RaiseCanExecuteChanged();
			AddMeaningCommand.RaiseCanExecuteChanged();
		}
	}

	internal class AddMeaningPlaceHolder : Meaning
	{
		public AddMeaningPlaceHolder(Word word, ICommand command) : base(word)
		{
			Command = command;
		}

		public ICommand Command { get; }
	}
}
