﻿using System;
using Dwarf.ObjectModel;


namespace Azbooka
{
	public class ShelfEntity : LocalizedEntity, ISelectable
	{
		public ShelfEntity(string uid) :  base(uid) { }

		public ShelfEntity(string uid, ShelfEntity entity) :
			base(uid)
		{
			CopyFrom(entity);
		}

		public bool IsSelected { get; set; }

		public override bool IsUsed => base.IsUsed || IsSelected;

		public void CopyFrom(ShelfEntity entity)
		{
			base.CopyFrom(entity);
			IsSelected = entity.IsSelected;
		}
	}
}
