﻿using System;
using System.Collections.Generic;

namespace Dwarf.Config
{
	/// <summary>
	/// Interface IConfig
	/// </summary>
	public interface IConfig
	{
		#region Properties
		/// <summary>
		/// Determines whether this instance is mutable.
		/// </summary>
		/// <returns><c>true</c> if this instance is mutable; otherwise, <c>false</c>.</returns>
		bool IsMutable { get; }

		/// <summary>
		/// Determines whether this instance is modified.
		/// </summary>
		/// <returns><c>true</c> if this instance is modified; otherwise, <c>false</c>.</returns>
		bool IsModified { get; }
		#endregion


		#region Methods
		/// <summary>
		/// Gets a collection containing the keys in this config.
		/// </summary>
		/// <returns>
		/// The keys.
		/// </value>
		IEnumerable<string> Keys();

		/// <summary>
		/// Gets a collection containing all key and values in this config.
		/// </summary>
		/// <returns></returns>
		IEnumerable<KeyValuePair<string, object>> All();

		/// <summary>
		/// Gets a collection containing key and values in the specified group.
		/// </summary>
		/// <param name="name">The name of the group.</param>
		/// <returns></returns>
		IEnumerable<KeyValuePair<string, object>> Group(string name);

		/// <summary>
		/// Sets the default value for specified key.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="value">The value.</param>
		void SetDefaultValue(string key, object value);

		/// <summary>
		/// Sets the value for specified key.
		/// </summary>
		/// <typeparam name="Type">Type of value</typeparam>
		/// <param name="key">The key.</param>
		/// <param name="value">The value.</param>
		void Set<Type>(string key, Type value);

		/// <summary>
		/// Gets the value for specified key.
		/// </summary>
		/// <typeparam name="Type">Type of value.</typeparam>
		/// <param name="key">The key.</param>
		/// <returns>The value.</returns>
		Type Get<Type>(string key);

		/// <summary>
		/// Gets the value for specified key.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="type">The type of value; <c>null</c> for any type.</param>
		/// <returns></returns>
		object Get(string key, Type type=null);

		/// <summary>
		/// Gets the enum value for specified key.
		/// </summary>
		/// <typeparam name="EnumType">The type of the enum.</typeparam>
		/// <param name="key">The key.</param>
		/// <param name="ignoreCase"><c>true</c> to ignore case; <c>false</c> otherwise.</param>
		/// <returns></returns>
		EnumType GetEnum<EnumType>(string key, bool ignoreCase = false) where EnumType : struct;

		/// <summary>
		/// Commits changes and sets <see cref="IsModified"/> to <c>false</c>.
		/// </summary>
		void Commit();
		#endregion
	}

	#region UnitIConfig
	#pragma warning disable RCS1060, RCS1023
	public sealed class UnitIConfig : InterfaceUnit
	{
		private UnitIConfig() : base(typeof(IConfig), UnitConfig._) { }
		public static readonly UnitIConfig _ = new UnitIConfig();
		public static UnitIConfig Instance => _;
	}
	#endregion
}
