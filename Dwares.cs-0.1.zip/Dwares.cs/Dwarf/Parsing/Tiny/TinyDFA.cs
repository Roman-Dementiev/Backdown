﻿using System;
using Dwarf.Utility;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing.Tiny
{
	/// <summary>
	/// Class DFA
	/// </summary>
	public class TinyDFA : DFA, ILexer, IDfaStates, ICharSets
	{
		public const ushort cSymNone = 0xffff;

		#region Fields
		protected char[][] charSetTable;
		protected ushort[][] stateTable;
		#endregion

		#region Properties
		public int CharSetCount => charSetTable.Length;
		public int StateCount => stateTable.Length;
		#endregion

		#region Constructors
		public TinyDFA(char[][] charSetTable, ushort[][] stateTable, uint initialState)
		{
			Init(charSetTable, stateTable, initialState);
		}

		protected TinyDFA() { }

		protected void Init(char[][] charSetTable, ushort[][] stateTable, uint initialState)
		{
			this.charSetTable = charSetTable;
			this.stateTable = stateTable;
			base.Init(this, this, initialState);
		}
		#endregion

		#region Methods
		public bool IsAcceptState(uint state)
		{
			Debug.Assert(state < stateTable.Length);
			return stateTable[state][0] != cSymNone;
		}

		public int AcceptSymbol(uint state)
		{
			Debug.Assert(state < stateTable.Length);
			return stateTable[state][0];
		}

		public uint EdgeCount(uint state)
		{
			Debug.Assert(state < stateTable.Length);
			return (uint)(stateTable[state].Length - 1) / 2;
		}

		public uint EdgeCharSet(uint state, uint edge)
		{
			Debug.Assert(state < stateTable.Length);
			ushort[] edges = stateTable[state];
			uint index = 2 * edge + 1;
			Debug.Assert(index < edges.Length);
			return edges[index];
		}

		public uint EdgeTargetState(uint state, uint edge)
		{
			Debug.Assert(state < stateTable.Length);
			ushort[] edges = stateTable[state];
			uint index = 2 * edge + 1;
			Debug.Assert(index < edges.Length);
			return edges[index];
		}

		public CharSet GetCharSet(uint charsetIndex)
		{
			int length = charSetTable[charsetIndex].Length;
			var ranges = new char[length];
			Array.Copy(charSetTable[charsetIndex], ranges, length);

			return new CharSet(ranges);
		}

		public bool CharInCharset(char ch, uint charsetIndex)
		{
			Debug.Assert(charsetIndex < charSetTable.Length);
			/*
			char[] cs = charSetTable[charset];
			int found = Array.BinarySearch(cs, ch);
			if (found < 0) {
				found = ~found;
				if (found == 0) {
					return false;
				}
				found--;
			}

			return (found & 1) == 0;
			*/

			return CharSet.Contains(charSetTable[charsetIndex], ch);
		}

		public new int LookaheadToken(out int start, out int length)
		{
			Debug.Assert(lookahead != null);
			start = lookahead.LookaheadLength;
			length = 0;
			char ch = lookahead.LookaheadChar();
			if (ch == TextSource.EOF) {
				return Symbols.cEOF;
			}

			currentState = initialState;
			int acceptedSym = -1;
			int acceptedLen = 0;
			for (;;)
			{
				int targetState = -1;
				ushort[] state = stateTable[currentState];
				for (int index = 1; index < state.Length; index += 2)
				{
					uint charset = state[index];
					if (CharInCharset(ch, charset)) {
						targetState = (int)state[index+1];
						break;
					}
				}

				if (targetState < 0) {
					lookahead.PushBack();
				}

				if (state[0] != cSymNone) {
					acceptedSym = (int)state[0];
					acceptedLen = lookahead.LookaheadLength;
				}

				if (targetState < 0)
					break;

				currentState = (uint)targetState;
				ch = lookahead.LookaheadChar();
				if (ch == Lookahead.EOF)
					break;
			}

			if (acceptedSym >= 0) {
				length = lookahead.LookaheadLength = acceptedLen;
				return acceptedSym;
			} else {
				SetError(start, ch);
				return Symbols.cError;
			}
		}

		#endregion
	}

	#region UnitTinyDFA
	public sealed class UnitTinyDFA : ClassUnit
	{
		private UnitTinyDFA() : base(typeof(TinyDFA), UnitTiny._) { }
		public static readonly UnitTinyDFA _ = new UnitTinyDFA();
		public static UnitTinyDFA Instance => _;
	}
	#endregion
}
