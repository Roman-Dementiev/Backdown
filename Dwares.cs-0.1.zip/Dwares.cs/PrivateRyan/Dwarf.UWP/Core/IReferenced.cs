﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dwarf
{
	public interface IReferenced
	{
		uint RefCount { get; }
		void AddRef(object @ref);
		void RemoveRef(object @ref);
	}
}
