﻿using System;
using Dwarf.Platform;


namespace Dwarf.ObjectModel
{
	public interface IEntity
	{
		bool IsUsed { get; }
		string Name { get; }
		Bitmap Icon { get; }
	}
}
