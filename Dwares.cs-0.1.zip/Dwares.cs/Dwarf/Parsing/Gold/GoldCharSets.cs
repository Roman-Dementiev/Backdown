﻿//#define USE_RANGE_COMPARER
using System;
using System.Collections.Generic;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing.Gold
{
	/// <summary>
	/// Class CharSet
	/// </summary>
	public class GoldCharSets : ICharSets
	{
		#region Fields
		private Grammar.CharSet[] charSets;
		#endregion

		#region Constructors
		public GoldCharSets(Grammar grammar)
		{
			charSets = grammar.CharSets;
		}
		#endregion

		#region Properties
		public Grammar.CharSet[] GrammarCharSets => charSets;
		public int CharSetCount => charSets.Length;
		#endregion

		#region Methods
		public CharSet GetCharSet(uint charsetIndex)
		{
			Debug.Assert(charsetIndex < charSets.Length);
			Grammar.CharSet.Range[] ranges = charSets[charsetIndex].Ranges;

			CharSet charSet = new CharSet();
			for (int i = 0; i < ranges.Length; i++) {
				charSet.AddRange((char)ranges[i].start, (char)ranges[i].end, true);
			}

			return charSet;
		}

		public bool CharInCharset(char ch, uint charsetIndex)
		{
			Debug.Assert(charsetIndex < charSets.Length);
			Grammar.CharSet cs = charSets[charsetIndex];
#if USE_RANGE_COMPARER
			Grammar.CharSet.Range range = new Grammar.CharSet.Range();
			range.start = range.end = ch;
			int found = Array.BinarySearch<Grammar.CharSet.Range>(cs.Ranges, range, rangeComparer);
			return found >= 0;
#else
			foreach (Grammar.CharSet.Range range in cs.Ranges) {
				if (ch >= range.start && ch <= range.end)
					return true;
			}
			return false;
#endif
		}
		#endregion

#if USE_RANGE_COMPARER
		class RangeComparer : IComparer<Grammar.CharSet.Range>
		{
			public int Compare(Grammar.CharSet.Range r1, Grammar.CharSet.Range r2)
			{
				if (r1.end < r2.start)
					return -1;
				if (r2.end < r1.start)
					return 1;
				return 0;
			}
		}
		private static readonly RangeComparer rangeComparer = new RangeComparer();
#endif
	}
	
	#region UnitGoldCharSet
	public sealed class UnitGoldCharSets : ClassUnit
	{
		private UnitGoldCharSets() : base(typeof(GoldCharSets), UnitGold._) { }
		public static readonly UnitGoldCharSets _ = new UnitGoldCharSets();
		public static UnitGoldCharSets Instance => _;
	}
	#endregion
}
