﻿using System;
using System.Threading;

	
namespace Azbooka
{
	public partial class UILanguages : Languages
	{
		public static UILanguages Instance => LazyInitializer.EnsureInitialized(ref instance);
		static UILanguages instance;

		public static Language Current => Instance.currentLanguage;
		Language currentLanguage;
	}
}
