﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dwarf.Extensions;

namespace Dwarf.Collections
{
	public class Vocabulary : Vocabulary<object>
	{
		public Vocabulary() { }
		public Vocabulary(IDictionary<string, object> source) : base(source) { }

		public TValue Get<TValue>(string key)
		{
			var value = this[key];
			return (value is TValue) ? (TValue)value : default(TValue);
		}

		//public void Put<TValue>(string key, TValue value)
		//{
		//	this[key] = value;
		//}
	}

	public class Vocabulary<TValue> : Dictionary<string, TValue>
	{
		public Vocabulary() { }
		public Vocabulary(IDictionary<string, TValue> source) : base(source) { }

		public new TValue this[string key] {
			get => this.GetValue(key);
			set => base[key] = value;
		}
	}
}
