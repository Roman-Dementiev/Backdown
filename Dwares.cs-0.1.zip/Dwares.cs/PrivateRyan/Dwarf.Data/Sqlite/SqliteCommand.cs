﻿using System;
using System.Data;
using Microsoft.Data.Sqlite;
using System.Data.Common;

namespace Dwarf.Data.Sqlite
{
	public class SqliteCommand : Microsoft.Data.Sqlite.SqliteCommand, ICommandParameters
	{
		public SqliteCommand() { }
		public SqliteCommand(string commandText, SqliteConnection connection) : base(commandText, connection) { }

		public string ParameterName(string column) => "@" + column;

		public SqliteParameter AddParamenter(string column, SqliteType type) => Parameters.Add(ParameterName(column), type);
		public SqliteParameter AddParamenter(string column, SqliteType type, int size) => Parameters.Add(ParameterName(column), type, size);

		public DbParameter AddTextParameter(string column, string text = null)
		{
			if (text != null) {
				var parameter = AddParamenter(column, SqliteType.Text, text.Length);
				parameter.Value = text;
				return parameter;
			} else {
				return AddParamenter(column, SqliteType.Text);
			}
		}

		public DbParameter AddBoolParameter(string column, bool? value = null)
		{
			if (value != null) {
				var parameter = AddParamenter(column, SqliteType.Integer);
				parameter.Value = (bool)value ? 1 : 0;
				return parameter;
			} else {
				return AddParamenter(column, SqliteType.Integer);
			}
		}

		public DbParameter AddIntParameter(string column, int? value = null)
		{
			if (value != null) {
				return AddLongParameter(column, (long)value);
			} else {
				return AddLongParameter(column);
			}
		}

		public DbParameter AddLongParameter(string column, long? value = null)
		{
			if (value != null) {
				var parameter = AddParamenter(column, SqliteType.Integer);
				parameter.Value = value;
				return parameter;
			} else {
				return AddParamenter(column, SqliteType.Integer);
			}
		}

		public DbParameter AddRealParameter(string column, double? value = null)
		{
			if (value != null) {
				var parameter = AddParamenter(column, SqliteType.Real);
				parameter.Value = value;
				return parameter;
			} else {
				return AddParamenter(column, SqliteType.Real);
			}
		}

		public DbParameter AddBlobParameter(string column, byte[] blob = null)
		{
			if (blob != null) {
				var parameter = AddParamenter(column, SqliteType.Blob, blob.Length);
				parameter.Value = blob;
				return parameter;
			} else {
				return AddParamenter(column, SqliteType.Blob);
			}
		}

		public static string String(object value)
		{
			if (value == null) {
				return null;
			} else if (value is string str) {
				return str;
			} else {
				return value.ToString();
			}
		}

		public static bool? Boolean(object value)
		{
			if (value == null) {
				return null;
			} else if (value is bool b) {
				return b;
			} else {
				return Integer(value) != 0;;
			}
		}

		public static long? Integer(object value)
		{
			if (value == null) {
				return null;
			} else {
				return (long)Convert.ChangeType(value, typeof(long));
			}
		}

		public static double? Real(object value)
		{
			if (value == null) {
				return null;
			} else {
				return (double)Convert.ChangeType(value, typeof(double));
			}
		}

		public DbParameter AddParameter(string column, DbType type, object value = null)
		{
			switch (type)
			{
				case DbType.AnsiString:
				case DbType.AnsiStringFixedLength:
				case DbType.StringFixedLength:
					return AddTextParameter(column, String(value));

				case DbType.Boolean:
					return AddBoolParameter(column, Boolean(value));

				case DbType.Byte:
				case DbType.SByte:
				case DbType.Int16:
				case DbType.Int32:
				case DbType.Int64:
				case DbType.UInt16:
				case DbType.UInt32:
				case DbType.UInt64:
					return AddLongParameter(column, Integer(value));

				case DbType.Single:
				case DbType.Double:
				case DbType.Decimal:
					return AddRealParameter(column, Real(value));
				
				//case DbType.DateTime:
				//	DateTime? datetime = (value == null) ? (DateTime?)null : (DateTime)value;
				//	// TODO
				//	break;

				case DbType.Binary:
					return AddBlobParameter(column, value as byte[]);
				
				default:
					throw new NotSupportedException(type.ToString());
			}
		}

		public long LastInsertedRowId => SqliteDb.GetLastInsertedRowId(Connection);
	}
}
