﻿using System;
using System.IO;
using System.Collections.Generic;
using Dwarf.Parsing.Tiny;
using Dwarf.Utility;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing.Gold
{
	/// <summary>
	/// Class Grammar
	/// </summary>
	public class Grammar
	{
		public enum SymbolKind
		{
			Nonterminal,
			Terminal,
			Noise,
			EndOfFile,
			GroupStart,
			GroupEnd,
			Deprecated,
			Error
		}

		public class Parameter
		{
			public string Name { get; }
			public string Value { get; }

			public Parameter(string name, string value)
			{
				Name = name;
				Value = value;
			}

			public Parameter(string name, object value) :
				this(name, value.ToString())
			{ }
		}

		public class CharSet
		{
			public struct Range {
				public ushort start;
				public ushort end;
			}
			public ushort Index { get; }
			public ushort UnicodePlane { get; }
			public Range[] Ranges { get; }

			public CharSet(ushort index, string character)
			{
				// TODO
				throw new NotImplementedException();
			}

			public CharSet(ushort index, ushort unicodePlane, ushort rangeCount)
			{
				Index = index;
				UnicodePlane = unicodePlane;
				Ranges = new Range[rangeCount];
			}
		}

		public class Symbol
		{
			public ushort Index { get; }
			public string Name { get; }
			public ushort Kind { get; }
			public Group Group { get; set; }
			public bool IsEndOfFile { get { return Kind == (ushort)SymbolKind.EndOfFile; } }
			public bool IsError { get { return Kind == (ushort)SymbolKind.Error; } }
			public bool IsNoise { get { return Kind == (ushort)SymbolKind.Noise; } }
			public bool IsTerminal { get { return Kind == (ushort)SymbolKind.Terminal; } }
			public bool IsNonterminal { get { return Kind == (ushort)SymbolKind.Nonterminal; } }
			public bool IsGroupStart { get { return Kind == (ushort)SymbolKind.GroupStart; } }
			public bool IsGroupEnd { get { return Kind == (ushort)SymbolKind.GroupEnd; } }

			public Symbol(ushort index, string name, ushort kind)
			{
				Index = index;
				Name = name;
				Kind = kind;
				Group = null;
			}

			public override string ToString()
			{
				if (Kind == (ushort)SymbolKind.Terminal) {
					return Name;
				} else  if (Kind == (ushort)SymbolKind.Nonterminal) {
					return "<" + Name + ">";
				} else {
					return "{" + Name + "}";
				}
			}
		}

		public class Group
		{
			public const ushort cAdvanceToken = 0;
			public const ushort cAdvanceChar  = 1;
			public const ushort cEndingOpen   = 0;
			public const ushort cEndingClosed = 1;

			public ushort Index { get; }
			public string Name { get; }
			public Symbol Container { get; }
			public Symbol Start { get; }
			public Symbol End { get; }
			public ushort AdvanceMode { get; }
			public ushort EndingMode { get; }
			public ushort[] Nesting { get; }

			public Group(ushort index, string name, Symbol container, Symbol start, Symbol end,
						ushort advanceMode, ushort endingMode, int nestingCount)
			{
				Index = index;
				Name = name;
				Container = container;
				Start = start;
				End = end;
				AdvanceMode = advanceMode;
				EndingMode = endingMode;
				Nesting = new ushort[nestingCount];
			}
		}

		public class Rule
		{
			public ushort Index { get; }
			public ushort Head { get; }
			public ushort[] Symbols { get; }

			public Rule(ushort index, ushort head, int length)
			{
				Index = index;
				Head = head;
				Symbols = new ushort[length];
			}
		}

		public class DfaState
		{
			public struct Edge
			{
				public ushort charsetIndex;
				public ushort targetIndex;
			}

			public ushort Index { get; }
			public bool IsAcceptState { get; }
			public ushort AcceptIndex { get; }
			public Edge[] Edges { get; }

			public DfaState(ushort index, bool isAcceptState, ushort acceptIndex, int edgeCount)
			{
				Index = index;
				IsAcceptState = isAcceptState;
				AcceptIndex = acceptIndex;
				Edges = new Edge[edgeCount];
			}
		}

		public class LalrState
		{
			public enum ActionType
			{
				Shift = 1,
				Reduce = 2,
				Goto = 3,
				Accept = 4
			}

			public struct Action
			{
				public ushort symbol;
				public ushort action;
				public ushort target;
			}

			public ushort Index { get; }
			public Action[] Actions { get; }

			public LalrState(ushort index, int actionCount)
			{
				Index = index;
				Actions = new Action[actionCount];
			}
		}

		#region Constructors
		public Grammar()
		{
			Init();
		}

		public Grammar(string egtPath)
		{
			GTable table = new GTable(egtPath);
			Init(table);
		}

		private void Init()
		{
			Version = String.Empty;
			InitialDfaState = 0;
			InitialLalrState = 0;
			Parameters = null;
			CharSets = null;
			Symbols = null;
			Groups = null;
			Rules = null;
			DfaStates = null;
			LalrStates = null;
		}

		private void Init(GTable table)
		{
			Version = table.Version;
			InitialDfaState = table.InitialDfaState;
			InitialLalrState = table.InitialLalrState;
			Parameters = table.Parameters;
			CharSets = table.CharSets;
			Symbols = table.Symbols;
			Groups = table.Groups;
			Rules = table.Rules;
			DfaStates = table.DfaStates;
			LalrStates = table.LalrStates;
		}
		#endregion

		#region Properties
		public string Version { get; protected set; }
		public List<Parameter> Parameters { get; protected set; }
		public CharSet[] CharSets { get; protected set; }
		public Symbol[] Symbols { get; protected set; }
		public Group[] Groups { get; protected set; }
		public Rule[] Rules { get; protected set; }
		public DfaState[] DfaStates { get; protected set; }
		public LalrState[] LalrStates { get; protected set; }
		public ushort InitialDfaState { get; protected set; }
		public ushort InitialLalrState { get; protected set; }
		#endregion

		#region Methods
		public ILexer CreateLexer(GoldSymbols symbols = null, bool simplify = true)
		{
			if (symbols == null) {
				symbols = new GoldSymbols(this);
			}
			var charSets = new GoldCharSets(this);
			var dfaStates = new GoldDfaStates(this);
			var dfa = new DFA(charSets, dfaStates, InitialDfaState);
			if (simplify) {
				if (symbols.GroupsCount == 0) {
					return dfa;
				}
			}

			return new GoldLexer(symbols, dfa);
		}

		public GoldParser CreateGoldParser(TerminalFactory terminalFactory, NonterminalFactory nonterminalFactory)
		{
			var parser = new GoldParser(this);
			parser.TerminalFactory = terminalFactory;
			parser.NonterminalFactory = nonterminalFactory;
			return parser;
		}

		public GoldParser CreateGoldParser(TokenFactory tokenFactory)
		{
			var parser = new GoldParser(this);
			parser.Factory = tokenFactory;
			return parser;
		}

		public TinyParser CreateTinyParser(TerminalFactory terminalFactory, NonterminalFactory nonterminalFactory)
		{
			GoldSymbols symbols = new GoldSymbols(this);

			int i, length = CharSets.Length;
			char[][] charSetTable = new char[length][];
			for (i = 0; i < length; i++) {
				CharSet cs = CharSets[i];
				char[] ranges = new char[2 * cs.Ranges.Length];
				int k = 0;
				foreach (CharSet.Range range in cs.Ranges) {
					ranges[k++] = (char)range.start;
					ranges[k++] = (char)(range.end + 1);
				}
				charSetTable[i] = ranges;
			}

			length = Rules.Length;
			ushort[][] rulesTable = new ushort[length][];
			for (i = 0; i < length; i++) {
				Grammar.Rule rule = Rules[i];
				ushort[] ruleSyms = new ushort[rule.Symbols.Length + 1];
				ruleSyms[0] = rule.Head;
				for (int k = 1; k < ruleSyms.Length; k++) {
					ruleSyms[k] = rule.Symbols[k - 1];
				}
				rulesTable[i] = ruleSyms;
			}

			length = DfaStates.Length;
			ushort[][] dfaStateTable = new ushort[length][];
			for (i = 0; i < length; i++) {
				Grammar.DfaState dfaState = DfaStates[i];
				ushort[] state = new ushort[2 * dfaState.Edges.Length + 1];
				state[0] = dfaState.IsAcceptState ? dfaState.AcceptIndex : TinyDFA.cSymNone;
				int k = 1;
				foreach (Grammar.DfaState.Edge edge in dfaState.Edges) {
					state[k++] = edge.charsetIndex;
					state[k++] = edge.targetIndex;
				}
				dfaStateTable[i] = state;
			}

			length = LalrStates.Length;
			ushort[][] lalrStateTable = new ushort[length][];
			for (i = 0; i < length; i++) {
				Grammar.LalrState lalrState = LalrStates[i];
				ushort[] state = new ushort[2 * lalrState.Actions.Length];
				int k = 0;
				foreach (Grammar.LalrState.Action action in lalrState.Actions) {
					state[k++] = action.symbol;
					state[k++] = (ushort)(((action.action-1) << 14) | action.target);
				}
				lalrStateTable[i] = state;
			}

			TinyDFA dfa = new TinyDFA(charSetTable, dfaStateTable, InitialDfaState);
			ILexer lexer;
			if (symbols.GroupsCount == 0) {
				lexer = dfa;
			} else {
				lexer = new GoldLexer(symbols, dfa);
			}

			var parser = new TinyParser(symbols, lexer, rulesTable, lalrStateTable, InitialLalrState);
			parser.TerminalFactory = terminalFactory;
			parser.NonterminalFactory = nonterminalFactory;
			return parser;
		}

		public TinyParser CreateTinyParser(TokenFactory tokenFactory)
		{
			var parser = CreateTinyParser(null, null);
			parser.Factory = tokenFactory;
			return parser;
		}

		public void Dump(TextWriter writer)
		{
			writer.WriteLine("Version: {0}", Version);
			DumpProperties(writer);
			DumpTableCounts(writer);
			DumpCharSets(writer);
			DumpSymbols(writer);
			DumpGroups(writer);
			DumpRules(writer);
			DumpDfaStates(writer);
			DumpLalrStates(writer);
			DumpInitialStates(writer);
		}

		public void DumpProperties(TextWriter writer)
		{
			writer.WriteLine("Properties:");
			int index = 0;
			foreach (Parameter property in Parameters) {
				writer.WriteLine("  Property[{0}] {1} = {2}", index++, property.Name, property.Value);
			}
		}

		public void DumpTableCounts(TextWriter writer)
		{
			writer.WriteLine("Table Counts:");
			writer.WriteLine("  Char Sets     {0}", CharSets.Length);
			writer.WriteLine("  Symbols       {0}", Symbols.Length);
			writer.WriteLine("  Groups        {0}", Groups.Length);
			writer.WriteLine("  Productions   {0}", Rules.Length);
			writer.WriteLine("  DFA States    {0}", DfaStates.Length);
			writer.WriteLine("  LALR States   {0}", LalrStates.Length);
		}

		public void DumpCharSets(TextWriter writer)
		{
			writer.WriteLine("Character Sets:");
			foreach (CharSet charset in CharSets) {
				writer.Write("  CS[{0}] ", charset.Index);

				for (int i = 0; i < charset.Ranges.Length; i++) {
					if (i > 0) writer.Write(", ");

					ushort start = charset.Ranges[i].start;
					ushort end = charset.Ranges[i].end;
					if (start == end) {
						writer.Write("'{0}'", ((char)start).ToPrintable());
					} else {
						writer.Write("'{0}'-'{1}'", ((char)start).ToPrintable(), ((char)end).ToPrintable());
					}
				};
				writer.WriteLine();
			}
		}

		public void DumpSymbols(TextWriter writer)
		{
			writer.WriteLine("Symbols:");
			foreach (Symbol symbol in Symbols) {
				writer.WriteLine("  Symbol[{0}] {1} ({2})", symbol.Index, symbol.ToString(), (SymbolKind)symbol.Kind);
			}
		}

		public void DumpGroups(TextWriter writer)
		{
			writer.WriteLine("GroupSymbol:");
			foreach (Group group in Groups) {
				writer.WriteLine("  Group[{0}] {1}", group.Index, group.Name);
			}
		}

		public void DumpRules(TextWriter writer)
		{
			writer.WriteLine("Productions:");
			foreach (Rule rule in Rules) {
				// TODO
				Symbol symbol = Symbols[rule.Head];
				writer.Write("  Rule[{0}] {1} ::=", rule.Index, symbol.ToString());
				for (int i = 0; i < rule.Symbols.Length; i++) {
					symbol = Symbols[rule.Symbols[i]];
					writer.Write(" {0}", symbol.ToString());
				}
				writer.WriteLine();
			}
		}

		public void DumpDfaStates(TextWriter writer)
		{
			writer.WriteLine("DFA States:");
			foreach (DfaState dfa in DfaStates) {
				writer.Write("  DFA[{0}] Accept State? = {1}", dfa.Index, dfa.IsAcceptState);
				if (dfa.IsAcceptState) {
					writer.WriteLine(", Accept Symbol = {0}", Symbols[dfa.AcceptIndex].ToString());
				} else {
					writer.WriteLine();
				}
				foreach (DfaState.Edge edge in dfa.Edges) {
					writer.WriteLine("          CS[{0}] => DFA[{1}]", edge.charsetIndex, edge.targetIndex);
				}
			}
		}

		public void DumpLalrStates(TextWriter writer)
		{
			writer.WriteLine("LALR States:");
			foreach (LalrState lalr in LalrStates) {
				writer.WriteLine("  LALR[{0}]", lalr.Index);
				foreach (LalrState.Action action in lalr.Actions) {
					Symbol symbol = Symbols[action.symbol];
					string actionType;
					string targetName = String.Empty;
					switch (action.action) {
					case (ushort)LalrState.ActionType.Shift:
						actionType = "Shift";
						targetName = String.Format("LALR[{0}]", action.target);
						break;
					case (ushort)LalrState.ActionType.Reduce:
						actionType = "Reduce";
						targetName = String.Format("Rule[{0}]", action.target);
						break;
					case (ushort)LalrState.ActionType.Goto:
						actionType = "Goto";
						targetName = String.Format("LALR[{0}]", action.target);
						break;
					case (ushort)LalrState.ActionType.Accept:
						actionType = "Accept";
						break;
					default:
						actionType = "Unknown action";
						break;
					}
					writer.WriteLine("          {0} => {1} {2}", symbol.ToString(), actionType, targetName);
				}
			}
		}

		public void DumpInitialStates(TextWriter writer)
		{
			writer.WriteLine("Initial States: DFA[{0}] LALR[{1}]", InitialDfaState, InitialLalrState);
		}
		#endregion

	}

	#region UnitGrammar
	public sealed class UnitGrammar : ClassUnit
	{
		private UnitGrammar() : base(typeof(Grammar), UnitGold._) { }
		public static readonly UnitGrammar _ = new UnitGrammar();
		public static UnitGrammar Instance => _;
	}
	#endregion
}
