﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;


namespace Dwarf.Extensions
{
	public static partial class Extensions
	{
		public static TValue GetValue<TKey, TValue>(
			this Dictionary<TKey, TValue> dict,
			TKey key, TValue defaultValue=default(TValue))
		{
			if (dict.TryGetValue(key, out var value)) {
				return value;
			} else {
				return defaultValue;
			}
		}

		public static byte[] LoadToMemory(this Stream stream)
		{
			using (var memStream = new MemoryStream())
			{
				stream.CopyTo(memStream);
				return memStream.ToArray();
			}
		}

		public static int BinarySearch(this IList list, object item, IComparer comparer)
		{
			int low = 0, high = list.Count - 1;
			while (low <= high)
			{
				int mid = (low + high) / 2;
				int cmp = comparer.Compare(item, list[mid]);
				if (cmp == 0) {
					return mid;
				}

				if (cmp < 0) {
					high = mid - 1;
				} else {
					low = mid + 1;
				}
			}

			return -(low + 1);
		}
		public static int BinarySearch<TItem>(this IList<TItem> list, TItem item, IComparer<TItem> comparer)
		{
			int low = 0, high = list.Count - 1;
			while (low <= high)
			{
				int mid = (low + high) / 2;
				int cmp = comparer.Compare(item, list[mid]);
				if (cmp == 0)
				{
					return mid;
				}

				if (cmp < 0) {
					high = mid - 1;
				} else {
					low = mid + 1;
				}
			}

			return -(low + 1);
		}

		public static TValue ToValue<TValue>(this TValue? nullable, TValue @default = default(TValue)) where TValue : struct
		{
			if (nullable != null) {
				return (TValue)nullable;
			} else {
				return @default;
			}
		}

		public static TValue ToValue<TValue>(this TValue? nullable, Func<TValue> @default) where TValue : struct
		{
			if (nullable != null) {
				return (TValue)nullable;
			} else if (@default != null) {
				return @default();
			} else {
				return default(TValue);
			}
		}

	}
}
