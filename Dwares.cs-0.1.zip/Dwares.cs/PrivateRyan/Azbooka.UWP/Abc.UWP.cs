﻿using System;
using Windows.UI.Xaml;
using Dwarf.Platform;
using Dwarf.UWP;


namespace Azbooka
{
	public partial class Abc
	{
		public int UIThemeIndex {
			get { return uiThemeIndex; }
			set {
				if (value != uiThemeIndex) {
					uiThemeIndex = value;
					MainPage.RequestedTheme = (ElementTheme)uiThemeIndex;
				}
			}
		}
		int uiThemeIndex = 0;

		public int UILanguageIndex {
			get { return UILanguages.Instance.CurrentIndex; }
			set { UILanguages.Instance.CurrentIndex = value; }
		}
	}
}
