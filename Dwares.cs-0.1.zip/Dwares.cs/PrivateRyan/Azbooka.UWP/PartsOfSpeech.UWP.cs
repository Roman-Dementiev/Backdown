﻿using System;
using Windows.ApplicationModel.Resources;
using Dwarf.Extensions;


namespace Azbooka
{
	public partial class PartsOfSpeech
	{
		void LoadFromResources()
		{
			var loader = ResourceLoader.GetForViewIndependentUse("PoS");
			var languages = loader.GetStringSplit("@@", ',');
			foreach (var languageTag in languages)
			{
				var languagePoS = LoadFromResources(loader, languageTag);
				if (languagePoS != null) {
					this[languagePoS.LanguageTag] = languagePoS;

					if (languageTag == cGeneralTag) {
						generalPoS = languagePoS;
					}
				}
			}
		}

		LanguagePoSList LoadFromResources(ResourceLoader loader, string languageTag)
		{
			var tags = loader.GetStringSplit(languageTag, ',');
			if (tags.Length == 0)
				return null;

			var languagePoS = new LanguagePoSList(languageTag);
			foreach (var tag in tags) {
				var uid = String.Format("{0}-{1}", languageTag, tag);
				var split = loader.GetStringSplit(uid, ':');
				if (split.Length==0)
					continue;

				PoS PoS;
				if (split.Length == 1) {
					PoS = new PoS(uid, tag, split[0]);
				} else {
					PoS = new PoS(uid, split[0], split[1]);
				}
				languagePoS.Add(PoS);
			}

			return languagePoS;
		}

		LanguagePoSList LoadFromResources(string languageTag)
		{
			var loader = ResourceLoader.GetForViewIndependentUse("PoS");
			return LoadFromResources(loader, languageTag);
		}
	}
}
