﻿using System;
using Dwarf;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf
{
	public delegate string DescriptorN<TType, TArg>(TType obj, params TArg[] arg);
	public delegate string Encoding<TType>(TType obj);
	public delegate TType Decoding<TType>(string str);

	#region UnitDwarf
	public sealed class UnitDwarf : NamespaceUnit
	{
		private UnitDwarf() : base("Dwarf", null) { }
		public static readonly UnitDwarf _ = new UnitDwarf();
		public static UnitDwarf Instance => _;
	}
	#endregion
}

namespace Dwares
{
	#region UnitDwares
	public sealed class UnitDwares : NamespaceUnit
	{
		private UnitDwares() : base("Dwares", null) { }
		public static readonly UnitDwares _ = new UnitDwares();
		public static UnitDwares Instance => _;
	}
	#endregion
}
