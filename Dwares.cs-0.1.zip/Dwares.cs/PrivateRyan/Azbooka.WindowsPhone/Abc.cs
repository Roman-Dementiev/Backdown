﻿using System;
using Dwarf.ObjectModel;


namespace Azbooka
{
	public partial class Abc
	{
		public static MainPage MainPage { get; set; }

		static EntityCollection<DirectoryItem> InitDirectory()
		{
			//TODO
			return new EntityCollection<DirectoryItem>() {
			};
		}
	}
}
