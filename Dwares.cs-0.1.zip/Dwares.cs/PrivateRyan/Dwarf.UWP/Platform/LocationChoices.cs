﻿using System;
using System.Collections.Generic;


namespace Dwarf.Platform
{
	public class LocationChoices : Choices<Location>
	{
		int fixedCount;
		int recentCount;
		int maxRecentCount;
		IChoice chooseLocation;

		public LocationChoices(IEnumerable<Location> locations, SelectChoice select = SelectChoice.First) :
			this(locations, null, 0, select)
		{ }

		public LocationChoices(IEnumerable<Location> locations, int maxRecentCount, SelectChoice select = SelectChoice.First) :
			this(locations, null, maxRecentCount, select)
		{ }

		public LocationChoices(IEnumerable<Location> locations, IEnumerable<Location> recentLocations, int maxRecentCount, SelectChoice select = SelectChoice.First)
		{
			if (locations != null) {
				AddItems(locations);
			}
			fixedCount = Count;

			if (recentLocations != null) {
				AddItems(recentLocations);
			}
			recentCount = Count - fixedCount;
			this.maxRecentCount = maxRecentCount > 0 ? maxRecentCount : recentCount;

			Select(select);
		}

		public List<Location> RecentLocations()
		{
			var recent = new List<Location>();
			for (int i = 0, index = fixedCount; i < recentCount; i++) {
				if (this[index++] is Location location) {
					recent.Add(location);
				}
			}
			return recent;
		}

		public int ChooseLocationIndex => (chooseLocation != null) ? (fixedCount + recentCount) : -1;

		public IChoice ChooseLocationChoice {
			get => chooseLocation;
			set {
				if (value != chooseLocation) {
					if (chooseLocation == null) {
						Add(value);
					} else {
						this[ChooseLocationIndex] = value;
					}
					chooseLocation = value;
				}
			}
		}

		public ICommand ChooseLocationCommand {
			get => chooseLocation?.Command;
			set {
				if (chooseLocation != null) {
					chooseLocation.Command = value;
				} else {
					ChooseLocationChoice = new Choice() { Uid = "Choose", Command = value };
				}
			}
		}

		public override Location SetCurrent(Location location, bool add)
		{
			if (Contains(location, out currentChoice, out currentIndex)) {
				current = location;
			} else {
				if (add && maxRecentCount > 0)
				{
					if (recentCount == maxRecentCount) {
						RemoveAt(fixedCount);
						recentCount--;
					}
					if (chooseLocation != null) {
						currentIndex = fixedCount + recentCount;
						InsertItem(currentIndex, location);
					} else {
						currentIndex = AddItem(location);
					}
					recentCount++;
				}
				else {
					currentIndex = -1;
				}
				currentChoice = location;
				current = location;
			}

			RaiseCurrentChoiceChanged();
			return current;
		}
	}


	public class ChooseLocationChoice : Choice
	{
		public ChooseLocationChoice(string uid)
		{
			Uid = uid;
			Command = new RelayCommand(Choose);
		}

		public virtual void Choose()
		{
		}

		public override string ChoiceLabel => Uid != null ? Appx.GetString(Uid) : "Choose...";
	}
}
