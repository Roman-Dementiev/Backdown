﻿using System;
using System.Collections;
using System.Collections.Generic;


namespace Dwarf.Collections
{
	class ReadOnlyList<TItem> : ListWrapper<TItem>
	{
		public ReadOnlyList(IList<TItem> source) : base(source, true) { }
		public ReadOnlyList(IEnumerable<TItem> items) : base(items) { }

		public new bool IsReadOnly => true;

		public new TItem this[int index] {
			get => base[index];
			set => throw new NotSupportedException();
		}

		public new void Add(TItem item) => throw new NotSupportedException();
		public new void Clear() => throw new NotSupportedException();
		public new void CopyTo(TItem[] array, int arrayIndex) => throw new NotSupportedException();
		public new void Insert(int index, TItem item) => throw new NotSupportedException();
		public new bool Remove(TItem item) => throw new NotSupportedException();
		public new void RemoveAt(int index) => throw new NotSupportedException();
	}
}
