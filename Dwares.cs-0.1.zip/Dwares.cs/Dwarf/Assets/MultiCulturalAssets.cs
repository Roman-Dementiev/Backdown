﻿using System;
using System.Collections;
using System.Collections.Generic;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Assets
{
	public class MultiCulturalAssets : BaseAssets
	{
		#region Data
		private Dictionary<object, IAssets> dict = new Dictionary<object, IAssets>();
		#endregion Data

		#region Constructors
		public MultiCulturalAssets() : base(null, true) { }
		#endregion

		#region Methods
		public override IEnumerable GetCultures() => dict.Keys;

		public override void AddAsset(string key, object asset, object culture)
		{
			IAssets assets = dict[culture];
			if (assets == null) {
				if (culture == null) {
					assets = new CommonAssets();
				} else {
					assets = new CultureAssets(culture);
				}
				dict[culture] = assets;
			}
			assets.AddAsset(key, asset, culture);
		}

		public override object GetAsset(string key, object culture)
		{
			object asset = null;
			if (dict.ContainsKey(culture)) {
				IAssets assets = dict[culture];
				if (assets != null) {
					asset = assets.GetAsset(key, culture);
				}
			}

			if (asset == null && culture != null && dict.ContainsKey(null)) {
				IAssets assets = dict[null];
				if (assets != null) {
					asset = assets.GetAsset(key, culture);
				}
			}

			return asset;
		}

		public override void ReleaseAllAssets(bool dispose)
		{
			dict.ReleaseContent(dispose);
		}

		public override void ReleaseCultureAssets(object culture, bool dispose)
		{
			if (dict[culture] != null) {
				dict[culture].Release(dispose);
				dict.Remove(culture);
			}
		}
		#endregion

	}

	#region UnitCulturalAssets
	public sealed class UnitMultiCulturalAssets : ClassUnit
	{
		public UnitMultiCulturalAssets() : base(typeof(MultiCulturalAssets), UnitAssets._) { }
		public static readonly UnitMultiCulturalAssets _ = new UnitMultiCulturalAssets();
		public static UnitMultiCulturalAssets Instance => _;
	}
	#endregion
}
