﻿using System;
using Dwarf.Assets;
using Dwarf.Utility;
using Dwarf.Logging;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf
{
	/// <summary>
	/// Error event handler.
	/// </summary>
	/// <param name="exc">The exception.</param>
	public delegate void ExceptionHandler(object sender, Exception exc);

	/// <summary>
	/// Base class for Dwares exceptions
	/// </summary>
	/// <seealso cref="System.Exception" />
	public class DwarfException : Exception
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="Exception"/> class.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <param name="message">The message.</param>
		/// <param name="innerExc">The inner exception.</param>
		public DwarfException(Unit unit, string message, bool useAssets, Exception innerExc = null) :
			base(GetMessage(message, useAssets, innerExc), innerExc)
		{
			Unit = null;
			IsLogged = false;

			if (unit != null) {
				Source = unit.FullName;
			} else {
				if (innerExc != null) {
					Source = innerExc.Source;
				}
				if (Source == null) {
					Source = Sys.ProcessName;
				}
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="Exception"/> class.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <param name="innerExc">The inner exception.</param>
		/// <param name="format">The format.</param>
		/// <param name="args">The arguments.</param>
		public DwarfException(Unit unit, Exception innerExc, bool useAssets, string format, params object[] args) :
			this(unit, FormatMessage(innerExc, useAssets, format, args), false, innerExc)
		{ }

		/// <summary>
		/// Gets the unit throwing the exception.
		/// </summary>
		/// <value>
		/// The unit.
		/// </value>
		public Unit Unit { get; }

		/// <summary>
		/// Gets a value indicating whether the exception message was logged.
		/// </summary>
		/// <value>
		/// <c>true</c> if the message was logged; otherwise, <c>false</c>.
		/// </value>
		public bool IsLogged { get; private set; }

		/// <summary>
		/// Logs the exception message if it was not logged yet.
		/// </summary>
		public void Log()
		{
			if (!IsLogged) {
				Dwarf.Log.Write(LogLevel.Error, Source, Message);
				IsLogged = true;
			}
		}

		/// <summary>
		/// Logs the message if it was not logged yet and throws this exception.
		/// </summary>
		public void Throw()
		{
			Log();
			throw this;
		}

		/// <summary>
		/// Wraps the specified exception if it isn't instance of <see cref="DwarfException"/>.
		/// </summary>
		/// <param name="exc">The exception.</param>
		/// <returns>The same exception if it is DwarfException; otherwise wrapper for argument.</returns>
		public static DwarfException Wrap(Exception exc)
		{
			DwarfException dwarfExc = exc as DwarfException;
			if (dwarfExc != null) {
				return dwarfExc;
			} else {
				return new DwarfException(null, null, false, exc);
			}
		}

		/// <summary>
		/// <see cref="ExceptionHandler"/> that writes the exception message to <see cref="Log"/>.
		/// </summary>
		/// <param name="sender">The sender.</param>
		/// <param name="exc">The exception.</param>
		public static void Log(object sender, Exception exc)
		{
			Wrap(exc).Log();
		}

		/// <summary>
		/// <see cref="ExceptionHandler"/> handler that logs the exception message and throws the exception.
		/// </summary>
		/// <param name="sender">The sender.</param>
		/// <param name="exc">The exception.</param>
		public static void Throw(object sender, Exception exc)
		{
			Wrap(exc).Throw();
		}

		/// <summary>
		/// Formats the message.
		/// </summary>
		/// <param name="innerExc">The inner exception.</param>
		/// <param name="format">The format.</param>
		/// <param name="args">The arguments.</param>
		/// <returns></returns>
		public static string FormatMessage(Exception innerExc, bool useAssets, string format, params object[] args)
		{
			if (useAssets) {
				format = AssetMgr.GetString(format, true);
			}
			string message = String.Format(format, args);
			if (innerExc != null && !String.IsNullOrEmpty(innerExc.Message)) {
				message = String.Format("{0} <= {1}", message, innerExc.Message);
			}
			return message;
		}

		public static string GetMessage(string message, bool useAssets, Exception innerExc)
		{
			if (message != null) {
				if (useAssets) {
					message = AssetMgr.GetString(message, true);
				}
				return message;
			}
			if (innerExc != null) {
				return innerExc.Message;
			}
			return String.Empty;
		}
	}
}
