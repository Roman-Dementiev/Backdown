﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing.Gold
{
	/// <summary>
	/// Class GoldRules
	/// </summary>
	public class GoldRules : IRules
	{
		#region Fields
		private Grammar.Rule[] rules;
		#endregion

		#region Constructors
		public GoldRules(Grammar grammar)
		{
			rules = grammar.Rules;
		}
		#endregion

		#region Properties
		public Grammar.Rule[] GrammarRules => rules;
		public int RulesCount => rules.Length;
		#endregion

		#region Methods
		public int GetHeadSymbol(uint rule)
		{
			Debug.Assert(rule < rules.Length);
			return rules[rule].Head;
		}

		public int GetRuleLength(uint rule)
		{
			Debug.Assert(rule < rules.Length);
			return rules[rule].Symbols.Length;
		}

		public int GetRuleSymbol(uint rule, uint index)
		{
			Debug.Assert(rule < rules.Length && index < rules[rule].Symbols.Length);
			return rules[rule].Symbols[index];
		}

		public bool IsTrimable(uint rule)
		{
			Debug.Assert(rule < rules.Length);
			return rules[rule].Symbols.Length == 1;
		}
		#endregion

	}

	#region UnitGoldRules
	public sealed class UnitGoldRules : ClassUnit
	{
		private UnitGoldRules() : base(typeof(GoldRules), UnitGold._) { }
		public static readonly UnitGoldRules _ = new UnitGoldRules();
		public static UnitGoldRules Instance => _;
	}
	#endregion
}
