﻿using System;
using System.Threading;
using Windows.UI.Xaml.Controls;
using Dwarf.Localization;


namespace Azbooka
{
	public sealed partial class AboutPanel : SettingsFlyout
	{
		public AboutPanel()
		{
			this.InitializeComponent();
		}

		public Localizable Localizable => LazyInitializer.EnsureInitialized(
			ref localizable, () => new Localizable() {
				appTitle
			});
		Localizable localizable;
	}
}
