﻿using System.IO;
using Dwarf.Utility;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing
{
	/// <summary>
	/// Interface ILexer
	/// </summary>
	public interface ILexer
	{
		TextPosition Position { get; }
		char[] Buffer { get; }
		DwarfException Error { get; }

		void Prepare(TextReader source);
		int LookaheadToken(out int start, out int length);
		void ConsumeLookahead();
	}

	#region UnitILexer
	public sealed class UnitILexer : InterfaceUnit
	{
		private UnitILexer() : base(typeof(ILexer), UnitParsing._) { }
		public static readonly UnitILexer _ = new UnitILexer();
		public static UnitILexer Instance => _;
	}
	#endregion
}
