﻿using System;
using System.Collections.Generic;
using Dwarf.Logging;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf
{
	/// <summary>
	/// Utility class Log
	/// </summary>
	public static class Log
	{
		public readonly static ILogger cNullLogger = new NullLogger();
#if DEBUG
		public readonly static ILogger cDebugLogger = new DebugLogger();
#endif
		private readonly static ILogFormatter cDefaultFormatter = new DefaultLogFormatter();
		private static Dictionary<Unit, LogLevel> sUnitLevels = new Dictionary<Unit, LogLevel>();

		#region Properties
		/// <summary>
		/// Gets or sets the current logger.
		/// </summary>
		/// <value>
		/// The logger.
		/// </value>
		public static ILogger Logger { get; set; } =
#if DEBUG
		cDebugLogger;
#else
		cNullLogger;
#endif

		/// <summary>
		/// Gets or sets the default logging level for all units.
		/// </summary>
		/// <value>
		/// The default logging level.
		/// </value>
		public static LogLevel DefaultLogLevel { get; set; } = LogLevel.Default;

		/// <summary>
		/// Gets or sets the log format.
		/// </summary>
		/// <value>
		/// The log format.
		/// </value>
		public static ILogFormatter Formatter { get; set; } = cDefaultFormatter;
		#endregion

		#region Methods
		/// <summary>
		/// Pushes the logger on top of current logger.
		/// </summary>
		/// <param name="logger">The logger.</param>
		public static void PushLogger(ILogger logger)
		{
			logger.BackLogger = Logger;
			Logger = logger;
		}

		/// <summary>
		/// Pops current logger from the logger stack.
		/// </summary>
		/// <returns></returns>
		public static ILogger PopLogger()
		{
			ILogger logger = Logger;
			Logger = logger.BackLogger;
			if (Logger == null) {
				Logger = cNullLogger;
			}
			return logger;
		}

		/// <summary>
		/// Gets logging level for specified unit level.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <returns>Logging level for the unit or default level if unit=<c>null</c>.</returns>
		public static LogLevel GetUnitLogLevel(Unit unit)
		{
			if (unit != null && sUnitLevels.ContainsKey(unit)) {
				return sUnitLevels[unit];
			} else {
				return DefaultLogLevel;
			}
		}

		/// <summary>
		/// Sets logging level for specified unit.
		/// </summary>
		/// <param name="unit">The unit. If unit=<c>null</c> sets default level</param>
		/// <param name="level">The level.</param>
		public static void SetUnitLogLevel(Unit unit, LogLevel level)
		{
			if (unit == null) {
				DefaultLogLevel = level;
			} else {
				sUnitLevels[unit] = level;
			}
		}

		/// <summary>
		/// Gets effective log level for specified unit.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <returns></returns>
		public static LogLevel GetLogLevel(Unit unit)
		{
			bool found = false;
			LogLevel level = LogLevel.All;
			if (unit != null) {
				do {
					if (sUnitLevels.ContainsKey(unit)) {
						found = true;
						LogLevel unitLevel = sUnitLevels[unit];
						if (level > unitLevel) {
							level = unitLevel;
							if (level == LogLevel.None)
								break;
						}
					}
					unit = unit.Namespace;
				}
				while (unit != null);
			}

			if (found) {
				return level;
			} else {
				return DefaultLogLevel;
			}
		}

		/// <summary>
		/// Writes log message from specified unit.
		/// </summary>
		/// <param name="level">Logging level.</param>
		/// <param name="source">The source.</param>
		/// <param name="message">The message.</param>
		public static void Write(LogLevel level, string source, string message)
		{
			if (level <= DefaultLogLevel) {
				if (Logger.CustomFormat) {
					Logger.Write(level, source, message, null, false);
				} else {
					String msg = Formatter.Format(level, source, message);
					Logger.Write(level, source, msg, null, true);
				}
			}
		}

		/// <summary>
		/// Writes formatted log message from specified unit.
		/// </summary>
		/// <param name="level">Logging level.</param>
		/// <param name="source">The source.</param>
		/// <param name="format">The format.</param>
		/// <param name="args">The arguments.</param>
		public static void Write(LogLevel level, string source, string format, params object[] args)
		{
			if (level <= DefaultLogLevel) {
				if (Logger.CustomFormat) {
					Logger.Write(level, source, format, args, false);
				} else {
					String msg = Formatter.Format(level, source, format, args);
					Logger.Write(level, source, msg, null, true);
				}
			}
		}

		/// <summary>
		/// Writes log message from specified unit.
		/// </summary>
		/// <param name="level">Logging level.</param>
		/// <param name="unit">The unit.</param>
		/// <param name="message">The message.</param>
		public static void Write(LogLevel level, Unit unit, string message)
		{
			if (level <= GetLogLevel(unit)) {
				string source = unit.FullName;
				if (Logger.CustomFormat) {
					Logger.Write(level, source, message, null, false);
				} else {
					String msg = Formatter.Format(level, unit.FullName, message);
					Logger.Write(level, source, msg, null, true);
				}
			}
		}

		/// <summary>
		/// Writes formatted log message from specified unit.
		/// </summary>
		/// <param name="level">Logging level.</param>
		/// <param name="unit">The unit.</param>
		/// <param name="format">The format.</param>
		/// <param name="args">The arguments.</param>
		public static void Write(LogLevel level, Unit unit, string format, params object[] args)
		{
			if (level <= GetLogLevel(unit)) {
				string source = unit.FullName;
				if (Logger.CustomFormat) {
					Logger.Write(level, source, format, args, false);
				} else {
					String msg = Formatter.Format(level, source, format, args);
					Logger.Write(level, source, msg, null, true);
				}
			}
		}

		/// <summary>
		/// Writes fatal error message from specified unit.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <param name="message">The message.</param>
		public static void Fatal(Unit unit, string message)
		{
			Write(LogLevel.Fatal, unit, message);
		}

		/// <summary>
		/// Writes formatted fatal error message from specified unit.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <param name="format">The format.</param>
		/// <param name="args">The arguments.</param>
		public static void Fatal(Unit unit, string format, params object[] args)
		{
			Write(LogLevel.Fatal, unit, format, args);
		}

		/// <summary>
		/// Writes error message from specified unit..
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <param name="message">The message.</param>
		public static void Error(Unit unit, string message)
		{
			Write(LogLevel.Error, unit, message);
		}

		/// <summary>
		/// Writes formatted error message from specified unit.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <param name="format">The format.</param>
		/// <param name="args">The arguments.</param>
		public static void Error(Unit unit, string format, params object[] args)
		{
			Write(LogLevel.Error, unit, format, args);
		}

		/// <summary>
		/// Writes warning message from specified unit.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <param name="message">The message.</param>
		public static void Warning(Unit unit, string message)
		{
			Write(LogLevel.Warning, unit, message);
		}

		/// <summary>
		/// Writes formatted warning message from specified unit.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <param name="format">The format.</param>
		/// <param name="args">The arguments.</param>
		public static void Warning(Unit unit, string format, params object[] args)
		{
			Write(LogLevel.Warning, unit, format, args);
		}

		/// <summary>
		/// Writes important message from specified unit.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <param name="message">The message.</param>
		public static void Important(Unit unit, string message)
		{
			Write(LogLevel.Important, unit, message);
		}

		/// <summary>
		/// Writes formatted important message from specified unit.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <param name="format">The format.</param>
		/// <param name="args">The arguments.</param>
		public static void Important(Unit unit, string format, params object[] args)
		{
			Write(LogLevel.Important, unit, format, args);
		}

		/// <summary>
		/// Writes normal message from specified unit.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <param name="message">The message.</param>
		public static void Message(Unit unit, string message)
		{
			Write(LogLevel.Message, unit, message);
		}

		/// <summary>
		/// Writes formatted normal message from specified unit.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <param name="format">The format.</param>
		/// <param name="args">The arguments.</param>
		public static void Message(Unit unit, string format, params object[] args)
		{
			Write(LogLevel.Message, unit, format, args);
		}

		/// <summary>
		/// Writes verbose message from specified unit.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <param name="message">The message.</param>
		public static void Verbose(Unit unit, string message)
		{
			Write(LogLevel.Verbose, unit, message);
		}

		/// <summary>
		/// Writes formatted verbose message from specified unit.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <param name="format">The format.</param>
		/// <param name="args">The arguments.</param>
		public static void Verbose(Unit unit, string format, params object[] args)
		{
			Write(LogLevel.Verbose, unit, format, args);
		}

		/// <summary>
		/// Writes debug message from specified unit.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <param name="message">The message.</param>
		public static void Debug(Unit unit, string message)
		{
			Write(LogLevel.Debug, unit, message);
		}

		/// <summary>
		/// Writes formatted debug message from specified unit.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <param name="format">The format.</param>
		/// <param name="args">The arguments.</param>
		public static void Debug(Unit unit, string format, params object[] args)
		{
			Write(LogLevel.Debug, unit, format, args);
		}

		/// <summary>
		/// Writes trace message from specified unit.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <param name="message">The message.</param>
		public static void Trace(Unit unit, string message)
		{
			Write(LogLevel.Trace, unit, message);
		}

		/// <summary>
		/// Writes formatted trace message from specified unit.
		/// </summary>
		/// <param name="unit">The unit.</param>
		/// <param name="format">The format.</param>
		/// <param name="args">The arguments.</param>
		public static void Trace(Unit unit, string format, params object[] args)
		{
			Write(LogLevel.Trace, unit, format, args);
		}

		#endregion
	}

	#region UnitLog
	public class UnitLog : UtilityUnit
	{
		private UnitLog() : base(typeof(Log), UnitDwarf._) { }
		public static readonly UnitLog _ = new UnitLog();
		public static UnitLog Instance => _;
	}
	#endregion
}
