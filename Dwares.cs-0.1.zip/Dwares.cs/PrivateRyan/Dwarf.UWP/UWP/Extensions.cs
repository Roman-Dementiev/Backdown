﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;
using Windows.UI.Xaml.Input;


namespace Dwarf.Extensions
{
	public static partial class Extensions
	{
		public static InputScopeNameValue DefaultScopeNameValue(this InputScope inputScope)
		{
			if (inputScope.Names.Count > 0) {
				return inputScope.Names[0].NameValue;
			} else {
				return default(InputScopeNameValue);
			}
		}

		public static InputScope ToInputScope(this InputScopeNameValue value)
		{
			var inputScope = new InputScope();
			var scopeName = new InputScopeName();
			scopeName.NameValue = value;
			inputScope.Names.Add(scopeName);
			return inputScope;
		}

		public static async Task<bool> FileExistsAsync(this StorageFolder folder, string filename)
		{
			try {
				var file = await folder.GetFileAsync(filename);
				return file != null;
			} catch {
				return false;
			}
		}

		public static async Task<bool> FileDoesNotExistAsync(this StorageFolder folder, string filename)
		{
			bool exists = await FileExistsAsync(folder, filename);
			return !exists;
		}

		public static StorageFolder GetFolder(this KnownFolderId folderId)
		{
			switch (folderId) {
			case KnownFolderId.AppCaptures:
				return KnownFolders.AppCaptures;
			case KnownFolderId.CameraRoll:
				return KnownFolders.CameraRoll;
			case KnownFolderId.DocumentsLibrary:
				return KnownFolders.DocumentsLibrary;
			case KnownFolderId.HomeGroup:
				return KnownFolders.HomeGroup;
			case KnownFolderId.MediaServerDevices:
				return KnownFolders.MediaServerDevices;
			case KnownFolderId.MusicLibrary:
				return KnownFolders.MusicLibrary;
			case KnownFolderId.Objects3D:
				return KnownFolders.Objects3D;
			case KnownFolderId.PicturesLibrary:
				return KnownFolders.PicturesLibrary;
			case KnownFolderId.Playlists:
				return KnownFolders.Playlists;
			case KnownFolderId.RecordedCalls:
				return KnownFolders.RecordedCalls;
			case KnownFolderId.RemovableDevices:
				return KnownFolders.RemovableDevices;
			case KnownFolderId.SavedPictures:
				return KnownFolders.SavedPictures;
			//case KnownFolderId.Screenshots:
			//	return KnownFolders.Screenshots;
			case KnownFolderId.VideosLibrary:
				return KnownFolders.VideosLibrary;
			}

			return null;

		}
	}
}
