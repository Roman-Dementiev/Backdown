﻿using System;


namespace Dwarf.Data
{
	public static class Convert
	{
		public static object ChangeType(object value, Type type)
		{
			return System.Convert.ChangeType(value, type);
		}

		public static T ConvertTo<T>(object value)
		{
			return (T)System.Convert.ChangeType(value, typeof(T));
		}

		public static T? ToNullabe<T>(object value) where T : struct
		{
			if (value == null || DBNull.Value.Equals(value)) {
				return null;
			} else {
				return (T?)System.Convert.ChangeType(value, typeof(T));
			}
		}

		public static T? ToNullabe<T>(object value, bool nullForInvalid = true) where T : struct
		{
			if (value == null || DBNull.Value.Equals(value)) {
				return null;
			} else {
				try {
					return (T?)System.Convert.ChangeType(value, typeof(T));
				} catch {
					if (nullForInvalid) {
						return null;
					}  else {
						throw;
					}
				}
			}
		}

		public static string ToString(object value)
		{
			if (value == null) {
				return null;
			} else if (value.GetType() == typeof(string)) {
				return (string)value;
			} else {
				return value.ToString();
			}
		}

		public static Boolean? ToBoolean(object value) => ToNullabe<Boolean>(value);
		public static Byte? ToByte(object value) => ToNullabe<Byte>(value);
		public static SByte? ToSByte(object value) => ToNullabe<SByte>(value);
		public static Int16? ToInt16(object value) => ToNullabe<Int16>(value);
		public static Int32? ToInt32(object value) => ToNullabe<Int32>(value);
		public static Int64? ToInt64(object value) => ToNullabe<Int64>(value);
		public static UInt16? ToUInt16(object value) => ToNullabe<UInt16>(value);
		public static UInt32? ToUInt32(object value) => ToNullabe<UInt32>(value);
		public static UInt64? ToUInt64(object value) => ToNullabe<UInt64>(value);
		public static Single? ToSingle(object value) => ToNullabe<Single>(value);
		public static Double? ToDouble(object value) => ToNullabe<Double>(value);
		public static DateTime? ToDateTime(object value) => ToNullabe<DateTime>(value);
	}
}
