﻿using System;

namespace Dwarf.Logging
{
	/// <summary>
	/// Abstract class BaseLogFormatter
	/// </summary>
	public abstract class BaseLogFormatter : ILogFormatter
	{
		#region Constructors
		/// <summary>
		/// Initializes a new instance of the <see cref="BaseLogFormatter"/> class.
		/// </summary>
		public BaseLogFormatter()
		{
			IndentSize = 4;
			IndentLevel = 0;
		}
		#endregion

		#region Properties
		/// <summary>
		/// Gets or sets the number of spaces in an indent.
		/// </summary>
		/// <value>
		/// The number of spaces in an indent. The default is four.
		/// </value>
		public uint IndentSize { get; set; }

		/// <summary>
		/// Gets or sets the indent level.
		/// </summary>
		/// <value>
		/// The indent level.
		/// </value>
		public uint IndentLevel { get; protected set; }
		#endregion

		#region Methods
		/// <summary>
		/// Increases the current IndentLevel by one.
		/// </summary>
		public void Indent()
		{
			IndentLevel++;
		}

		/// <summary>
		/// Decreases the current IndentLevel by one.
		/// </summary>
		public void Unindent()
		{
			if (IndentLevel > 0) {
				IndentLevel--;
			}
		}

		public abstract string Format(LogLevel level, string source, string message);

		public string Format(LogLevel level, string source, string format, params object[] args)
		{
			string message;
			if (args == null) {
				message = format;
			} else {
				message = String.Format(format, args);
			}
			return Format(level, source, message);
		}

		#endregion
	}

	#region UnitBaseLogFormatter
	#pragma warning disable RCS1060, RCS1023
	public sealed class  UnitBaseLogFormatter : ClassUnit
	{
		private UnitBaseLogFormatter() :  base(typeof(BaseLogFormatter), UnitLogging._) {}
		public static readonly UnitBaseLogFormatter _ = new UnitBaseLogFormatter();
		public static UnitBaseLogFormatter Instance => _;
	}
	#endregion
}
