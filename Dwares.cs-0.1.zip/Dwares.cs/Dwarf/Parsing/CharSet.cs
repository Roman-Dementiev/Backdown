﻿using System;
using System.Collections.Generic;
using Dwarf.Assets;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing
{
	/// <summary>
	/// Class CharSet
	/// </summary>
	public class CharSet
	{
		public struct Range {
			public char start, end;

			public Range(char start, char end) {
				Debug.Assert(start < end);
				this.start = start;
				this.end = end;
			}
			public Range(Range range) {
				start = range.start;
				end = range.end;
			}
		}

		#region Fields
		private LinkedList<Range> ranges = null;
		private char[] array = null;
		#endregion

		#region Properties
		public string Name { get; set; } = null;
		public string Description { get; set; } = null;
		public LinkedList<Range> Ranges => GetRanges();
		public char[] RangesAsArray => GetArray();
		public int RangeCount {
			get {
				if (ranges != null)
					return ranges.Count;
				if (array != null)
					return array.Length / 2;
				return 0;
			}
		}
		#endregion

		#region Constructors
		public CharSet() {}

		public CharSet(char ch) :
			this(ch, ch, true)
		{
		}

		public CharSet(char start, char end, bool includeEnd = true)
		{
			if (includeEnd)
				end++;

			ranges = new LinkedList<Range>();
			ranges.AddFirst(new Range(start, end));
		}

		public CharSet(char firstStart, char firstEnd, params char[] more) :
			this(true, firstStart, firstEnd, more)
		{
		}

		public CharSet(bool includeEnds, char firstStart, char firstEnd, params char[] more) :
			this(firstStart, firstEnd, includeEnds)
		{
			for (int i = 1; i < more.Length; i += 2) {
				AddRange(more[i-1], more[i], includeEnds);
			}
		}

		public CharSet(CharSet charSet)
		{
			if (charSet.array != null) {
				array = charSet.array;
			} else if (charSet.ranges != null) {
				ranges = new LinkedList<Range>(charSet.ranges);
			}
		}

		public CharSet(char[] rangeArray)
		{
			if (!IsValidRangeArray(rangeArray))
				throw new ArgumentException(AssetMgr.GetString(Messages.InvalidRangeArray));

			array = rangeArray;
		}

		public static bool IsValidRangeArray(char[] rangeArray)
		{
			int length = rangeArray.Length;
			if (length % 2 != 0)
				return false;

			for (int i = 1; i < length; i++) {
				if (rangeArray[i] <= rangeArray[i - 1])
					return false;
			}

			return true;
		}
		#endregion

		#region Methods
		private LinkedList<Range> GetRanges()
		{
			if (ranges == null) {
				ranges = new LinkedList<Range>();
				if (array != null) {
					for (int i = 1; i < array.Length; i++) {
						ranges.AddLast(new Range(array[i-1], array[i]));
					}
				}
			}
			return ranges;
		}

		private char[] GetArray()
		{
			if (array == null) {
				if (ranges != null) {
					array = new char[2 * ranges.Count];
					int i = 0;
					for (LinkedListNode<Range> node = ranges.First; node != null; node = node.Next) {
						array[i++] = node.Value.start;
						array[i++] = node.Value.end;
					}
				} else {
					array = new char[0];
				}
			}
			return array;
		}

		public void AddChar(char ch)
		{
			AddRange(ch, ch, true);
		}

		public void AddRange(Range range)
		{
			AddRange(range.start, range.end, false);
		}

		public void AddRange(char start, char end, bool includeEnd)
		{
			if (includeEnd)
				end++;
			Debug.Assert(start < end);

			GetRanges();
			array = null;

			if (ranges.Count == 0) {
				ranges.AddFirst(new Range(start, end));
				return;
			}

			for (LinkedListNode<Range> node = ranges.First; node != null; node = node.Next) {
				Range range = node.Value;
				if (start > range.end)
					continue;

				if (end < range.start) {
					ranges.AddBefore(node, new Range(start, end));
					return;
				}
				if (end <= range.end) {
					node.Value = new Range(start, range.end);
					return;
				}

				if (range.start > start) {
					range.start = start;
				}
				if (range.end < end) {
					range.end = end;
				}

				LinkedListNode<Range> next = node.Next;
				while (next != null && next.Value.start <= range.end) {
					if (range.end < next.Value.end) {
						range.end = next.Value.end;
					}
					ranges.Remove(next);
					next = node.Next;
				}

				node.Value = range;
				return;
			}

			ranges.AddLast(new Range(start, end));
		}

		public static bool Contains(char[] rangeArray, char ch)
		{
			Debug.Assert(IsValidRangeArray(rangeArray));
			int found = Array.BinarySearch(rangeArray, ch);
			if (found < 0) {
				found = ~found;
				if (found == 0) {
					return false;
				}
				found--;
			}

			return (found % 2) == 0;
		}

		public bool Contains(char ch) => Contains(GetArray(), ch);

		public override bool Equals(object obj)
		{
			var charSet = obj as CharSet;
			if (charSet == null)
				return false;

			char[] array = GetArray();
			char[] csArray = charSet.GetArray();

			if (csArray.Length != array.Length)
				return false;

			for (int i = 0; i < array.Length; i++) {
				if (csArray[i] != array[i])
					return false;
			}

			return true;
		}

		#endregion

	}

	#region UnitCharSet
	public sealed class UnitCharSet : ClassUnit
	{
		private UnitCharSet() : base(typeof(CharSet), UnitParsing._) { }
		public static readonly UnitCharSet _ = new UnitCharSet();
		public static UnitCharSet Instance => _;
	}
	#endregion
}
