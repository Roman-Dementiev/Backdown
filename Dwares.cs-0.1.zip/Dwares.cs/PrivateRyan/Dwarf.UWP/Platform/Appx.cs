﻿using System;
using System.Reflection;
using System.IO;
using Windows.ApplicationModel.Resources;
using Windows.Globalization;
using Dwarf.Extensions;


namespace Dwarf.Platform
{
	public static class Appx
	{
		public static Assembly ApplicationAssembly { get; set; }
		public static void SetApplicationAssembly(Type appType)
		{
			if (appType==null) throw new ArgumentNullException(nameof(appType));
			ApplicationAssembly = appType.GetTypeInfo().Assembly;
		}

		public static ResourceLoader ResourceLoader {
			get { return resourceLoader ?? ResourceLoader.GetForCurrentView(); }
			set { resourceLoader = value; }
		}
		static ResourceLoader resourceLoader = null;

		//public static Uri ResourceBaseUri { get; } = new Uri("ms-resource:");
		//public static Uri ResourceUri(string resourceName) => new Uri(ResourceBaseUri, resourceName);
		//public static bool IsResourceUri(Uri uri) => uri != null && uri.Scheme == ResourceBaseUri.Scheme;

		public static Uri BaseContentUri { get; } = new Uri("ms-appx:///");
		public static Uri ContentUri(string path) => new Uri(BaseContentUri, path);
		public static bool IsContentUri(Uri uri) => uri != null && uri.Scheme == BaseContentUri.Scheme;

		public static Uri IconsBaseUri { get; set; } = new Uri(BaseContentUri, "Assets/Icons/");
		public static Uri IconUri(string name)  => new Uri(IconsBaseUri, name);

		public static string GetString(string key, string defaultValue)
		{
			return ResourceLoader.GetString(key, defaultValue);
		}

		public static string GetString(string key, bool useKeyAsDefault=true)
		{
			return ResourceLoader.GetString(key, useKeyAsDefault ? key : String.Empty);
		}

		public static Bitmap GetBitmap(Uri uri)
		{
			return new Bitmap(uri);
		}

		public static Bitmap GetBitmap(string path)
		{
			return new Bitmap(ContentUri(path));
		}

		public static Bitmap GetIcon(string name, string ext=".png")
		{
			var uri = IconUri(name + (ext != null ? ext : String.Empty));
			return new Bitmap(uri);
		}

		public static byte[] GetResource(string resourceName, Assembly assembly = null)
		{
			using (var input = GetResourceStream(resourceName, assembly))
			{
				var buffer = new byte[input.Length];
				using (var output = new MemoryStream(buffer)) {
					input.CopyTo(output);
				}
				return buffer;
			}
		}

		public static Stream GetResourceStream(string resourceName, Assembly assembly = null)
		{
			if (assembly == null) {
				assembly = ApplicationAssembly;
			}
			return assembly.GetManifestResourceStream(resourceName);
		}

		//public static MemoryStream GetResourceAsMemoryStream(Assembly assembly, string resourceName)
		//{
		//	using (var input = GetResourceStream(resourceName, assembly))
		//	{
		//		var stream = new MemoryStream();
		//		input.CopyTo(stream);
		//		stream.Position = 0;
		//		return stream;
		//	}
		//}

		public static string ApplicationLanguage {
			get { return ApplicationLanguages.Languages[0]; }
			set { ApplicationLanguages.PrimaryLanguageOverride = value; }
		}

		public static string ManifestLanguage {
			get { return ApplicationLanguages.ManifestLanguages[0]; }
		}

		public static string GetLanguageNativeName(string tag)
		{
			if (Language.IsWellFormed(tag)) {
				var language = new Language(tag);
				return language.NativeName;
			} else {
				return null;
			}
		}
	}
}
