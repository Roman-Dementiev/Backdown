﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Collections
{
	/// <summary>
	/// Generic class LinkedQueue
	/// </summary>
	public class LinkedQueue<TLinked> : LinkedCollection<TLinked>
		where TLinked : class, ILinked<TLinked>
	{
		#region Fields
		private TLinked last = null;
		#endregion

		#region Constructors
		public LinkedQueue(TLinked node = null) :
			base(node)
		{
			last = node;
		}
		#endregion

		#region Methods
		public override void Clear()
		{
			base.Clear();
			last = null;
		}

		public override void Add(TLinked node)
		{
			Enqueue(node);
		}

		public override bool Remove(TLinked node)
		{
			if (node == null) {
				throw new ArgumentNullException(nameof(node));
			}

			if (node == head) {
				base.Remove(node);
				return true;
			} else {
				return false;
			}
		}

		public void Enqueue(TLinked node)
		{
			if (node == null) {
				throw new ArgumentNullException(nameof(node));
			}

			if (last == null) {
				Debug.Assert(head == null);
				head = last = node;
			} else {
				last.Link = node;
			}
			node.Link = null;
		}

		public TLinked Dequeue()
		{
			TLinked node = head;
			if (node != null) {
				head = node.Link;
				node.Link = null;
			}
			return node;
		}
		#endregion

	}

	#region UnitLinkedQueue
	public sealed class UnitLinkedQueue : ClassUnit
	{
		private UnitLinkedQueue() : base(typeof(LinkedQueue<>), UnitCollections._) { }
		public static readonly UnitLinkedQueue _ = new UnitLinkedQueue();
		public static UnitLinkedQueue Instance => _;
	}
	#endregion
}
