﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UWT
{
	public class SampleCategory
	{
		public string Name { get; set; }
//		public Sample[] Samples { get; set; }
		public string Icon { get; set; }
	}
}
