﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Dwarf.ObjectModel;


namespace Dwarf.Platform
{
	public enum SelectChoice
	{
		None,
		First,
		Last
	}

	public class Choices<TItem> : ObservableCollection<IChoice>, IChoices where TItem : class
	{
		protected int currentIndex = -1;
		protected IChoice currentChoice = null;
		protected TItem current = null;

		public event CurrentChoiceChangedHandler CurrentChoiceChanged;

		protected Choices() {}

		public Choices(IEnumerable<TItem> items, SelectChoice select = SelectChoice.First)
		{
			AddItems(items);
			Select(select);
		}

		protected void AddItems(IEnumerable<TItem> items)
		{
			if (items == null)
				return;

			foreach (var item in items) {
				AddItem(item);
			}
		}

		public void Select(SelectChoice select)
		{
			currentIndex = -1;
			currentChoice = null;
			current = null;

			switch (select)
			{
			case SelectChoice.First:
				if (Count > 0) {
					currentIndex = 0;
				}
				break;

			case SelectChoice.Last:
				if (Count > 0) {
					currentIndex = Count - 1;
				}
				break;
			}

			if (currentIndex >= 0) {
				currentChoice = this[currentIndex];
				current = ChoiceSource(currentChoice);
			}
		}

		public int IndexOf(TItem item)
		{
			for (int index = 0; index < Count; index++) {
				if (ChoiceSource(this[index]) == item)
					return index;
			}
			return -1;
		}

		public bool Contains(TItem item)
		{
			for (int i = 0; i < Count; i++) {
				if (ChoiceSource(this[i]) == item) {
					return true;
				}
			}
			return false;
		}

		public bool Contains(TItem item, out IChoice choice, out int index)
		{
			for (int i = 0; i < Count; i++) {
				if (ChoiceSource(this[i]) == item) {
					choice = this[i];
					index = i;
					return true;
				}
			}
			choice = null;
			index = -1;
			return false;
		}

		public virtual int AddItem(TItem item)
		{
			int index = Count;
			var choice = Adapt(item);
			Add(choice);
			return index;
		}

		public int CurrentIndex {
			get => currentIndex;
			set {
				if (value != currentIndex && value >= 0 && value < Count) {
					currentIndex = value;
					currentChoice = this[value];
					current = ChoiceSource(currentChoice);
					CurrentChoiceChanged?.Invoke(this);
				}
				else if (currentChoice != null) {
					currentIndex = -1;
					currentChoice = null;
					current = null;
					CurrentChoiceChanged?.Invoke(this);
				}
			}
		}

		public IChoice CurrentChoice {
			get => currentChoice;
			set {
				if (value != currentChoice) {
					currentChoice = value;
					currentIndex = IndexOf(value);
					current = ChoiceSource(value);
					CurrentChoiceChanged?.Invoke(this);
				}
			}
		}

		public TItem Current {
			get => current;
			set {
				if (value != current) {
					SetCurrent(value, false);
				}
			}
		}

		public virtual TItem SetCurrent(TItem item, bool add)
		{
			if (Contains(item, out currentChoice, out currentIndex)) {
				current = ChoiceSource(currentChoice);
			} else {
				if (add) {
					currentIndex = AddItem(item);
					currentChoice = this[currentIndex];
				} else {
					currentIndex = -1;
					currentChoice = Adapt(item);
				}
				current = item;
			}

			RaiseCurrentChoiceChanged();
			return current;
		}

		protected void RaiseCurrentChoiceChanged()
		{
			CurrentChoiceChanged?.Invoke(this);
		}

		public virtual TItem ChoiceSource(IChoice choice)
		{
			if (choice is TItem self) {
				return self;
			} else if (choice is ISourced<TItem> adapter) {
				return adapter.Source;
			} else {
				return null;
			}
		}

		public virtual IChoice Adapt(TItem item)
		{
			if (item is IChoice choice) {
				return choice;
			} else {
				return CreateAdapter(item);
			}
		}

		protected virtual IChoice CreateAdapter(TItem item)
		{
			return new ChoiceAdapter<TItem>(item);
		}

		IChoice IReadOnlyList<IChoice>.this[int index] => base[index];
		IEnumerator<IChoice> IEnumerable<IChoice>.GetEnumerator() => base.GetEnumerator();
	}
}
