﻿using System;
using System.IO;
using Dwarf.Logging;
using Dwarf.Utility;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing
{
	/// <summary>
	/// Class LALRParser
	/// </summary>
	public class LALRParser : Parser
	{
		const int cDefaultStackSize = 256;

		#region Events
		public delegate void TokenReadEventHandler(LALRParser parser, int sym, object obj);
		public delegate void ShiftEventHandler(LALRParser parser, int sym);
		public delegate void ReduceEventHandler(LALRParser parser, int sym, uint rule, bool trimmed);

		public event TokenReadEventHandler OnTokenRead;
		public event ShiftEventHandler OnShift;
		public event ReduceEventHandler OnReduce;
		protected bool HasOnShiftOrReduce => OnShift != null || OnReduce != null;
		private LogLevel logEvents = LogLevel.None;

		public LogLevel LogEvents {
			get { return logEvents; }
			set {
				if (value == logEvents)
					return;
				if (logEvents != LogLevel.None) {
					OnTokenRead -= LogTokenRead;
					OnShift -= LogShift;
					OnReduce -= LogReduce;
				}
				if (value != LogLevel.None) {
					OnTokenRead += LogTokenRead;
					OnShift += LogShift;
					OnReduce += LogReduce;
				}
				logEvents = value;
			}
		}
		#endregion

		#region Fields
		protected ILexer lexer = null;
		protected Symbols symbols = null;
		protected IRules rules = null;
		protected ILalrStates states;
		protected uint initialState = 0;
		protected uint currentState = 0;
		protected Token lookahead = null;
		protected int stackSize = cDefaultStackSize;
		protected Token[]  tokenStack = null;
		protected int tokenStackTop = -1;
		protected uint[] stateStack = null;
		protected int stateStackTop = -1;
		protected ITokenFactory tokenFactory = null;
		protected TerminalFactory terminalFactory = Parsing.TokenFactory.@null;
		protected NonterminalFactory nonterminalFactory = Parsing.TokenFactory.@null;
		protected bool continueParsing;
		#endregion

		#region Properties
		public ILexer Lexer => lexer;
		public Symbols Symbols => symbols;
		public IRules Rules => rules;
		public ILalrStates States => states;
		public uint InitialState => initialState;
		public bool TrimReductions { get; set; } = false;
		public int StackSize {
			get { return stackSize; }
			set {
			//	Debug.Assert(!continueParsing);
				stackSize = value > 0 ? value : cDefaultStackSize;
				if (tokenStack != null && stackSize > tokenStack.Length) {
					Array.Resize(ref tokenStack, stackSize);
				}
				if (stateStack != null && stackSize > stateStack.Length) {
					Array.Resize(ref stateStack, stackSize);
				}
			}
		}

		public TerminalFactory TerminalFactory {
			get { return terminalFactory; }
			set { terminalFactory = value ?? Parsing.TokenFactory.@null; }
		}

		public NonterminalFactory NonterminalFactory {
			get { return nonterminalFactory; }
			set { nonterminalFactory = value ?? Parsing.TokenFactory.@null; }
		}

		public ITokenFactory Factory {
			get { return tokenFactory; }
			set {
				tokenFactory = value;
				if (value != null) {
					terminalFactory = value.CreateTerminal;
					nonterminalFactory = value.CreateNonterminal;
				} else {
					terminalFactory = Parsing.TokenFactory.@null;
					nonterminalFactory = Parsing.TokenFactory.@null;
				}
			}
		}
		#endregion

		#region Constructors
		protected LALRParser() { }

		public LALRParser(Symbols symbols, ILexer lexer, IRules rules, ILalrStates states, uint initialState)
		{
			Init(symbols, lexer, rules, states, initialState);
		}

		protected void Init(Symbols symbols, ILexer lexer, IRules rules, ILalrStates states, uint initialState)
		{
			this.lexer = lexer;
			this.symbols = symbols;
			this.rules = rules;
			this.states = states;
			this.initialState = initialState;
			this.currentState = initialState;
		}
		#endregion

		#region Methods
		protected Token GetLookahead()
		{
			if (lookahead == null)
			{
				int sym;
				object obj = null;
				lookahead = new Token();
				lookahead.Position = lexer.Position;
				do {
					int start, length;
					sym = lexer.LookaheadToken(out start, out length);
					if (sym == Symbols.cEOF)
						break;

					if (sym == Symbols.cError) {
						obj = lexer.Error;
						Error(lexer.Error);
						break;
					}

					obj = terminalFactory(sym, lexer.Buffer, start, length);
					if (OnTokenRead != null) {
						var text = new string(lexer.Buffer, start, length);
						OnTokenRead(this, sym, text);
					}
				}
				while (symbols.IsNoise(sym));

				lookahead.Symbol = sym;
				lookahead.Object = obj;
				lexer.ConsumeLookahead();
			}

			return lookahead;
		}

		public int FindAction(uint state, int sym)
		{
			int count = states.ActionCount(state);
			for (uint action = 0; action < count; action++) {
				if (states.ActionSymbol(state, action) == sym)
					return (int)action;
			}
			return -1;
		}

		protected void SyntaxError()
		{
			int count = states.ActionCount(currentState);
			string[] expected = new string[count];
			for (uint i = 0;  i < count; i++) {
				int sym = states.ActionSymbol(currentState, i);
				expected[i] = symbols.GetName(sym);
			}
			Error(new SyntaxError(UnitLALRParser._, expected));
		}

		protected override void Error(DwarfException exc)
		{
			base.Error(exc);
			continueParsing = false;
		}

		/// <summary>
		/// Validates input from the specified reader.
		/// </summary>
		/// <param name="reader">The reader.</param>
		/// <returns><c>true</c> if input is valid; otherwise <c>false</c></returns>
		public override bool Validate(TextReader reader)
		{
			TerminalFactory terminalFactory = this.terminalFactory;
			NonterminalFactory nonterminalFactory = this.nonterminalFactory;
			this.terminalFactory = Parsing.TokenFactory.@null;
			this.nonterminalFactory = Parsing.TokenFactory.@null;
			try {
				Parse(reader);
				return Accepted;
			} finally {
				this.terminalFactory = terminalFactory;
				this.nonterminalFactory = nonterminalFactory;
			}
		}

		public override void Prepare(TextReader source)
		{
			if (lexer == null || symbols == null || states == null || rules == null) {
				Error(new ParserInitializationError(UnitLALRParser._));
				return;
			}

			base.Prepare(source);
			lexer.Prepare(source);
			lookahead = null;
			if (tokenStack == null) {
				tokenStack = new Token[StackSize];
			}
			if (stateStack == null) {
				stateStack = new uint[StackSize];
			}
			tokenStackTop = -1;
			stateStackTop = 0;
			stateStack[0] = initialState;
			continueParsing = true;
		}

		public override object Process()
		{
			while (continueParsing)
			{
				Token token = GetLookahead();
				if (!continueParsing)
					break;

				currentState = PeekState();
				int actionIndex = FindAction(currentState, lookahead.Symbol);
				if (actionIndex < 0) {
					SyntaxError();
					return null;
				}

				uint action = states.ActionType(currentState, (uint)actionIndex);
				uint target = states.ActionTarget(currentState, (uint)actionIndex);

				if (action == states.AcceptAction) {
					Accept(PeekToken().Object);
					continueParsing = false;
				}
				else if (action == states.ShiftAction) {
					Shift(target);
				} 
				else if (action == states.ReduceAction) {
					Reduce(target);
				}
				else {
					Error(new InvalidParserTable(UnitLALRParser._, currentState, lookahead.Symbol, (int)action));
					break;
				}
			}

			return Result;
		}

		protected void Shift(uint state)
		{
			PushState(state);
			PushToken(lookahead);
			lookahead = null;
		}

		protected void Reduce(uint rule)
		{
			int sym = rules.GetHeadSymbol(rule);
			Debug.Assert(symbols.IsNonterminal(sym));

			Token token;
			int length = rules.GetRuleLength(rule);
			if (TrimReductions && length == 1) {
				token = PeekToken();
				token.Symbol = sym;
				PopStates(1);
				OnReduce?.Invoke(this, sym, rule, true);
			} else {
				int start = tokenStackTop + 1 - length;
				Debug.Assert(start >= 0);
				object obj = nonterminalFactory(rule, tokenStack, start, length);
				token = new Token(sym, obj);
				if (length > 0) {
					token.Position = tokenStack[start].Position;
				} else {
					token.Position = TextPosition.None;
				}
				PopStates(length);
				PopTokens(length);
				PushToken(token);
				OnReduce?.Invoke(this, sym, rule, false);
			}

			currentState = PeekState();

			// Goto
			int action = FindAction(currentState, sym);
			if (action < 0) {
				Error(new InvalidParserTable(UnitLALRParser._, currentState, sym));
				return;
			}
			uint actionType = states.ActionType(currentState, (uint)action);
			if (actionType != states.GotoAction) {
				Error(new InvalidParserTable(UnitLALRParser._, currentState, sym, (int)actionType));
				return;
			}

			uint target = states.ActionTarget(currentState, (uint)action);
			PushState(target);
		}

		protected uint PeekState()
		{
			Debug.Assert(stateStackTop >= 0);
			return stateStack[stateStackTop];
		}

		protected void PushState(uint state)
		{
			stateStackTop++;
			if (stateStackTop == stateStack.Length - 1) {
				Array.Resize(ref stateStack, stateStack.Length + stackSize);
			}
			stateStack[stateStackTop] = state;
		}

		protected void PopStates(int count)
		{
			Debug.Assert(count <= stateStackTop + 1);
			stateStackTop -= count;
		}

		protected Token PeekToken()
		{
			Debug.Assert(tokenStackTop >= 0);
			return tokenStack[tokenStackTop];
		}

		protected void PushToken(Token token)
		{
			tokenStackTop++;
			if (tokenStackTop == tokenStack.Length - 1) {
				Array.Resize(ref tokenStack, tokenStack.Length + stackSize);
			}
			tokenStack[tokenStackTop] = token;
		}

		protected void PopTokens(int count)
		{
			Debug.Assert(count <= tokenStackTop + 1);
			tokenStackTop -= count;
		}

		#endregion

		public static void LogTokenRead(LALRParser parser, int sym, object obj)
		{
			string text;
			if (obj != null) {
				text = obj.ToString().ToPrintable();
			} else {
				text = "null";
			}
			Log.Write(parser.LogEvents, UnitLALRParser._, "Token Read: {0} = \"{1}\"",
						parser.symbols.GetName(sym), text);
		}

		public static void LogShift(LALRParser parser, int sym)
			=> Log.Write(parser.LogEvents, UnitLALRParser._, "Shift {0}", parser.symbols.GetName(sym));

		public static void LogReduce(LALRParser parser, int sym, uint rule, bool trimmed)
			=> Log.Write(parser.LogEvents, UnitLALRParser._, "Reduce rule {0} => {1}", 
				rule, parser.symbols.GetName(sym));

	}

	#region UnitLALRParser
	public sealed class UnitLALRParser : ClassUnit
	{
		private UnitLALRParser() : base(typeof(LALRParser), UnitParsing._) { }
		public static readonly UnitLALRParser _ = new UnitLALRParser();
		public static UnitLALRParser Instance => _;
	}
	#endregion
}
