﻿using System;
using Dwarf.Assets;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Config
{
	public class InvalidConfigValue : DwarfException
	{
		public InvalidConfigValue(Unit unit, string message, bool useAssets, Exception innerExc = null) :
			base(unit, message, useAssets,  innerExc)
		{ }

		public InvalidConfigValue(
				Dwarf.Unit unit,
				string key,
				object value,
				Type expectedType,
				Exception innerExc=null
			) :
			base(unit, innerExc, true, Messages.InvalidConfigValue,
				key, value.ToString(), expectedType)
		{ }
	}

	/// <summary>
	/// Default error message for exceptions
	/// </summary>
	public static class Messages
	{
		public const string InvalidConfigValue = nameof(InvalidConfigValue); // key, value, expectedType
	}

	#region UnitConfig
	public sealed class UnitConfig : NamespaceUnit
	{
		private UnitConfig() : base("Config", UnitDwarf._)
		{
#if INIT_DEFAULT_MESSAGES
			AssetMgr.SetDefaultString(Messages.InvalidConfigValue, "Invalid configuration value: {0}=\"{1}\"; expected {2}"); // key, value, expectedType
#endif
		}
		public static readonly UnitConfig _ = new UnitConfig();
		public static UnitConfig Instance => _;
	}
	#endregion
}
