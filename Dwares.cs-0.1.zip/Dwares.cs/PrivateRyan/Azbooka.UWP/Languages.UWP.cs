﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Reflection;
using Windows.ApplicationModel.Resources;
using Dwarf.Platform;
using Dwarf.ObjectModel;
using Dwarf.Localization;

namespace Azbooka
{
	public partial class Languages : EntityCollection<Language>
	{
		public static Language InitUnknown()
		{
			return new Language(tagUnknown) {
				NativeName = nameUnknown,
				LocalizedName = nameUnknown,
				Icon = Appx.GetBitmap("Assets/Languages/--.Unknown.png")
			};
		}

		public static Languages InitAllKnown()
		{
			var languages = new AllKnownLanguages();
			return languages;
		}
	}

	class AllKnownLanguages : Languages, ILocalizable
	{
		public AllKnownLanguages()
		{
			LoadFromResources();
			Localizer.AddTarget(this);
		}

		void LoadFromResources()
		{
			var list = new List<Language>();
			Assembly assembly = Appx.ApplicationAssembly;
			var loader = ResourceLoader.GetForViewIndependentUse("Languages");
			foreach (var resourceName in assembly.GetManifestResourceNames()) {
				if (resourceName.StartsWith("Azbooka.Assets.Languages") && resourceName.EndsWith(".png")) {
					var parts = resourceName.Split('.');
					var tag = parts[3];
					var nativeName = (parts.Length == 6) ? parts[4] : Appx.GetLanguageNativeName(tag);
					var language = new Language(tag) {
						NativeName = nativeName,
						Icon = new Bitmap(resourceName, assembly)
					};
					list.Add(language);
				}
			}

			list.Sort((x, y) => x.Tag.CompareTo(y.Tag));
			Add(list);
		}

		public void Localize()
		{
			var loader = ResourceLoader.GetForViewIndependentUse("Languages");
			foreach (var language in this) {
				if (String.IsNullOrEmpty(language.Tag))
					continue;

				language.LocalizedName = loader.GetString(language.Tag);
			}
		}

	}
}
