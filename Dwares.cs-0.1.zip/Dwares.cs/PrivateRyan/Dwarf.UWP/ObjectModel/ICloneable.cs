﻿using System;


namespace Dwarf.ObjectModel
{
	public interface ICloneable
	{
		object Clone(bool deepCopy);
	}

	public interface ICloneable<TObject> : ICloneable
	{
		new TObject Clone(bool deepCopy);
		void CopyFrom(TObject obj, bool deepCopy);
	}
}
