﻿using System;
using System.Collections.Generic;
using System.Text;
using Dwarf;
using Dwarf.ObjectModel;

namespace Azbooka
{
	public class Translation : Entity, ICloneable<Translation>
	{
		public Translation()
		{
			Language = Languages.Unknown;
			Text = String.Empty;
		}

		public Translation(string uid, Language laguage, string text) :
			base(uid)
		{
			Language = laguage;
			Text = text ?? String.Empty;
		}

		public Translation(string uid, Translation translation, bool deepCopy) :
			base(uid)
		{
			CopyFrom(translation, deepCopy);
		}

		public bool IsEditable { get; set; }
		public Language Language { get; set; }
		public string Text { get; set; }

		object ICloneable.Clone(bool deepCopy) => new Translation(uid, this, deepCopy);
		public Translation Clone(bool deepCopy) => new Translation(uid, this, deepCopy);
		
		public void CopyFrom(Translation translation, bool deepCopy = false)
		{
			base.CopyFrom(translation);
			Language = translation.Language;
			Text = translation.Text;
		}
	}
}
