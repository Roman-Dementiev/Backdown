﻿using System;
using System.IO;
using Dwarf.Config;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Utility
{
	/// <summary>
	/// Generic class GTextProcessor
	/// </summary>
	public abstract class GTextProcessor<TResult> : Configurable, ITextProcessor<TResult>
	{
		#region Properties
		/// <summary>
		/// Gets the reader.
		/// </summary>
		/// <value>
		/// The source.
		/// </value>
		public TextReader Reader {
			get { return Source != null ? Source.Reader : null; }
		}

		/// <summary>
		/// Gets or sets the source.
		/// </summary>
		/// <value>
		/// The source.
		/// </value>
		public TextSource Source { get; protected set; } = null;

		/// <summary>
		/// Gets or sets the result.
		/// </summary>
		/// <value>
		/// The result.
		/// </value>
		public TResult Result { get; protected set; } = default(TResult);

		/// <summary>
		/// Gets the error exception.
		/// </summary>
		/// <value>
		/// The error.
		/// </value>
		public DwarfException ErrorOccured { get; protected set; } = null;

		/// <summary>
		/// Gets or sets a value indicating whether the <see cref="TryProcess"/> return <see cref="ErrorOccured"/>.
		/// </summary>
		/// <value>
		/// <c>true</c> if the TryProcess returns exceptions;
		/// <c>false</c> if it returns null in case of error.
		/// </value>
		public bool ReturnErrors { get; set; } = false;
		#endregion

		#region Events
		/// <summary>
		/// Fired when error occurs.
		/// </summary>
		public event ExceptionHandler OnError;
		#endregion

		#region Methods
		/// <summary>
		/// Prepare for processing input from the reader.
		/// </summary>
		/// <param name="reader"></param>
		public virtual void Prepare(TextReader reader)
		{
			Prepare(new TextSource(reader));
		}

		/// <summary>
		/// Prepare for processing input from the source.
		/// </summary>
		/// <param name="source">The source.</param>
		public virtual void Prepare(TextSource source)
		{
			Source = source;
			Result = default(TResult);
			ErrorOccured = null;
		}

		/// <summary>
		/// Processes the text input from the <see cref="Source" />.
		/// </summary>
		/// <returns>
		/// The result of processing
		/// </returns>
		public abstract TResult Process();

		/// <summary>
		/// Tries to prepare and process input from the source.
		/// </summary>
		/// <param name="source">The source.</param>
		/// <returns>
		/// <see cref="P:Dwarf.Utility.ITextProcessor`1.Result" /> if processed successfully;
		/// otherwise <see cref="!:ErrorOcuured" /> when <see cref="P:Dwarf.Utility.ITextProcessor`1.ReturnErrors" /> is <c>true</c> or <c>null</c> when <see cref="P:Dwarf.Utility.ITextProcessor`1.ReturnErrors" /> is false.
		/// </returns>
		public virtual object Try(TextReader source)
		{
			try {
				Prepare(source);
				Result = Process();
			}
			catch (Exception exc) {
				ErrorOccured = exc is DwarfException ? (DwarfException)exc : UnknownError(exc);
				ErrorOccured.Log();
				Result = default(TResult);
				return ReturnErrors ? ErrorOccured : null;
			}
			return Result;
		}

		protected virtual DwarfException UnknownError(Exception exc)
		{
			return DwarfException.Wrap(exc);
		}
		#endregion

		protected virtual void Error(DwarfException exc)
		{
			ErrorOccured = exc;
			OnError?.Invoke(this, exc);
		}

		protected virtual void Error(Exception exc)
		{
			DwarfException dwarfExc = exc as DwarfException;
			if (dwarfExc == null) {
				dwarfExc = UnknownError(exc);
			}
			Error(dwarfExc);
		}
	}

	public abstract class TextProcessor : GTextProcessor<object>
	{
		public TextProcessor() { }
	}

	#region UnitGTextProcessor
	public sealed class UnitGTextProcessor : ClassUnit
	{
		private UnitGTextProcessor() : base(typeof(GTextProcessor<>), UnitUtility._) { }
		public static readonly UnitGTextProcessor _ = new UnitGTextProcessor();
		public static UnitGTextProcessor Instance => _;
	}
	#endregion

	#region UnitTextProcessor
	public sealed class UnitTextProcessor<T> : ClassUnit
	{
		private UnitTextProcessor() : base(typeof(TextProcessor), UnitUtility._) { }
		public static readonly UnitTextProcessor<T> _ = new UnitTextProcessor<T>();
	}
	#endregion
}
