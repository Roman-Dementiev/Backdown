﻿#define BITMAP_STRUCT
//#define BITMAP_WEAK_REFERENCE
using System;
using System.IO;
using System.Reflection;
using Windows.UI.Xaml.Media.Imaging;
using Dwarf.Extensions;
using Dwarf.ObjectModel;

namespace Dwarf.Platform
{
#if BITMAP_STRUCT
	public struct Bitmap
#else
	public class Bitmap
#endif
	{
		IBitmapLoader loader;
	#if BITMAP_WEAK_REFERENCE
		WeakReference<BitmapImage> image;
	#else
		BitmapImage image;
	#endif

		Bitmap(IBitmapLoader loader, BitmapImage image)
		{
			this.loader = loader;
	#if BITMAP_WEAK_REFERENCE
			this.image = new WeakReference<BitmapImage>(image);
	#else
			this.image = image;
	#endif
		}

		public Bitmap(BitmapImage image = null) : 
			this(null, image)
		{ }

		public Bitmap(IBitmapLoader loader) : 
			this(loader ?? throw new ArgumentNullException(nameof(loader)), null)
		{ }

		public Bitmap(Uri uri) : 
			this(new BitmapUriSource(uri), null)
		{ }

		public Bitmap(string resourceName, Assembly assemnbly = null) :
			this(new BitmapResource(resourceName, assemnbly), null)
		{ }

		public Bitmap(Stream input, bool keepData = false) :  this()
		{
			LoadFromStream(input, keepData);
		}

		public Bitmap(byte[] buffer, bool keepData=false) : this()
		{
			LoadFromBuffer(buffer);
		}

		public IBitmapLoader Loader {
			get => loader;
			set {
				if (value != loader) {
					loader = value;
			#if BITMAP_WEAK_REFERENCE
					image.SetrTarget(null);
			#else
					image = null;
			#endif
				}
			}
		}

		public BitmapImage BitmapImage {
			get {
				if (image == null && loader != null) {
					image = loader.LoadBitmapImage();
				}
				return image;
			}
			set {
				if (value != image) {
					loader = null;
					image = value;
				}
			}
		}

		public byte[] BitmapData {
			get {
				if (loader != null && loader.CanLoadData()) {
					return loader.LoadBitmapData();
				} else {
					return null;
				}
			}
			set {
				if (value != null) {
					Loader = new BitmapBuffer(value);
				} else {
					Loader = null;
				}
			}
		}


		public void SetNull()
		{
			loader = null;
			image = null;
		}

#if BITMAP_STRUCT
		public static Bitmap Null = new Bitmap();
		public static bool IsNull(Bitmap bitmap) => (bitmap.image == null && bitmap.loader == null);

		public static implicit operator BitmapImage(Bitmap bitmap)
		{
			return bitmap.BitmapImage;
		}

#else
		public static Bitmap Null = null;
		public static bool IsNull(Bitmap bitmap) => (bitmap == null) || (bitmap.image == null && bitmap.loader == null);

		public static implicit operator BitmapImage(Bitmap bitmap)
		{
			return bitmap?.BitmapImage;
		}

#endif

		//public static implicit operator byte[] (Bitmap bitmap)
		//{
		//	return bitmap.GetData();
		//}

		//public static implicit operator Bitmap(byte[] buffer)
		//{
		//	return new Bitmap(buffer);
		//}

		public void LoadFromStream(Stream input, bool keepData=false)
		{
			loader = null;
			if (input == null) {
				image = null;
				return;
			}

			if (keepData) {
				var buffer = input.LoadToMemory();
				loader = new BitmapBuffer(buffer);
				image = loader.LoadBitmapImage();
			} else {
				image = new BitmapImage();
				image.LoadFromStream(input);
			}
		}

		public void LoadFromBuffer(byte[] buffer, bool keepData = false)
		{
			loader = null;
			if (buffer == null) {
				image = null;
				return;
			}

			if (keepData) {
				loader = new BitmapBuffer(buffer);
				image = loader.LoadBitmapImage();
			} else {
				image = new BitmapImage();
				image.LoadFromBuffer(buffer);
			}
		}

		public void LoadFromResource(string resourceName, Assembly assemnbly = null, bool keepData=false)
		{
			if (keepData) {
				var buffer = Appx.GetResource(resourceName, assemnbly);
				loader = new BitmapBuffer(buffer);
			} else {
				loader = new BitmapResource(resourceName, assemnbly);
			}

			image = loader.LoadBitmapImage();
		}
	}


	public struct BitmapPropertyValue
	{
	#if BITMAP_STRUCT
		ScalarPropertyValue<Bitmap> bitmapValue;
	#else
		PropertyValue<Bitmap> bitmapValue;
	#endif

		public BitmapPropertyValue(Bitmap bitmap)
		{
		#if BITMAP_STRUCT
			bitmapValue = new ScalarPropertyValue<Bitmap>(bitmap);
		#else
			bitmapValue = new PropertyValue<Bitmap>(bitmap);
		#endif
		}

		public Type PropertyType => typeof(Bitmap);
		public Bitmap Value {
			get => bitmapValue;
			set => Set(value);
		}

		public void Set(Bitmap bitmap, PropertyValueChanging<Bitmap> onValueChanging = null) => bitmapValue.Set(bitmap, onValueChanging);
		public void Set(Bitmap bitmap, Action onValueChanging) => bitmapValue.Set(bitmap, onValueChanging);
		public void Set(Bitmap bitmap, Action<Bitmap> onValueChanging) => bitmapValue.Set(bitmap, onValueChanging);
		public static implicit operator Bitmap(BitmapPropertyValue propertyValue) => propertyValue.Value;
	}
}
