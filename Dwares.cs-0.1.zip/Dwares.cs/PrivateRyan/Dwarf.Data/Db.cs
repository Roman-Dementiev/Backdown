﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Threading;


namespace Dwarf.Data
{
	public enum IdentityType {
		Global,
		Scope,
		Table
	};

	public class Db<TConnection, TCommand, TQuery> : IDb, IDisposable
		where TCommand : class, IDbCommand, new()
		where TConnection : class, IDbConnection, new()
		where TQuery : Query, new()
	{
		public Db(string connectionString, string filename, bool open=false)
		{
			ConnectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
			FileName = filename;
			if (open) {
				Open();
			}
		}

		public string ConnectionString { get; }
		public string FileName { get; }
		public bool AutoOpen { get; set; } = true;

		public IDbManifest Manifest { get; private set; }
		public Version Version => Manifest?.Version;
		public string ContentType => Manifest?.ContentType;
		public string ContentName => Manifest?.ContentName;
		public IEnumerable<string> Tables => Manifest?.Tables;
		public string GetSchema(string table) => Manifest?.GetSchema(table);

		public TConnection Connection {
			get {
				if (connection == null && AutoOpen) {
					Open();
				}
				return connection;
			}
		}
		TConnection connection = null;

		IDbConnection IDb.Connection => connection;
		public bool IsOpen => connection != null;

		public void InitFromManifest(IDbManifest manifest, string dropCmd = null)
		{
			Open(dropCmd);
			Manifest = manifest ?? throw new ArgumentNullException(nameof(manifest));
			manifest.InitDb(this);
		}

		public void OpenWithManifest(string manifestTable)
		{
			Open();
			if (Manifest == null || Manifest.ManifestTable != manifestTable) {
				Manifest = new DbManifest(this, manifestTable);
			}
		}

		public void Open(string initCmd = null)
		{
			if (connection == null)
			{
				connection = new TConnection();
				connection.ConnectionString = ConnectionString;
				connection.Open();

				if (initCmd != null) {
					ExecuteCommand(initCmd);
				}
			}
		}

		public void Close()
		{
			if (connection != null) {
				connection.Close();
				connection.Dispose();
				connection = null;
			}
		}

		public void Dispose()
		{
			Close();
		}

		IDbCommand IDb.Command(string commandText) => Command(commandText);

		public virtual TCommand Command()
		{
			var command = new TCommand();
			command.Connection = Connection;
			return command;
		}

		public TCommand Command(string commandText)
		{
			var command = Command();
			if (commandText != null) {
				command.CommandText = commandText;
			}
			return command;
		}

		public TCommand Command(string format, params object[] args)
		{
			var command = Command();
			command.CommandText = String.Format(format, args);
			return command;
		}

		public void ExecuteCommand(string commandText)
		{
			using (var command = Command(commandText)) {
				command.ExecuteNonQuery();
			}
		}

		public void ExecuteCommand(string format, params object[] args)
		{
			using (var command = Command(format, args)) {
				command.ExecuteNonQuery();
			}
		}

		Query IDb.ExecuteQuery(string commandText) => ExecuteQuery(commandText);

		public TQuery ExecuteQuery(IDbCommand command)
		{
			var query = new TQuery();
			query.Execute(command);
			return query;
		}

		public virtual TQuery ExecuteQuery(string commandText)
			=> ExecuteQuery(Command(commandText));

		public virtual TQuery ExecuteQuery(string format, params object[] args)
			=> ExecuteQuery(Command(format, args));

		public virtual bool IdentitySpupported(IdentityType type) => false;

		public virtual object GetIdentity(IdentityType type = IdentityType.Global, string table = null)
		{
			if (!IdentitySpupported(type))
				return false;

			string commandText;
			switch (type)
			{
				default:
			//	case IdentityType.Global:
					commandText = "SELECT @@IDENTITY";
					break;
				case IdentityType.Scope:
					commandText = "SELECT SCOPE_IDENTITY()";
					break;
				case IdentityType.Table:
					commandText = String.Format("SELECT IDENT_CURRENT({0})", 
						table ?? throw new ArgumentNullException(nameof(table)));
					break;
			}

			using (var command = Command(commandText)) {
				return command.ExecuteScalar();
			}
		}

	}
}
