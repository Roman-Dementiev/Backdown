﻿using System;
using System.Collections.Generic;
using Windows.System;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Dwarf.Platform;
using Dwarf.ObjectModel;


namespace Dwarf.UWP
{
	public class NavigationHelper : INavigationHelper
	{
		public Frame Frame { get; protected set; }
		public Page CurrentPage { get; protected set; }
		public List<INavigationHelper> Additional { get; protected set; }
		public virtual string SharedStateKey => "@shared";


//		public List<string> BackStackKeys = new List<string>();

		protected NavigationHelper() { }

		public NavigationHelper(Frame frame)
		{
			Frame = frame ?? throw new ArgumentNullException(nameof(frame));

			frame.Navigating += OnNavigating;
			frame.Navigated += OnNavigated;
		}

		public NavigationHelper(Frame frame, params INavigationHelper[] additional) :
			this(frame)
		{
			AddHelpers(additional);
		}

		public void Add(params INavigationHelper[] additional)
		{
			if (additional != null && additional.Length > 0) {
				AddHelpers(additional as IEnumerable<INavigationHelper>);
			}
		}
		
		public void AddHelpers(IEnumerable<INavigationHelper> additional)
		{
			if (Additional == null) {
				Additional = new List<INavigationHelper>(additional);
			} else {
				Additional.AddRange(additional);
			}
		}

		public RelayCommand GoBackCommand => RelayCommand.LazyInit(ref goBackCommand, GoBack, CanGoBack);
		RelayCommand goBackCommand;

		public RelayCommand GoForwardCommand => RelayCommand.LazyInit(ref goForwardCommand, GoForward, CanGoForward);
		RelayCommand goForwardCommand;

		public virtual bool CanGoBack()
		{
			return Frame != null && Frame.CanGoBack;
		}

		public virtual bool CanGoForward()
		{
			return Frame != null && Frame.CanGoForward;
		}

		public virtual void GoBack()
		{
			if (CanGoBack())
				Frame.GoBack();
		}

		
		public virtual void GoForward()
		{
			if (CanGoForward()) 
				Frame.GoForward();
		}

		public virtual void OnNavigatedTo(Page page, NavigationEventArgs e)
		{
			if (page is IStateful stateful) {
				var frameState = SuspensionManager.SessionStateForFrame(this.Frame);
				var pageState = frameState.Get<StateDict>(stateful.StateKey);
				var sharedState = frameState.Get<StateDict>(SharedStateKey);

				stateful.LoadState(pageState, sharedState, e.Parameter);
			}

			if (Additional != null) {
				foreach (var helper in Additional) {
					helper.OnNavigatedTo(page, e);
				}
			}

			GoBackCommand.RaiseCanExecuteChanged();
			GoForwardCommand.RaiseCanExecuteChanged();
		}

		public virtual void OnNavigatedFrom(Page page, NavigationEventArgs e)
		{

			var stateful = page as IStateful;
			if (stateful != null)
			{
				var frameState = SuspensionManager.SessionStateForFrame(Frame);
				var pageState = frameState.Get<StateDict>(stateful.StateKey);
				var sharedState = frameState.Get<StateDict>(SharedStateKey);

				stateful.SaveState(ref pageState, ref sharedState, e.Parameter);
				if (pageState != null) {
					frameState[stateful.StateKey] = pageState;
				}
				if (sharedState != null) {
					frameState[SharedStateKey] = sharedState;
				}
			}

			if (Additional != null) {
				foreach (var helper in Additional) {
					helper.OnNavigatedFrom(page, e);
				}
			}

			GoBackCommand.RaiseCanExecuteChanged();
			GoForwardCommand.RaiseCanExecuteChanged();
		}

		public virtual void OnNavigatingFrom(Page page, NavigatingCancelEventArgs e)
		{
			if (Additional != null) {
				foreach (var helper in Additional) {
					helper.OnNavigatingFrom(page, e);
					if (e.Cancel)
						return;
				}
			}
		}


		private void OnNavigating(object sender, NavigatingCancelEventArgs e)
		{
			if (CurrentPage != null) {
				OnNavigatingFrom(CurrentPage, e);
				if (e.Cancel)
					return;
			}
		}

		private void OnNavigated(object sender, NavigationEventArgs e)
		{
			if (CurrentPage != null) {
				OnNavigatedFrom(CurrentPage, e);
			}

			CurrentPage = e.Content as Page;

			if (CurrentPage != null) {
				OnNavigatedTo(CurrentPage, e);
			}
		}
	}
}
