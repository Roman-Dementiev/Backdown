﻿using System;
using Windows.Globalization;
using Dwarf.Platform;


namespace Azbooka
{
	public partial class UILanguages : Languages
	{
		//public static Language Default => Instance.defaultLanguage;
		//Language defaultLanguage;
		
		public int CurrentIndex {
			get { return currentIndex; }
			set {
				if (value != currentIndex && value >= 0 && value < Count) {
					currentIndex = value;
					currentLanguage = this[value];
					Appx.ApplicationLanguage = currentLanguage.Tag;
				}
			}
		}
		int currentIndex;


		public UILanguages()
		{
			//defaultLanguage = new Language(String.Empty) {
			//	NativeName = "Default",
			//	LocalizedName = Appx.GetString("DefaultLanguage", null)
			//};
			//Add(defaultLanguage);

			currentIndex = -1;
			currentLanguage = null;

			string appLanguage = Appx.ApplicationLanguage;
			foreach (var languageTag in ApplicationLanguages.ManifestLanguages)
			{
				var split = languageTag.Split('-');
				var tag = (split.Length > 0) ? split[0] : languageTag;

				var language = GetKnown(tag);
				if (language == null) {
					language = new Language(tag);
					if (Windows.Globalization.Language.IsWellFormed(tag)) {
						var lang = new Windows.Globalization.Language(tag);
						language.NativeName = lang.NativeName;
						language.LocalizedName = lang.DisplayName;
					} else {
						language.CopyFrom(Unknown);
					}
					Languages.AddToKnown(language);
				}
				if (tag == appLanguage || languageTag == appLanguage) {
					currentIndex = Count;
					currentLanguage = language;
				}
				Add(language);
			}

			if (currentLanguage == null) {
				currentIndex = 0;
				currentLanguage = this[0];
			}
		}
	}
}
