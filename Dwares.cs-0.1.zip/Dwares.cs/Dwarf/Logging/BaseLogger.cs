﻿using System;

namespace Dwarf.Logging
{
	/// <summary>
	/// Abstract class BaseLogger
	/// </summary>
	public abstract class BaseLogger : ILogger
	{
		#region Constructor
		/// <summary>
		/// Initializes a new instance of the <see cref="BaseLogger"/> class.
		/// </summary>
		/// <param name="backLogger">The back logger.</param>
		/// <param name="formatter">The formatter.</param>
		public BaseLogger(ILogger backLogger=null, ILogFormatter formatter =null)
		{
			BackLogger = backLogger;
			Formatter = formatter;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="BaseLogger"/> class.
		/// </summary>
		/// <param name="formatter">The formatter.</param>
		public BaseLogger(ILogFormatter formatter) :
			this(null, formatter)
		{}
		#endregion

		#region Properties
		/// <summary>
		/// Gets or sets the back logger.
		/// </summary>
		/// <value>
		/// The back logger.
		/// </value>
		public ILogger BackLogger { get; set; }

		/// <summary>
		/// Gets or sets the log formatter for this instance.
		/// </summary>
		/// <value>
		/// The formatter.
		/// </value>
		public ILogFormatter Formatter { get; set; }

		/// <summary>
		/// Gets a value indicating whether this instance or one of back logger has its formatter.
		/// </summary>
		/// <value>
		///   <c>true</c> if there has formatter; otherwise, <c>false</c>.
		/// </value>
		public bool CustomFormat {
			get {
				if (Formatter != null) {
					return true;
				}
				if (BackLogger != null) {
					return BackLogger.CustomFormat;
				}
				return false;
			}
		}

		#endregion

		#region Methodss
		/// <summary>
		/// Writes log message from specified unit.
		/// </summary>
		/// <param name="level">Logging level.</param>
		/// <param name="source">The source.</param>
		/// <param name="message">The message.</param>
		/// <param name="args">The arguments.</param>
		/// <param name="formatted">if set to <c>true</c> message was formatted by <see cref="Log.DefaultFormatter" />.</param>
		public virtual void Write(LogLevel level, string source, string message, object[] args, bool formatted)
		{
			if (!formatted) {
				if (Formatter != null) {
					message = Formatter.Format(level, source, message, args);
				} else {
					message = Log.Formatter.Format(level, source, message, args);
				}
			}

			Write(message);

			if (BackLogger != null) {
				BackLogger.Write(level, source, message, args, formatted);
			}
		}

		/// <summary>
		/// Writes formatted log message from specified unit.
		/// </summary>
		/// <param name="message">The message.</param>
		public abstract void Write(string message);
		#endregion
	}

	#region UnitBaseLogger
	#pragma warning disable RCS1060, RCS1023
	public sealed class UnitBaseLogger : ClassUnit
	{
		private UnitBaseLogger() : base(typeof(BaseLogger), UnitLogging._) { }
		public static readonly UnitBaseLogger _ = new UnitBaseLogger();
		public static UnitBaseLogger Instance => _;
	}
	#endregion
}
