﻿using System;
using System.Collections.Generic;
using System.Linq;
using Windows.UI.Xaml;


namespace Dwarf.Platform
{
	public delegate void CurrentChoiceChangedHandler(IChoices sender);

	public enum ChoiceAppearance
	{
		Auto,
		ImageOnly,
		LabelOnly,
		ImageAndLabel
	}

	public interface IChoice
	{
		ICommand Command { get; set; }
		Bitmap ChoiceImage { get; }
		string ChoiceLabel { get; }
		Bitmap PopupImage { get; }
		string PopupLabel { get; }

		string ChoiceToolTip(ChoiceAppearance appearance);
	}

	public interface IChoices : IReadOnlyList<IChoice>
	{
		int CurrentIndex { get; set; }
		IChoice CurrentChoice { get; set; }

		event CurrentChoiceChangedHandler CurrentChoiceChanged;
	}

	public static partial class Extensions
	{
		public static bool HasChoiceImages(this IChoices choices) =>
				choices.FirstOrDefault((choice) => !Bitmap.IsNull(choice.ChoiceImage)) != null;

		public static bool HasChoiceLabels(this IChoices choices) =>
			choices.FirstOrDefault(choice => !String.IsNullOrEmpty(choice.ChoiceLabel)) != null;

		public static bool HasPopupLabels(this IChoices choices) =>
			choices.FirstOrDefault(choice => !String.IsNullOrEmpty(choice.PopupLabel)) != null;

		public static bool HasPopupImages(this IChoices choices) =>
			choices.FirstOrDefault(choice => !Bitmap.IsNull(choice.PopupImage)) != null;

		public static Visibility ChoiceImagesVisibility(this ChoiceAppearance appearance, IChoices choices)
		{
			if (choices == null)
				return Visibility.Collapsed;

			switch (appearance)
			{
			default:
				return choices.HasChoiceImages() ? Visibility.Visible : Visibility.Collapsed;

			case ChoiceAppearance.LabelOnly:
				return Visibility.Collapsed;

			case ChoiceAppearance.ImageOnly:
			case ChoiceAppearance.ImageAndLabel:
				return Visibility.Visible;
			}
		}

		public static Visibility ChoiceLabelsVisibility(this ChoiceAppearance appearance, IChoices choices)
		{
			if (choices == null)
				return Visibility.Collapsed;

			switch (appearance)
			{
			default:
				return choices.HasChoiceLabels() ? Visibility.Visible : Visibility.Collapsed;

			case ChoiceAppearance.ImageOnly:
				return Visibility.Collapsed;

			case ChoiceAppearance.LabelOnly:
			case ChoiceAppearance.ImageAndLabel:
				return Visibility.Visible;
			}
		}

		public static Visibility PopupImagesVisibility(this ChoiceAppearance appearance, IChoices choices)
		{
			if (choices == null)
				return Visibility.Collapsed;

			switch (appearance)
			{
			default:
				return choices.HasPopupLabels() ? Visibility.Visible : Visibility.Collapsed;

			case ChoiceAppearance.LabelOnly:
				return Visibility.Collapsed;

			case ChoiceAppearance.ImageOnly:
			case ChoiceAppearance.ImageAndLabel:
				return Visibility.Visible;
			}
		}

		public static Visibility FlyoutLabelsVisibility(this ChoiceAppearance appearance, IChoices choices)
		{
			if (choices == null)
				return Visibility.Collapsed;

			switch (appearance)
			{
			default:
				return choices.HasPopupImages() ? Visibility.Visible : Visibility.Collapsed;

			case ChoiceAppearance.ImageOnly:
				return Visibility.Collapsed;

			case ChoiceAppearance.LabelOnly:
			case ChoiceAppearance.ImageAndLabel:
				return Visibility.Visible;
			}
		}

		public static string DefaultChoiceTolTip(this ChoiceAppearance appearance, IChoice choice)
		{
			if (choice != null && appearance == ChoiceAppearance.ImageOnly) {
				return choice.ChoiceLabel;
			} else {
				return null;
			}
		}
	}
}
