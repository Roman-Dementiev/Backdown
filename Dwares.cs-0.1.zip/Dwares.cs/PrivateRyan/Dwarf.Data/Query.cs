﻿using System;
using System.Data;


namespace Dwarf.Data
{
	public class Query : IDisposable
	{
		IDbCommand command = null;
		IDataReader reader = null;

		public Query() { }

		public Query(IDataReader reader)
		{
			this.reader = reader ?? throw new ArgumentNullException(nameof(reader));
		}

		public Query(IDbCommand command, bool execute = true)
		{
			this.command = command ?? throw new ArgumentNullException(nameof(command));
			if (execute) {
				Execute();
			}
		}

		public IDbCommand Command => command;
		public IDataReader Reader => reader;

		public void Dispose()
		{
			if (reader != null) {
				reader.Dispose();
				reader = null;
			}
			if (command != null) {
				command.Dispose();
				command = null;
			}
		}

		public void Execute()
		{
			if (reader != null) {
				reader.Dispose();
				reader = null;
			}

			reader = command.ExecuteReader();
		}

		public void Execute(IDbCommand command)
		{
			if (command == null) throw new ArgumentNullException(nameof(command));

			if (command != this.command) {
				Dispose();
				this.command = command;
			}

			Execute();
		}

		public bool Read()
		{
			return reader.Read();
		}

		public object this[string key] {
			get { return reader[key]; }
		}

		public TValue? Nullable<TValue>(string key) where TValue : struct
		{
			return reader[key] as TValue?;
		}

		public TValue Get<TValue>(string key, TValue defaultValue = default(TValue))
		{
			var value = reader[key];
			if (value != null && value.GetType() != typeof(DBNull)) {
				return Convert.ConvertTo<TValue>(value);
			} else {
				return defaultValue;
			}
		}

		public byte[] Blob(string key) => Get<byte[]>(key);
		public string String(string key, string defaultValue = null) => Get(key, defaultValue);
		public bool Bool(string key, bool defaultValue = false) => Get(key, defaultValue);
		public long Long(string key, long defaultValue = -1) => Get(key, defaultValue);
		public int Int(string key, int defaultValue = -1) => Get(key, defaultValue);
		public int Short(string key, short defaultValue = -1) => Get(key, defaultValue);
		public byte Byte(string key, byte defaultValue = 0) => (byte)Short(key, defaultValue);
	}
}
