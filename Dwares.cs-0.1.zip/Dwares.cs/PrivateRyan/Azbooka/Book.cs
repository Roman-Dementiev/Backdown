﻿using System;
using Dwarf.Platform;
using Dwarf.Localization;


namespace Azbooka
{
	public enum BookType
	{
		Dictionary,
		Phrasebook,
		Thesaurus,
		Grammar,

		_Unknown
	}

	public class Book : ShelfEntity
	{
		static Bitmap DictionaryIcon = Appx.GetIcon("Dictionary");
		static Bitmap PhrasebookIcon  = Appx.GetIcon("Phrasebook");
		static Bitmap ThesaurusIcon = Appx.GetIcon("Thesaurus");
		static Bitmap GrammarIcon => Appx.GetIcon("Grammar");


		public Book(string uid, BookType type) :
			base(uid)
		{
			Type = type;
			Icon = DefaultIcon;
		}

		public BookType Type { get; }

		public new Bitmap Icon {
			get { return base.Icon; }
			set { base.Icon = Bitmap.IsNull(value) ? DefaultIcon : value; }
		}

		public Bitmap DefaultIcon {
			get {
				switch (Type)
				{
					case BookType.Dictionary:
						return DictionaryIcon;
					case BookType.Phrasebook:
						return PhrasebookIcon;
					case BookType.Thesaurus:
						return ThesaurusIcon;
					case BookType.Grammar:
						return GrammarIcon;
				}
				return new Bitmap();
			}
		}

		public string PrimaryLanguageTag { 
			get => primaryLanguage.Tag;
			set => primaryLanguage.Tag = value;
		}
		public Language PrimaryLanguage {
			get => primaryLanguage.Value;
			set => primaryLanguage.Value = value;
		}
		LanguageRef primaryLanguage = new LanguageRef();

		public static Book NewBook(string uid, int type)
		{
			if (type < 0 || type >= (int)BookType._Unknown)
				return null;

			if (uid.StartsWith("AZB:")) {
				return new MyBook((BookType)type, uid, uid.Substring(4));
			} else {
				return new Book(uid, (BookType)type);
			}
		}
	}

	public class MyBook : Book, ILocalizable
	{
		public MyBook(BookType type, string uid, string name, bool permanent = true) :
			base(uid, type)
		{
			IsSelected = true;
			Name = name;
			Localizer.AddTarget(this);

			if (permanent) {
				AddRef(null);
			}
		}

		public MyBook(BookType type, string name)  :
			this(type, String.Format("AZB:{0}", name), name)
		{}

		public void Localize()
		{
			LocalizedName = Appx.GetString(name);
		}
	}
}
