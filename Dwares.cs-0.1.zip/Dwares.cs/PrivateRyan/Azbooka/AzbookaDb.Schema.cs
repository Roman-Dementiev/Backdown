﻿using System;
using System.Collections.Generic;
using Dwarf.Collections;

namespace Azbooka
{
	public partial class AzbookaDb
	{
#if true && DEBUG
		const string DebugDropOnStart = DropAll;
#else
		const string DebugDropOnStart = null;
#endif

		internal static class Table {
			public const string Manifest = "[Manifest]";
			public const string Languages = "[Languages]";
			public const string Topics = "[Topics]";
			public const string PoS = "[PoS]";
			public const string Books = "[Books]";
			public const string Volumes = "[Volumes]";
			public const string Words = "[Words]";
			public const string Meanings = "[Meanings]";
			public const string Translations = "[Translations]";
			//		public const string TableMetadata = "[Metadata]";
		}

		internal static class Field {
			public const string Id = nameof(Id);
			public const string Key = nameof(Key);
			public const string Uid = nameof(Uid);
			public const string Tag = nameof(Tag);
			public const string Type = nameof(Type);
			public const string Name = nameof(Name);
			public const string Icon = nameof(Icon);
			public const string Active = nameof(Active);
			public const string LanguageTag= nameof(LanguageTag);
			public const string PrimaryLanguageTag = nameof(PrimaryLanguageTag);
			public const string SecondaryLanguageTag= nameof(SecondaryLanguageTag);
			public const string WordId = nameof(WordId);
			public const string Abbr = nameof(Abbr);
			public const string Text = nameof(Text);
			public const string PoS = nameof(PoS);
		}


		static Vocabulary<string> Schemas = new Vocabulary<string>() {
{ Table.Manifest,
@"CREATE TABLE IF NOT EXISTS [Manifest] (
  [Id] INTEGER NOT NULL,
  [Type] TEXT NOT NULL,
  [Name] TEXT NOT NULL,
  [Value] TEXT,
  CONSTRAINT [PK_Languages] PRIMARY KEY ([Id])
);
"},
{ Table.PoS,
@"CREATE TABLE IF NOT EXISTS [PoS] (
  [Uid] TEXT UNIQUE NOT NULL,
  [Abbr] TEXT NOT NULL,
  [Name] TEXT NOT NULL,
  CONSTRAINT [PK_Languages] PRIMARY KEY ([Uid])
);
"},
{ Table.Languages,
@"CREATE TABLE IF NOT EXISTS [Languages] (
  [Tag] TEXT UNIQUE NOT NULL,
  [Name] TEXT NOT NULL,
  [Icon] BLOB NULL,
  [Active] INTEGER NOT NULL,
  CONSTRAINT [PK_Languages] PRIMARY KEY ([Tag])
);
"},
{ Table.Topics,
@"CREATE TABLE IF NOT EXISTS [Topics] (
  [Id] INTEGER NOT NULL,
  [Uid] TEXT UNIQUE NOT NULL,
  [Name] TEXT NOT NULL,
  [Icon] BLOB NULL,
  [Active] INTEGER NOT NULL,
  CONSTRAINT [PK_Languages] PRIMARY KEY ([Id])
);
"},
{ Table.Books,
@"CREATE TABLE IF NOT EXISTS [Books] (
  [Id] INTEGER NOT NULL,
  [Uid] TEXT UNIQUE NOT NULL,
  [Type] INTEGER NOT NULL,
  [Name] TEXT NOT NULL,
  [Icon] BLOB NULL,
  [Active] INTEGER NOT NULL,
  [PrimaryLanguageTag] TEXT NULL,
  CONSTRAINT [PK_Languages] PRIMARY KEY ([Id])
);
"},
{ Table.Volumes,
@"CREATE TABLE IF NOT EXISTS [Volumes] (
  [Id] INTEGER NOT NULL,
  [PrimaryLanguageTag] TEXT NOT NULL,
  [SecondaryLanguageTag] TEXT NULL,
  CONSTRAINT [PK_Languages] PRIMARY KEY ([Id])
);
"},
{ Table.Words,
@"CREATE TABLE IF NOT EXISTS [Words] (
  [Id] INTEGER NOT NULL,
  [LanguageTag] TEXT NOT NULL,
  [Text] TEXT NOT NULL,
  CONSTRAINT [PK_Languages] PRIMARY KEY ([Id])
);
"},
{ Table.Meanings,
@"CREATE TABLE IF NOT EXISTS [Meanings] (
  [Id] INTEGER NOT NULL,
  [Uid] TEXT UNIQUE NOT NULL,
  [WordId] INTEGER NOT NULL,
  [PoS] TEXT NULL,
  [Text] TEXT NULL,
  CONSTRAINT [PK_Languages] PRIMARY KEY ([Id])
);
"},
{ Table.Translations,
@"CREATE TABLE IF NOT EXISTS [Translations] (
  [Id] INTEGER NOT NULL,
  [VolumeId] INTEGER NOT NULL,
  [MeaningId] INTEGER NOT NULL,
  [Text] TEXT NULL,
  CONSTRAINT [PK_Languages] PRIMARY KEY ([Id])
);
"},
};

/*
		const string Schema = @"
CREATE TABLE IF NOT EXISTS [Manifest] (
  [Key] TEXT NOT NULL,
  [Text] TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS [Languages] (
  [Tag] TEXT UNIQUE NOT NULL,
  [Name] TEXT NOT NULL,
  [Icon] BLOB NULL,
  [Active] INTEGER NOT NULL,
  CONSTRAINT [PK_Languages] PRIMARY KEY ([Tag])
);

CREATE TABLE IF NOT EXISTS [Topics] (
  [Id] INTEGER NOT NULL,
  [Uid] TEXT UNIQUE NOT NULL,
  [Name] TEXT NOT NULL,
  [Icon] BLOB NULL,
  [Active] INTEGER NOT NULL,
  CONSTRAINT [PK_Languages] PRIMARY KEY ([Id])
);

CREATE TABLE IF NOT EXISTS [Books] (
  [Id] INTEGER NOT NULL,
  [Uid] TEXT UNIQUE NOT NULL,
  [Type] INTEGER NOT NULL,
  [Name] TEXT NOT NULL,
  [Icon] BLOB NULL,
  [Active] INTEGER NOT NULL,
  [PrimaryLanguageTag] TEXT NULL,
  CONSTRAINT [PK_Languages] PRIMARY KEY ([Id])
);

CREATE TABLE IF NOT EXISTS [Volumes] (
  [Id] INTEGER NOT NULL,
  [PrimaryLanguageTag] TEXT NOT NULL,
  [SecondaryLanguageTag] TEXT NULL,
  CONSTRAINT [PK_Languages] PRIMARY KEY ([Id])
);

CREATE TABLE IF NOT EXISTS [Words] (
  [Id] INTEGER NOT NULL,
  [LanguageTag] TEXT NOT NULL,
  [Text] TEXT NOT NULL,
  CONSTRAINT [PK_Languages] PRIMARY KEY ([Id])
);

CREATE TABLE IF NOT EXISTS [Meanings] (
  [Id] INTEGER NOT NULL,
  [Uid] TEXT UNIQUE NOT NULL,
  [WordId] INTEGER NOT NULL,
  [PoS] TEXT NULL,
  [Text] TEXT NULL,
  CONSTRAINT [PK_Languages] PRIMARY KEY ([Id])
);

CREATE TABLE IF NOT EXISTS [Translations] (
  [Id] INTEGER NOT NULL,
  [VolumeId] INTEGER NOT NULL,
  [MeaningId] INTEGER NOT NULL,
  [Text] TEXT NULL,
  CONSTRAINT [PK_Languages] PRIMARY KEY ([Id])
);

CREATE TABLE IF NOT EXISTS [PoS] (
  [Uid] TEXT UNIQUE NOT NULL,
  [Abbr] TEXT NOT NULL,
  [Name] TEXT NOT NULL,
  CONSTRAINT [PK_Languages] PRIMARY KEY ([Uid])
);

CREATE TABLE IF NOT EXISTS [Metadata] (
  [Id] INTEGER NOT NULL,
  [BookId] INTEGER NULL,
  [Name] TEXT NOT NULL,
  [Type] TEXT NULL,
  [Text] TEXT NULL,
  [Data] BLOB NULL,
  CONSTRAINT [PK_Metadata] PRIMARY KEY ([Id])
);
";
*/

		const string DropAll = @"
DROP TABLE IF EXISTS [Manifest];
DROP TABLE IF EXISTS [Languages];
DROP TABLE IF EXISTS [Topics];
DROP TABLE IF EXISTS [Books];
DROP TABLE IF EXISTS [Volumes];
DROP TABLE IF EXISTS [Words];
DROP TABLE IF EXISTS [Meanings];
DROP TABLE IF EXISTS [Translations];
DROP TABLE IF EXISTS [PoS];
DROP TABLE IF EXISTS [Metadata];
";

	}
}
