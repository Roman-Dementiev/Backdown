﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Collections
{
	/// <summary>
	/// Generic class LinkedStack
	/// </summary>
	public class LinkedStack<TLinked> : LinkedCollection<TLinked>
		where TLinked : class, ILinked<TLinked>
	{
		#region Properties
		#endregion

		#region Constructors
		public LinkedStack(TLinked head = null) : base(head) { }
		#endregion

		#region Methods
		public TLinked Peek() => head;

		public void Push(TLinked node)
		{
			if (node == null) {
				throw new ArgumentNullException(nameof(node));
			}
			node.Link = head;
			head = node;
		}

		public TLinked Pop()
		{
			TLinked node = head;
			if (node != null) {
				head = node.Link;
				node.Link = null;
			}
			return node;
		}
		#endregion

	}

	#region UnitLinkedStack
	public sealed class UnitLinkedStack : ClassUnit
	{
		private UnitLinkedStack() : base(typeof(LinkedStack<>), UnitCollections._) { }
		public static readonly UnitLinkedStack _ = new UnitLinkedStack();
		public static UnitLinkedStack Instance => _;
	}
	#endregion
}
