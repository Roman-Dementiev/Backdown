﻿#define USING_SQLITE
using System;
using System.Collections.Generic;
using Dwarf.ObjectModel;
using Dwarf.Data;
using Dwarf.Platform;
using Windows.Storage;
using System.Threading.Tasks;
using Dwarf.Extensions;
#if USING_SQLITE
using Dwarf.Data.Sqlite;
using DbCommand = Dwarf.Data.Sqlite.SqliteCommand;
using DbQuery = Dwarf.Data.Sqlite.SqliteQuery;
using Db = Dwarf.Data.Sqlite.SqliteDb;
#endif



namespace Azbooka
{
	public partial class AzbookaDb : Db
	{
#if DEBUG
		static bool DropOnStartup = false;
#endif

		public static readonly Version CurrentVerion = new Version(1,0);

		public AzbookaDb(string filename) : base(filename) { }

		static string Param(string name) => "@" + name;

		//public void Init(string contentType, params string[] tables)
		//{
		//	Manifest = new DbManifest(CurrentVerion, Schemas, contentType, tables);
		//	Manifest.InitDb(this);
		//}

		public async Task Open(bool startup)
		{
			bool init = false;
			string dropCmd = null;
			if (startup) {
				init = await ApplicationData.Current.LocalFolder.FileDoesNotExistAsync(FileName);
#if DEBUG
				if (DropOnStartup) {
					dropCmd = DropAll;
					init = true;
				}
#endif
			}

			if (init) {
				var manifest = new DbManifest(Schemas) {
					ManifestTable = Table.Manifest,
					Version = CurrentVerion,
					ContentType = "AzbookaDb"
				};
				InitFromManifest(manifest, dropCmd);
			} else {
				OpenWithManifest(Table.Manifest);
				var contentType = Manifest.ContentType;
				var contentName = Manifest.ContentName;
			}
		}

		public EntityCollection<Book> GetBooks()
		{
			var books = new EntityCollection<Book>();
			using (var query = ExecuteQuery("SELECT * FROM {0}", Table.Books))
			{
				while (query.Read())
				{
					var uid = query.String(Field.Uid);
					int type = query.Int(Field.Type);

					var book = Book.NewBook(uid, type);
					if (book != null) {
						book.Id = query.Int(Field.Id);
						book.Name = query.String(Field.Name);
						book.Icon = new Bitmap(query.Blob(Field.Icon));
						book.IsSelected = query.Bool(Field.Active);
						books.Add(book);
					} else {
						Dwarf.Debug.Print("Can not initialize book: Uid=\"{0}\" Type={1}", uid, type);
					}
				}
			}

			return books;
		}

		public void AddBook(Book book)
		{
			var commandText = String.Format("INSERT INTO {0} ({1}, {2}, {3}, {4}) VALUES (\"{5}\", {6}, \"{7}\", {8});",
				Table.Books, 
				Field.Uid, Field.Type, Field.Name, Field.Active,
				book.Uid, (int)book.Type, book.Name, book.IsSelected? 1 : 0);

			using (var command = Command(commandText)) {
				command.ExecuteNonQuery();
				book.Id = (int)LastInsertedRowId;
			}
		}

		public Languages GetLanguages()
		{
			var languages = new Languages();
			using (var query = ExecuteQuery( "SELECT * FROM {0};", Table.Languages))
			{
				while (query.Read())
				{
					var tag = query.String(Field.Tag);
					var language = Azbooka.Languages.GetKnown(tag);
					if (language == null) {
						language = new Language(query.String(Field.Tag)) {
							Icon = new Bitmap(query.Blob(Field.Icon)),
							NativeName = query.String(Field.Name),
						};
						Azbooka.Languages.AddToKnown(language);
					}
				//	language.Id = query.Int(Id);
					language.IsSelected = query.Bool(Field.Active);
					languages.Add(language);
				}
			}
			return languages;
		}

		public void AddLanguages(IEnumerable<Language> languages)
		{
			foreach (var language in languages)
			{
				var commandText = String.Format("INSERT INTO {0} ({1}, {2}, {3}, {4}) VALUES (\"{5}\", \"{6}\", {7}, {8});",
					Table.Languages,
					Field.Tag, Field.Name, Field.Icon, Field.Active,
					language.Tag, language.NativeName, Param(Field.Icon), language.IsSelected ? 1 : 0);

				using (var command = Command(commandText))
				{
					command.AddBlobParameter(Field.Icon, language.Icon.BitmapData);
					command.ExecuteNonQuery();
					language.Id = (int)LastInsertedRowId;
				}
			}
		}

		public static EntityCollection<Topic> GetTopics()
		{
			// TODO
			return new EntityCollection<Topic>();
		}

		public void UpdateActive(string table, IEnumerable<ISelectable> items)
		{
			// TODO: use transaction ?
			using (var command = Command())
			{
				foreach (var item in items)
				{
					command.SetCommandText("UPDATE {0} SET {1} = {2}", table, Field.Active, item.IsSelected ? "1" : "0");

					command.ExecuteNonQuery();
				}
			}
		}

		public SortedStringCollection GetWords(string languageTag)
		{
			var list = new SortedStringCollection();

			var queryText = languageTag != null ?
				String.Format("SELECT * FROM {0} WHERE {1}=\"{2}\";", Table.Words, Field.LanguageTag, languageTag) :
				String.Format("SELECT * FROM {0};", Table.Words);

			using (var query = ExecuteQuery(queryText))
			{
				while (query.Read()) {
					var word = query.String(Field.Text);
					list.Add(word);
				}
			}

			return list;
		}

		public Word GetWord(string languageTag, string text)
		{
			Word word;
			var queryText = String.Format("SELECT * FROM {0} WHERE {1}=\"{2}\" AND {3}=\"{4}\";",
					Table.Words, Field.LanguageTag, languageTag, Field.Text, text);
			
			using (var query = ExecuteQuery(queryText))
			{
				if (!query.Read())
					return null;

				word = new Word(languageTag, text);
				word.Id = query.Int(Field.Id);
			}

			queryText = String.Format("SELECT * FROM {0} WHERE {1}=\"{2}\";",
					Table.Meanings, Field.WordId, word.Id);

			using (var query = ExecuteQuery(queryText)) {
				while (query.Read()) {
					var meaning  = new Meaning(query.String(Field.Uid), word) {
						Id = query.Int(Field.Id),
						Text = query.String(Field.Text),
						PoS = PartsOfSpeech.GetPoS(languageTag, query.String(Field.PoS))
					};
					meaning.Id = query.Int(Field.Id);
					word.Meanings.Add(meaning);
				}
			}

			return word;
		}

		public void AddWord(Word word)
		{
			var commandText = String.Format("INSERT INTO {0} ({1}, {2}) VALUES (\"{3}\", \"{4}\");",
				Table.Words,
				Field.LanguageTag, Field.Text,
				word.LanguageTag, word.Text);

			using (var command = Command(commandText))
			{
				command.ExecuteNonQuery();
				word.Id = (int)LastInsertedRowId;
			}

			foreach (var meaning in word.Meanings)
			{
				 commandText = String.Format(@"INSERT INTO {0} ({1}, {2}, {3}, {4}) VALUES (""{5}"", ""{6}"", ""{7}"", ""{8}"");",
					Table.Meanings,
					Field.Uid, Field.WordId, Field.PoS, Field.Text,
					meaning.Uid, word.Id, meaning.PoS.Tag, meaning.Text);

				using (var command = Command(commandText)) {
					command.ExecuteNonQuery();
					meaning.Id = (int)LastInsertedRowId;
				}
			}
		}

		public void UpdateWord(Word newWord, Word originalWord)
		{
			// TODO
		}

		public List<PoS> GetPoS()
		{
			var list = new List<PoS>();
			using (var query = ExecuteQuery("SELECT * FROM {0}", Table.PoS)) {
				while (query.Read()) {
					var uid = query.String(Field.Uid);
					var abbr = query.String(Field.Abbr);
					var name = query.String(Field.Name);
					list.Add(new PoS(Field.Uid, abbr, name));
				}
			}
			return list;
		}

	}
}
