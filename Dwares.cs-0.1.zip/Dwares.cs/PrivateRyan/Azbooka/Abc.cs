﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Dwarf.ObjectModel;


namespace Azbooka
{
	public partial class Abc
	{
		public static Abc Instance => LazyInitializer.EnsureInitialized(ref instance);
		static Abc instance = null;
		static AzbookaDb Db = new AzbookaDb("Azbooka.db");

		public static readonly object RefLock = null; // new object();

		public Abc() {}

		public static async Task OpenDb(bool startup)
		{
			if (!Db.IsOpen) {
				await Db.Open(startup);
			}
		}

		public static async Task CloseDb()
		{
			if (Db.IsOpen) {
				Db.Close();
			}
		}

		public EntityCollection<DirectoryItem> Directory => LazyInitializer.EnsureInitialized(ref directory, InitDirectory);
		EntityCollection<DirectoryItem> directory;

		//public static EntityCollection<DirectoryItem> Secondary => LazyInitializer.EnsureInitialized(ref secondary, InitSecondary)
		//EntityCollection<DirectoryItem> secondary;

		public EntityCollection<Book> Books => LazyInitializer.EnsureInitialized(ref books, GetBooks);
		EntityCollection<Book> books;

		public Languages Languages => LazyInitializer.EnsureInitialized(ref languages, GetLanguages);
		Languages languages;

		public Languages ActiveLanguages => LazyInitializer.EnsureInitialized(ref activeLanguages, GetActiveLanguages);
		Languages activeLanguages;

		public EntityCollection<Topic> Topics => LazyInitializer.EnsureInitialized(ref topics, GetTopics);
		EntityCollection<Topic> topics;

		public PartsOfSpeech PartsOfSpeech => LazyInitializer.EnsureInitialized(ref partsOfSpeech, () => new PartsOfSpeech(Db));
		PartsOfSpeech partsOfSpeech;

		EntityCollection<Book> GetBooks()
		{
			var books = Db.GetBooks();
			if (books.Count == 0) {
				var dictionary = new MyBook(BookType.Dictionary, "My Dictionary");
				Db.AddBook(dictionary);
				books.Add(dictionary);

				var phrasebook = new MyBook(BookType.Phrasebook, "My Phrasebook");
				Db.AddBook(phrasebook);
				books.Add(phrasebook);
			} else {
				//LocalizableItems.LocalizeObject(books, null);
			}
			return books;
		}

		public void UpdateActiveBooks(IEnumerable<Book> books)
		{
			Db.UpdateActive(AzbookaDb.Table.Books, books);
		}

		Languages GetLanguages()
		{
			var languages = Db.GetLanguages();
			if (languages.Count == 0) {
				languages = new Languages(UILanguages.Instance, false);
				foreach (var language in languages) {
					language.IsSelected = true;
				}
				Db.AddLanguages(languages);
			}
			return languages;
		}


		Languages GetActiveLanguages()
		{
			var languages = new Languages();
			foreach (var language in Languages) {
				if (language.IsSelected) {
					languages.Add(language);
				}
			}
			return languages;
		}

		public void UpdateActiveLanguages(IList<Language> list)
		{
			var languages = Languages;
			var addList = new List<Language>();
			var updateList = new List<Language>();

			foreach (var language in list)
			{
				if (languages.Contains(language)) {
					updateList.Add(language);
				} else {
					addList.Add(language);
					languages.Add(language);
				}
			}

			Db.AddLanguages(addList);
			Db.UpdateActive(AzbookaDb.Table.Languages, updateList);
			activeLanguages = null;
		}

		EntityCollection<Topic> GetTopics()
		{
			return AzbookaDb.GetTopics();
		}

		public void UpdateActiveTopics(IEnumerable<Topic> topics)
		{
			Db.UpdateActive(AzbookaDb.Table.Topics, topics);
		}

		public SortedStringCollection GetWords(Language language)
		{
			string languageTag = language?.Tag;
			var list = Db.GetWords(languageTag);
			if (list.Count == 0)
			{
				var words = new EntityCollection<Word>()
				{
					new Word("en", "Ball", "noun", "ball"),
					new Word("en", "Red", "adj", "table"),
					new Word("ru", "Мяч", "noun", "мяч"),
					new Word("ru", "Красный", "adj", "красный"),
				};
				foreach (var word in words) {
					Db.AddWord(word);
				}

				list = Db.GetWords(languageTag);
			}
			return list;
		}

		public Word GetWord(Language language, string text)
		{
			return Db.GetWord(language.Tag, text);
		}

		public void AddWord(Word word)
		{
			Db.AddWord(word);
		}

		public void UpdateWord(Word newWord, Word originalWord)
		{
			Db.UpdateWord(newWord, originalWord);
		}
	}
}
