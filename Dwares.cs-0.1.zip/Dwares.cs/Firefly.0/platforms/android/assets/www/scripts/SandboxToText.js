define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function something() { }
    exports.something = something;
    var Sandbox;
    (function (Sandbox) {
        ;
        function stringOrFunc(source, sf, useToString) {
            if (!sf) {
                return useToString ? source.toString() : "";
            }
            if (typeof sf === 'string') {
                return sf;
            }
            else {
                return sf(source);
            }
        }
        function toText(source, items, args) {
            if (!args)
                args = {};
            var str = "";
            str += stringOrFunc(source, args.textPrefix);
            if (items) {
                for (var i = 0; i < items.length; i++) {
                    str += stringOrFunc(source, args.textBreaks);
                    var item = items[i];
                    str += stringOrFunc(item, args.itemPrefix, false);
                    str += stringOrFunc(item, args.itemString, true);
                    str += stringOrFunc(item, args.itemSuffix, false);
                }
            }
            if (args.textSuffix) {
                str += stringOrFunc(source, args.textSuffix);
            }
            return str;
        }
        Sandbox.toText = toText;
    })(Sandbox || (Sandbox = {}));
    ;
});
//# sourceMappingURL=SandboxToText.js.map