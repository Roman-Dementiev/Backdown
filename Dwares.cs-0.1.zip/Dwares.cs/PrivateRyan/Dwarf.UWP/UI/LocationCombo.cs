﻿using System;
using Dwarf.Platform;


namespace Dwarf.UI
{
	public class LocationCombo : ChoiceComboBox
	{
		public LocationCombo() { }

		public new LocationChoices Choices {
			get => base.Choices as LocationChoices;
			set => base.Choices = value;
		}
	}
}
