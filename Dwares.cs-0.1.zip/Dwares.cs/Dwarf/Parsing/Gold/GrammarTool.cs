﻿using System;
using System.IO;
using Dwarf;
using Dwarf.Utility;
using OptionStyle = Dwarf.Utility.CommandLine.OptionStyle;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing.Gold
{
	/// <summary>
	/// Class GrammarTool
	/// </summary>
	public abstract class GrammarTool : CommandLineTool
	{
		#region Fields
		#endregion

		#region Properties
		[CommandLine.Option('?', "help", Style = OptionStyle.SlashOrDash, IsHelpOption = true,
			Description = "Print usage information.")]
		public bool Help { get; set; } = false;

		[CommandLine.Option('v', "verbose", Description = "Print progress messages.")]
		public bool Verbose { get; set; } = false;

		[CommandLine.Option('c', "compile", Description = "Force compilation of the grammar.")]
		public bool Compile {
			get { return compile; }
			set { compile = value; compileIsSet = true; }
		}
		private bool compile, compileIsSet = false;

		[CommandLine.Option('g', "gold", Param = "Directory", IsRequired = true, 
			Description = "GOLD Parser Builder directory.")]
		public string GOLDBuilderDir { get; set; } = null;

		[CommandLine.Argument("grammar", IsRequired = true, 
			Description = "The grammar file or grammar table.")]
		public string GrammarFile { get; set; } = null;
		public string GTableFile { get; set; } = null;
		public string GOLDbuild { get; set; } = null;

		public Grammar Grammar {
			get {
				if (grammar == null) {
					grammar = GetGrammar();
				}
				return grammar;
			}
		}
		protected Grammar grammar = null;
		#endregion

		#region Constructors
		public GrammarTool()
		{
		}
		#endregion

		#region Methods
		protected virtual Grammar GetGrammar()
		{
			if (!File.Exists(GrammarFile)) {
				Sys.Abort(String.Format("File '{0}' does not exists.", GrammarFile));
			}

			if (Path.GetExtension(GrammarFile).ToLowerCase() == ".grm")
			{
				GTableFile = Path.ChangeExtension(GrammarFile, "egt");

				if (!compileIsSet) {
					if (File.Exists(GTableFile)) {
						DateTime dtGrammar = File.GetLastWriteTime(GrammarFile);
						DateTime dtGTable = File.GetLastWriteTime(GTableFile);
						Compile = dtGrammar > dtGTable;
					} else {
						Compile = true;
					}
				}

				if (Compile) {
					FindGOLD();
					if (Verbose) {
						Console.Out.WriteLine("Compiling grammar {0}", GrammarFile);
					}
					String arguments = String.Format("{0}v \"{1}\" \"{2}\"", Verbose ? '+' : '-', GrammarFile, GTableFile);
					int exitCode = Sys.Execute(GOLDbuild, arguments, null, true, Console.Out, Console.Error);
					if (exitCode != 0) {
						Sys.Abort(String.Format("Failed to compile file {0}", GrammarFile));
					}
				}
			} else {
				GTableFile = GrammarFile;
				GrammarFile = Path.ChangeExtension(GrammarFile, "grm");
				if (!File.Exists(GrammarFile)) {
					GrammarFile = null;
				}
			}

			return new GTable(GTableFile);
		}

		protected virtual void FindGOLD()
		{
			PathList pathList = new PathList();
			pathList.AddCurrentDir();
			pathList.AddSpecial(Environment.SpecialFolder.ProgramFiles, "GOLD Parser Builder");
			pathList.AddSpecial(Environment.SpecialFolder.ProgramFilesX86, "GOLD Parser Builder");
			pathList.AddPATH();
			
			if (GOLDBuilderDir == null) {
				string GOLDBuilderPath = pathList.FindFile("GOLDBuilder.exe");
				if (GOLDBuilderPath != null) {
					GOLDBuilderDir = Path.GetDirectoryName(GOLDBuilderPath);
					pathList.Insert(1, GOLDBuilderDir);
				}
			}

			GOLDbuild = pathList.FindFile("GOLDbuild.exe");
			if (GOLDbuild == null) {
				Sys.Abort("Can not find GOLDBuild.exe");
			}
		}
		#endregion

	}

	#region UnitGrammarTool
	public sealed class UnitGrammarTool : ClassUnit
	{
		private UnitGrammarTool() : base(typeof(GrammarTool), UnitGold._) { }
		public static readonly UnitGrammarTool _ = new UnitGrammarTool();
		public static UnitGrammarTool Instance => _;
	}
	#endregion
}
