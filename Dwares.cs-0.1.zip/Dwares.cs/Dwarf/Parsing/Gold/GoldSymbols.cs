﻿using System;
using System.Collections.Generic;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing.Gold
{
	/// <summary>
	/// Class Gold.Symbols
	/// </summary>
	public class GoldSymbols : Symbols
	{
		public const int cNone = -1;

		#region Fields
		private Grammar.Symbol[] symbols;
		#endregion

		#region Properties
		public Grammar.Symbol[] GrammarSymbols => symbols;
		public uint GroupsCount { get; private set; }
		public uint GroupsStart { get; private set; }
		public uint GroupsEnd { get; private set; }
		#endregion

		#region Constructors
		public GoldSymbols(Grammar grammar)
		{
			Init(grammar);
		}

		protected void Init(Grammar grammar)
		{
			uint terminalCount = 0, nonterminalCount = 0, noiseCount = 0, groupsCount = 0;
			symbols = grammar.Symbols;
			foreach (Grammar.Symbol symbol in symbols)
			{
				switch (symbol.Kind)
				{
				case (ushort)Grammar.SymbolKind.Terminal:
					terminalCount++;
					break;

				case (ushort)Grammar.SymbolKind.Nonterminal:
					nonterminalCount++;
					break;

				case (ushort)Grammar.SymbolKind.Noise:
					noiseCount++;
					break;

				case (ushort)Grammar.SymbolKind.GroupStart:
				case (ushort)Grammar.SymbolKind.GroupEnd:
					groupsCount++;
					break;
				}
			}

			base.Init(terminalCount, nonterminalCount, noiseCount + groupsCount);
			NoiseCount = noiseCount;
			NoiseEnd = NoiseStart + NoiseCount;
			GroupsCount = groupsCount;
			GroupsStart = NoiseEnd;
			GroupsEnd = GroupsStart + GroupsCount;
		}
		#endregion

		#region Methods
		public Grammar.Symbol GrammarSymbol(int sym)
		{
			Debug.Assert(sym >= 0 && sym < symbols.Length);
			return symbols[sym];
		}

		public override string GetName(int sym)
		{
			if (sym >= 0 && sym < symbols.Length) {
				return symbols[sym].Name;
			}

			return base.GetName(sym);
		}

		public bool IsGroup(int sym) {
			return sym >= GroupsStart && sym < GroupsEnd;
		}

		public bool IsGroupStart(int sym)
		{
			Debug.Assert(sym < symbols.Length);
			return IsGroup(sym) && symbols[sym].IsGroupStart;
		}

		public bool IsGroupEnd(int sym)
		{
			Debug.Assert(sym >= 0 && sym < symbols.Length);
			return IsGroup(sym) && symbols[sym].IsGroupEnd;
		}
		#endregion
	}

	#region UnitGoldSymbols
	public sealed class UnitGoldSymbols : ClassUnit
	{
		private UnitGoldSymbols() : base(typeof(GoldSymbols), UnitGold._) { }
		public static readonly UnitGoldSymbols _ = new UnitGoldSymbols();
		public static UnitGoldSymbols Instance => _;
	}
	#endregion
}
