/// <reference path="Sandbox.ts" />
define(["require", "exports", "./Dwog"], function (require, exports, Dwog) {
    // For an introduction to the Blank template, see the following documentation:
    // http://go.microsoft.com/fwlink/?LinkID=397705
    // To debug code on page load in cordova-simulate or on Android devices/emulators: launch your app, set breakpoints, 
    // and then run "window.location.reload()" in the JavaScript Console.
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function initialize() {
        document.addEventListener('deviceready', onDeviceReady, false);
    }
    exports.initialize = initialize;
    function onDeviceReady() {
        document.addEventListener('pause', onPause, false);
        document.addEventListener('resume', onResume, false);
        // TODO: Cordova has been loaded. Perform any initialization that requires Cordova here.
        var parentElement = document.getElementById('deviceready');
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');
        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');
        var testElement = document.getElementById('test');
        testElement.innerHTML = test();
    }
    function onPause() {
        // TODO: This application has been suspended. Save application state here.
    }
    function onResume() {
        // TODO: This application has been reactivated. Restore application state here.
    }
    function test() {
        //function dwogTest()
        //{
        //	Dwog.message('Hello here!');
        //	Dwog.verbose('Verbose: ...');
        //	Dwog.warning('Warning!');
        //	Dwog.debug('Debug!');
        //	Dwog.error('Error!');
        //	Dwog.fatal('Fatal!');
        //	Dwog.noise('Noise...');
        //	Dwog.woof('Woof!!!');
        //}
        Dwog.setLevel(Dwog.BarkLevel.Noise);
        Dwog.test.runToConsole();
        //	dwogTest();
        //Dwog.group();
        //dwogTest();
        //Dwog.groupEnd();
        var barks = Dwog.test.runToBarks();
        var ret = Sandbox.toText(barks, barks, { textBreaks: "<br>" });
        ;
        return ret;
    }
});
//# sourceMappingURL=application.js.map