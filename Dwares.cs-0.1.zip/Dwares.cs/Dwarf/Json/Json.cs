﻿using System;
using Dwarf.Assets;
using Dwarf.Config;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Json
{
	public class InvalidTokenException : Parsing.ParserInternalError
	{
		public InvalidTokenException(Dwarf.Unit unit, string message, bool useAssets, Exception innerExc = null) :
			base(unit, message, useAssets, innerExc)
		{ }

		public InvalidTokenException(Dwarf.Unit unit, object token, Exception innerExc = null) :
			base(unit, innerExc, true, Messages.JsonInvalidToken, token.ToString())
		{ }
	}

	public class NumberOverflowException : DwarfException
	{
		public NumberOverflowException(Dwarf.Unit unit, string message, bool useAssets, Exception innerExc = null) :
			base(unit, message, useAssets, innerExc)
		{ }

		public NumberOverflowException(Dwarf.Unit unit, object token, Exception innerExc = null) :
			base(unit, innerExc, true, Messages.JsonNumberOverflow, token.ToString())
		{ }
	}

	/// <summary>
	/// Default error message for exceptions
	/// </summary>
	public static class Messages
	{
		public const string JsonInvalidToken	= nameof(JsonInvalidToken);
		public const string JsonNumberOverflow	= nameof(JsonNumberOverflow);
	}

	#region Unit
	public sealed class UnitJson : NamespaceUnit
	{
		private UnitJson() : base("Json", UnitDwarf._)
		{
#if INIT_DEFAULT_MESSAGES
			AssetMgr.SetDefaultStrings(
				Messages.JsonInvalidToken,   "Invalid JSON token'{0}'",   // token name
				Messages.JsonNumberOverflow, "JSON number overflow'{0}'"  // token name
			);
#endif
		}
		public static readonly UnitJson _ = new UnitJson();
		public static UnitJson Instance => _;
	}
	#endregion
}
