﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Utility
{
	/// <summary>
	/// Generic class Singleton
	/// </summary>
	/// <typeparam name="T">Type of singleton</typeparam>
	public class Singleton<T> where T : new()
	{
		private static Lazy<T> lazy = new Lazy<T>(() => new T());

		public static T Instance => lazy.Value;
		public static bool IsCreated => lazy.IsValueCreated;
	}

	#region UnitSingleton
	public sealed class UnitSingleton : ClassUnit
	{
		private UnitSingleton() : base(typeof(Singleton<>), UnitUtility._) { }
		public static readonly UnitSingleton _ = new UnitSingleton();
		public static UnitSingleton Instance => _;
	}
	#endregion
}
