﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Microsoft.Toolkit.Uwp.UI;
using System.Threading.Tasks;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace UWT
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
		private AutoSuggestBox searchBox;

		public MainPage()
        {
            this.InitializeComponent();

		}

		private void HamburgerMenu_OnItemClick(object sender, ItemClickEventArgs e)
		{
			var category = e.ClickedItem as SampleCategory;

			//if (category != null)
			//{
			//	HideInfoArea();
			//	NavigationFrame.Navigate(typeof(SamplePicker), category);
			//}
		}

		private void HamburgerMenu_OnOptionsItemClick(object sender, ItemClickEventArgs e)
		{
			var option = e.ClickedItem as Option;
			if (option == null)
			{
				return;
			}

			//if (option.Tag != null)
			//{
			//	NavigationFrame.Navigate(typeof(SamplePicker), option.Tag);
			//	return;
			//}

			//if (NavigationFrame.CurrentSourcePageType != option.PageType)
			//{
			//	NavigationFrame.Navigate(option.PageType);
			//}
		}

		private void ConnectToSearch()
		{
			var searchButton = HamburgerMenu.FindDescendantByName("SearchButton") as Button;
			searchBox = HamburgerMenu.FindDescendantByName("SearchBox") as AutoSuggestBox;

			if (searchBox == null || searchButton == null)
			{
				return;
			}

			searchButton.Click += async (sender, args) =>
			{
				HamburgerMenu.IsPaneOpen = true;
				searchBox.Text = string.Empty;

				// We need to wait for the textbox to be created to focus it (only first time).
				TextBox innerTextbox = null;

				do
				{
					innerTextbox = searchBox.FindDescendant<TextBox>();
					innerTextbox?.Focus(FocusState.Programmatic);

					if (innerTextbox == null)
					{
						await Task.Delay(150);
					}
				}
				while (innerTextbox == null);
			};

			searchBox.DisplayMemberPath = "Name";
			searchBox.TextMemberPath = "Name";

			searchBox.QuerySubmitted += (sender, args) =>
			{
			//	NavigationFrame.Navigate(typeof(SamplePicker), _searchBox.Text);
			};

			searchBox.TextChanged += (sender, args) =>
			{
				if (args.Reason != AutoSuggestionBoxTextChangeReason.UserInput)
				{
					return;
				}

				UpdateSearchSuggestions();
			};
		}

		private async void UpdateSearchSuggestions()
		{
//			_searchBox.ItemsSource = (await Samples.FindSamplesByName(_searchBox.Text)).OrderBy(s => s.Name);
		}

		private void Page_Loaded(object sender, RoutedEventArgs e)
		{
			HamburgerMenu.OptionsItemsSource = new[]
			{
				new Option { Glyph = "", Name = "More resources" },
				new Option { Glyph = "", Name = "About" }
			};

			ConnectToSearch();
		}
	}

}
