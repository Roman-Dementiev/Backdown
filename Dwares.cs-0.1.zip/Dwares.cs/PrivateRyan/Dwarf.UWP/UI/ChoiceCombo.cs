﻿using System;
using Dwarf.ObjectModel;
using Dwarf.Platform;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Media.Imaging;


namespace Dwarf.UI
{
	public class ChoiceCombo : ComboBox
	{
		IChoices choices;

		public ChoiceCombo()
		{
			SelectionChanged += OnSelectionChanged;
		}

		public new object ItemsSource {
			get => base.ItemsSource;
			private set => base.ItemsSource = value; 
		}

		public IChoices Choices {
			get => choices;
			set => SetChoices(value);
		}

		void SetChoices(IChoices choices)
		{
			if (choices == this.choices)
				return;

			if (this.choices != null) {
				this.choices.CurrentChoiceChanged -= OnCurrentChoiceChanged;
			}

			if (choices != null) {
				choices.CurrentChoiceChanged += OnCurrentChoiceChanged;
			}

			this.choices = choices;
			ItemsSource = choices;

			ApplyAppearance();
			OnCurrentChoiceChanged();
		}

		public IChoice CurrentChoice {
			get => choices?.CurrentChoice;
			set {
				if (choices != null) {
					choices.CurrentChoice = value;
				}
			}
		}

		public void OnCurrentChoiceChanged(IChoices sender = null)
		{
			var currentChoice = choices?.CurrentChoice;

			if (currentChoice != null) {
				ChoiceImage = currentChoice.ChoiceImage;
				ChoiceLabel = currentChoice.ChoiceLabel;
				ChoiceToolTip = currentChoice.ChoiceToolTip(ChoiceAppearance);
			} else {
				ChoiceImage = PlaceholderImage;
				ChoiceLabel = PlaceholderText;
				ChoiceToolTip = String.Empty;
			}
			ToolTipService.SetToolTip(this, ChoiceToolTip);

			base.SelectedItem = null;
		}

		private void OnSelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (SelectedItem is IChoice choice) {
				if (choices != null && choice != choices.CurrentChoice) {
					choices.CurrentChoice = choice;
				}
			}
		}

		protected override void OnApplyTemplate()
		{
			base.OnApplyTemplate();

			ApplyAppearance();
			OnCurrentChoiceChanged();
		}

		void ApplyAppearance()
		{
			ImageVisibility = ChoiceAppearance.ChoiceImagesVisibility(choices);
			LabelVisibility = ChoiceAppearance.ChoiceLabelsVisibility(choices);
		}

		public ChoiceAppearance ChoiceAppearance {
			get => (ChoiceAppearance)GetValue(ChoiceAppearanceProperty);
			set {
				SetValue(ChoiceAppearanceProperty, value);
				ApplyAppearance();
			}
		}
		public static readonly DependencyProperty ChoiceAppearanceProperty = UI.RegisterDependencyProperty<ChoiceCombo, ChoiceAppearance>(nameof(ChoiceAppearance), ChoiceAppearance.Auto);

		public BitmapImage PlaceholderImage {
			get => (BitmapImage)GetValue(PlaceholderImageProperty);
			set => SetValue(PlaceholderImageProperty, value);
		}
		public static readonly DependencyProperty PlaceholderImageProperty = UI.RegisterDependencyProperty<ChoiceCombo, BitmapImage>(nameof(PlaceholderImage));

		public BitmapImage ChoiceImage {
			get => (BitmapImage)GetValue(ChoiceImageProperty);
			set => SetValue(ChoiceImageProperty, value);
		}
		public static readonly DependencyProperty ChoiceImageProperty = UI.RegisterDependencyProperty<ChoiceCombo, BitmapImage>(nameof(ChoiceImage));

		public Visibility ImageVisibility {
			get => (Visibility)GetValue(ImageVisibilityProperty);
			set => SetValue(ImageVisibilityProperty, value);
		}
		public static readonly DependencyProperty ImageVisibilityProperty = UI.RegisterDependencyProperty<ChoiceCombo, Visibility>(nameof(ImageVisibility));

		public double ImageWidth {
			get => (double)GetValue(ImageWidthProperty);
			set => SetValue(ImageWidthProperty, value);
		}
		public static readonly DependencyProperty ImageWidthProperty = UI.RegisterDependencyProperty<ChoiceCombo, double>(nameof(ImageWidth), 30);

		public double ImageHeight {
			get => (double)GetValue(ImageHeightProperty);
			set => SetValue(ImageHeightProperty, value);
		}
		public static readonly DependencyProperty ImageHeightProperty = UI.RegisterDependencyProperty<ChoiceCombo, double>(nameof(ImageHeight), 30);

		public Visibility LabelVisibility {
			get => (Visibility)GetValue(LabelVisibilityProperty);
			set => SetValue(LabelVisibilityProperty, value);
		}
		public static readonly DependencyProperty LabelVisibilityProperty = UI.RegisterDependencyProperty<ChoiceCombo, Visibility>(nameof(LabelVisibility));

		public string ChoiceLabel {
			get => (string)GetValue(ChoiceLabelProperty);
			set => SetValue(ChoiceLabelProperty, value);
		}
		public static readonly DependencyProperty ChoiceLabelProperty = UI.RegisterDependencyProperty<ChoiceCombo, string>(nameof(ChoiceLabel));

		public string ChoiceToolTip {
			get => (string)GetValue(ChoiceToolTipProperty);
			set => SetValue(ChoiceToolTipProperty, value);
		}
		public static readonly DependencyProperty ChoiceToolTipProperty = UI.RegisterDependencyProperty<ChoiceCombo, string>(nameof(ChoiceToolTip));

		public Thickness ContentMargin {
			get => (Thickness)GetValue(ContentMarginProperty);
			set => SetValue(ContentMarginProperty, value);
		}
		public static readonly DependencyProperty ContentMarginProperty = UI.RegisterDependencyProperty<ChoiceCombo, Thickness>(nameof(ContentMargin));

		public Thickness DropDownMargin {
			get => (Thickness)GetValue(DropDownMarginProperty);
			set => SetValue(DropDownMarginProperty, value);
		}
		public static readonly DependencyProperty DropDownMarginProperty = UI.RegisterDependencyProperty<ChoiceCombo, Thickness>(nameof(DropDownMargin));

	}

	public class ChoiceComboBox : ChoiceCombo
	{
		public ChoiceComboBox()
		{
			DefaultStyleKey = typeof(ChoiceComboBox);
		}
	}

	public class ChoicePicker : ChoiceCombo
	{
		public ChoicePicker()
		{
			DefaultStyleKey = typeof(ChoicePicker);
		}
	}
}
