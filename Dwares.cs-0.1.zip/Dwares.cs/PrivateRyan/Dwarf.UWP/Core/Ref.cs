﻿using System;


namespace Dwarf
{
	public struct Ref<TReferenced> where TReferenced : class, IReferenced
	{
		TReferenced value;

		public TReferenced Value {
			get => value;
			set {
				if (value != this.value) {
					if (this.value != null) {
						this.value.RemoveRef(this);
					}
					if (value != null) {
						value.AddRef(this);
					}
					this.value = value;
				}
			}
		}

		public TReferenced EnsureInitialized(Func<TReferenced> valueFactory, object @lock = null)
		{
			if (value == null) {
				if (@lock != null) {
					lock(@lock) {
						if (value != null) {
							value = valueFactory();
							value.AddRef(this);
						}
					}
				} else {
					value = valueFactory();
					value.AddRef(this);
				}
			}
			return value;
		}

		public static explicit operator TReferenced(Ref<TReferenced> @ref) => @ref.value;
	}

	public struct DisposableRef<TReferenced> : IDisposable
		where TReferenced : class, IReferenced, IDisposable
	{
		Ref<TReferenced> @ref;

		public void Dispose()
		{
			Value = null;
		}

		public TReferenced Value {
			get => @ref.Value;
			set {
				if (value != @ref.Value) {
					var val = @ref.Value;
					@ref.Value = value;
					if (val != null && val.RefCount == 0) {
						val.Dispose();
					}
				}
			}
		}
	}
}
