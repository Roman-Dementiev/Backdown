﻿using System;
using System.Collections.Generic;
using System.IO;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Utility
{
	public class PathList : List<string>
	{
		public const char cNoSplit = (char)0;
		public const char cSplit = ';';

		#region Constructors
		public PathList() { }

		public PathList(string path, char split = cSplit)
		{
			Add(path, split);
		}
		#endregion

		#region Methods
		public void Insert(int index, string path, char split = cNoSplit)
		{
			if (String.IsNullOrEmpty(path))
				return;

			if (split != cNoSplit) {
				string[] pathes = path.Split(split);
				foreach (string p in pathes) {
					if (index < 0) {
						base.Add(p);
					} else {
						base.Insert(index++, p);
					}
				}
			} else {
				if (index < 0) {
					base.Add(path);
				} else {
					base.Insert(index, path);
				}
			}
		}

		public void InsertCurrentDir(int index)
		{
			Insert(index, Sys.CurrentDir, cNoSplit);
		}

		public void InsertApplicationDir(int index)
		{
			Insert(index, Sys.AppDir, cNoSplit);
		}

		public void InsertSpecial(int index, Environment.SpecialFolder folder, string fileOrDirName = null)
		{
			string path = Environment.GetFolderPath(folder);
			if (fileOrDirName != null) {
				path = Path.Combine(path, fileOrDirName);
			}
			Insert(index, path, cNoSplit);
		}

		public void InsertEnv(int index, string name, char split = cSplit)
		{
			string path = Environment.GetEnvironmentVariable(name);
			if (!String.IsNullOrEmpty(path)) {
				Insert(index, path, split);
			}
		}

		public void InsertPATH(int index)
		{
			InsertEnv(index, "Path");
		}

		public void Add(string path, char split=cNoSplit)
		{
			Insert(-1, path, split);
		}

		public void AddCurrentDir()
		{
			InsertCurrentDir(-1);
		}

		public void AddApplicationDir()
		{
			InsertApplicationDir(-1);
		}

		public void AddSpecial(Environment.SpecialFolder folder, string fileOrDirName = null)
		{
			InsertSpecial(-1, folder, fileOrDirName);
		}

		public void AddEnvironmentVariable(string name, char split = cSplit)
		{
			InsertEnv(-1, name, split);
		}

		public void AddPATH()
		{
			InsertPATH(-1);
		}

		public string FindFile(string fileName)
		{
			foreach (string path in this)
			{
				string fullPath = Path.GetFullPath(Path.Combine(path, fileName));
				if (File.Exists(fullPath)) {
					return fullPath;
				}
			}

			return null;
		}

		public string FindDir(string dirName)
		{
			foreach (string path in this) {
				string fullPath = Path.GetFullPath(Path.Combine(path, dirName));
				if (Directory.Exists(fullPath)) {
					return fullPath;
				}
			}

			return null;
		}
		#endregion
	}

	#region UnitSys
	public sealed class UnitPathList : ClassUnit
	{
		private UnitPathList() : base(typeof(PathList), UnitUtility._) { }
		public static readonly UnitPathList _ = new UnitPathList();
		public static UnitPathList Instance => _;
	}
	#endregion
}
