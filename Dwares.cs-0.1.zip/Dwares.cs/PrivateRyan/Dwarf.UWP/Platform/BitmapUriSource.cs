﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Media.Imaging;

namespace Dwarf.Platform
{
	public class BitmapUriSource : IBitmapLoader
	{
		Uri uri;

		public BitmapUriSource(Uri uri)
		{
			this.uri = uri;
		}

		public BitmapImage LoadBitmapImage()
		{
			return new BitmapImage(uri);
		}

		public bool CanLoadData() => false;
		public byte[] LoadBitmapData() => null;
	}
}
