﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Windows.Foundation;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Dwarf.ObjectModel;


namespace Dwarf.UI
{
	public class ListViewHelper<TItem> : ListViewBaseHelper<ListView, FrameworkElement, TItem> where TItem : class
	{
		public ListViewHelper(uint numPhases = 0) : base(numPhases) { }
	}

	public class GridViewHelper<TItem> : ListViewBaseHelper<GridView, FrameworkElement, TItem> where TItem : class
	{
		public GridViewHelper(uint numPhases = 0) : base(numPhases) { }
	}


	public class ListViewBaseHelper<TContainer, TView, TItem>
		where TContainer : ListViewBase
		where TView : FrameworkElement
		where TItem : class
	{
		public ListViewBaseHelper(uint numPhases)
		{
			NumPhases = numPhases;
		}

		public ListViewBaseHelper(TContainer container, uint numPhases) : this(numPhases)
		{
			AttachTo(container);
		}

		public virtual void AttachTo(TContainer container)
		{
			container.ContainerContentChanging += ContainerContentChanging;
			container.SizeChanged += ContainerSizeChanged;
			container.SelectionChanged += SelectionChanged;
		}

		public virtual void DetachFrom(TContainer container)
		{
			container.ContainerContentChanging += ContainerContentChanging;
			container.SizeChanged += ContainerSizeChanged;
			container.SelectionChanged += SelectionChanged;
		}


		public uint NumPhases { get; set; }
		public List<TItem> SelectedChanged { get; } = new List<TItem>();

		/// <summary>
		/// Drop all references to the data item
		/// </summary>
		/// <param name="container"></param>
		/// <param name="view"></param>
		public virtual void ClearView(TContainer container, TView view)
		{
			if (view is ISourced<TItem> sourced) {
				TItem item = sourced.Source;
				if (item is INotifyPropertyChanged && view is IPropertyObserver) {
					((INotifyPropertyChanged)item).PropertyChanged -=
						((IPropertyObserver)view).OnPropertyChanged;
				}
				sourced.Source = null;
			}
		}

		/// <summary>
		/// This method visualizes the placeholder state of the data item.
		/// </summary>
		/// <param name="container"></param>
		/// <param name="item"></param>
		/// <param name="view"></param>
		public virtual void ShowPlaceholder(TContainer container, TView view, TItem item)
		{
			if (item == null)
				return;

			AdjustViewSize(container, view, item, container.ActualWidth, container.ActualHeight);

			if (view is ISourced<TItem> sourced) {
				sourced.Source = item;
			}

			if (item is INotifyPropertyChanged && view is IPropertyObserver) {
				((INotifyPropertyChanged)item).PropertyChanged +=
					((IPropertyObserver)view).OnPropertyChanged;
			}

			if (item is ISelectable selectable) {
				if (selectable.IsSelected) {
					container.SelectedItems.Add(item);
				}
			}
		}

		public double? AdjustWidth { get; set; }

		public virtual void AdjustViewSize(TContainer container, TView view, TItem item, double containerWidth, double containerHeight)
		{
			if (AdjustWidth != null && container is ListView && containerWidth > 0) {
				//var margin = container.Margin;
				//var border = container.BorderThickness;
				view.Width = containerWidth + (double)AdjustWidth /*- (margin.Left + margin.Right + border.Left + border.Right)*/;
				var viewType = view.GetType();
				var itemType = item.GetType();
				Debug.Print("Adjust width: view={0}, item={1} => {2}", viewType, itemType, view.Width);
			}
		}

		public virtual void AdjustViewSizeForAll(TContainer container, double containerWidth, double containerHeight)
		{
			if (AdjustWidth != null && container is ListView) {
				ForEachView(container, (view, item) => AdjustViewSize(container, view, item, containerWidth, containerHeight));
			}
		}

		/// <summary>
		/// Visualization phase
		/// </summary>
		/// <param name="container"></param>
		/// <param name="view"></param>
		public virtual void ShowPhase(uint phase, TContainer container, TView view, TItem item)
		{
			if (phase == 0) {
				ShowPlaceholder(container, view, item);
			}
		}

		public void ForEachItem(TContainer container, Action<TItem> action)
		{
			foreach (var obj in container.Items) {
				if (obj is TItem item) {
					action(item);
				}
			}
		}

		public void ForEachView(TContainer container, Action<TView, TItem> action)
		{
			foreach (var obj in container.Items) {
				if (obj is TItem item) {
					var itemContainer = container.ContainerFromItem(item) as SelectorItem;
					var view = itemContainer?.ContentTemplateRoot as TView;
					if (view != null) {
						action(view, item);
					}
				}
			}
		}

		/// <summary>
		/// Managing delegate creation to ensure we instantiate a single instance for 
		/// optimal performance. 
		/// </summary>
		private TypedEventHandler<ListViewBase, ContainerContentChangingEventArgs> ContentChangingDelegate {
			get {
				if (contentChangingDelegate == null) {
					contentChangingDelegate = new TypedEventHandler<ListViewBase, ContainerContentChangingEventArgs>(ContainerContentChanging);
				}
				return contentChangingDelegate;
			}
		}
		private TypedEventHandler<ListViewBase, ContainerContentChangingEventArgs> contentChangingDelegate;

		void ContainerContentChanging(ListViewBase sender, ContainerContentChangingEventArgs args)
		{
			TContainer container = sender as TContainer;
			TView view = args.ItemContainer.ContentTemplateRoot as TView;
			if (container == null || view == null)
				return;

			if (args.InRecycleQueue == true) {
				ClearView(container, view);
			} else {
				TItem item = args.Item as TItem;
				ShowPhase(args.Phase, container, view, item);

				if (args.Phase < NumPhases) {
					// Register for async callback to visualize next phase
					args.RegisterUpdateCallback(ContentChangingDelegate);
				}
			}

			args.Handled = true;
		}

		void ContainerSizeChanged(object sender, SizeChangedEventArgs e)
		{
			TContainer container = sender as TContainer;
			AdjustViewSizeForAll(container, e.NewSize.Width, e.NewSize.Height);
		}

		void SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			foreach (var item in e.RemovedItems) {
				if (item is ISelectable selectable) {
					selectable.IsSelected = false;
					SelectedChanged.Add((TItem)item);
				}
			}

			foreach (var item in e.AddedItems) {
				if (item is ISelectable selectable) {
					selectable.IsSelected = true;
					SelectedChanged.Add((TItem)item);
				}
			}
		}
	}
}
