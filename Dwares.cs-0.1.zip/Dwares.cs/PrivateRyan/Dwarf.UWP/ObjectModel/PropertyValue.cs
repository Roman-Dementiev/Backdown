﻿using System;
using System.ComponentModel;

namespace Dwarf.ObjectModel
{
	public delegate bool PropertyValueChanging<TValue>(TValue oldValue, TValue newValue);

	public struct PropertyValue<TValue> where TValue : class
	{
		TValue value;

		public PropertyValue(TValue value)
		{
			this.value = value;
		}

		public Type PropertyType => typeof(TValue);

		public TValue Value {
			get => value;
			set => Set(value);
		}

		public void Set(TValue value, PropertyValueChanging<TValue> onValueChanging = null)
		{
			if (value != this.value) {
				if (onValueChanging == null) {
					this.value = value;
				} else if (onValueChanging(this.value, value)) {
					this.value = value;
				}
			}
		}

		public void Set(TValue value, Action onValueChanged)
		{
			if (value != this.value) {
				this.value = value;
				onValueChanged?.Invoke();
			}
		}

		public void Set(TValue value, Action<TValue> onValueChanged)
		{
			if (value != this.value) {
				this.value = value;
				onValueChanged?.Invoke(value);
			}
		}

		public static implicit operator TValue(PropertyValue<TValue> val) => val.value;
	}


	public struct ScalarPropertyValue<TValue> where TValue : struct
	{
		TValue value;

		public ScalarPropertyValue(TValue value = default(TValue))
		{
			this.value = value;
		}

		public Type PropertyType => typeof(TValue);

		public TValue Value {
			get => value;
			set => Set(value);
		}

		public void Set(TValue value, PropertyValueChanging<TValue> onValueChanging = null)
		{
			if (!value.Equals(this.value)) {
				if (onValueChanging == null) {
					this.value = value;
				}
				else if (onValueChanging(this.value, value)) {
					this.value = value;
				}
			}
		}

		public void Set(TValue value, Action onValueChanging)
		{
			if (!value.Equals(this.value)) {
				onValueChanging?.Invoke();
				this.value = value;
			}
		}

		public void Set(TValue value, Action<TValue> onValueChanging)
		{
			if (!value.Equals(this.value)) {
				onValueChanging?.Invoke(value);
				this.value = value;
			}
		}

		public static implicit operator TValue(ScalarPropertyValue<TValue> val) => val.value;
	}

	public struct NullablePropertyValue<TValue> where TValue : struct
	{
		TValue? value;

		public NullablePropertyValue(TValue? value = null)
		{
			this.value = value;
		}

		public NullablePropertyValue(TValue value)
		{
			this.value = value;
		}

		public Type PropertyType => typeof(TValue);

		public bool IsNull => value == null;

		public TValue? Nullable {
			get => value;
			set => Set(value);
		}

		public TValue Value {
			get => value == null ? default(TValue) : (TValue)value;
			set => Set(value);
		}

		public void Set(TValue? value, PropertyValueChanging<TValue?> onValueChanging = null)
		{
			if (!System.Nullable.Equals<TValue>(value, this.value)) {
				if (onValueChanging == null) {
					this.value = value;
				} else if (onValueChanging(this.value, value)) {
					this.value = value;
				}
			}
		}

		public void Set(TValue value, Action onValueChanging)
		{
			if (!System.Nullable.Equals<TValue>(value, this.value)) {
				onValueChanging?.Invoke();
				this.value = value;
			}
		}

		public void Set(TValue? value, Action onValueChanging)
		{
			if (!System.Nullable.Equals<TValue>(value, this.value)) {
				onValueChanging?.Invoke();
				this.value = value;
			}
		}

		public void Set(TValue value, Action<TValue> onValueChanging)
		{
			if (!System.Nullable.Equals<TValue>(value, this.value)) {
				onValueChanging?.Invoke(value);
				this.value = value;
			}
		}

		public void Set(TValue? value, Action<TValue?> onValueChanging)
		{
			if (!System.Nullable.Equals<TValue>(value, this.value)) {
				onValueChanging?.Invoke(value);
				this.value = value;
			}
		}

		public static implicit operator TValue(NullablePropertyValue<TValue> val) => val.Value;
	}
}
