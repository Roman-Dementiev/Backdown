﻿using System;
using System.IO;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Logging
{
	/// <summary>
	/// Class TextLogger
	/// </summary>
	public class TextLogger : BaseLogger, IDisposable
	{
		#region Fields
		#endregion

		#region Constructor
		/// <summary>
		/// Initializes a new instance of the <see cref="TextLogger" /> class.
		/// </summary>
		/// <param name="writer">The writer.</param>
		/// <param name="formatter">The formatter.</param>
		public TextLogger(TextWriter writer, ILogFormatter formatter = null) :
			base(formatter)
		{
			Writer = writer;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="TextLogger"/> class.
		/// </summary>
		/// <param name="stream">The stream.</param>
		/// <param name="formatter">The formatter.</param>
		public TextLogger(Stream stream, ILogFormatter formatter = null) :
			base(formatter)
		{
			Writer = new StreamWriter(stream);
		}
		#endregion

		#region Properties
		/// <summary>
		/// Gets the output writer.
		/// </summary>
		/// <value>
		/// The writer.
		/// </value>
		public TextWriter Writer { get; }
		#endregion

		#region Methods
		/// <summary>
		/// Writes formatted log message from specified unit to <see cref="Writer"/>
		/// </summary>
		/// <param name="message">The message.</param>
		public override void Write(string message)
		{
			Writer.WriteLine(message);
		}

		/// <summary>
		/// Disposes the writer.
		/// </summary>
		public void Dispose()
		{
			Writer.Dispose();
		}
		#endregion

	}

	#region UnitTextLogger
	public sealed class UnitTextLogger : ClassUnit
	{
		private UnitTextLogger() : base(typeof(TextLogger), UnitLogging._) { }
		public static readonly UnitTextLogger _ = new UnitTextLogger();
		public static UnitTextLogger Instance => _;
	}
	#endregion
}
