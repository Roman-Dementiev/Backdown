﻿using System;
using System.ComponentModel;
using Windows.UI.Xaml.Controls;
using Dwarf.ObjectModel;


namespace Azbooka
{
	public sealed partial class LanguageView : UserControl, IPropertyObserver
	{
		public LanguageView()
		{
			this.InitializeComponent();
		}

		public Image Image => image;
		public TextBlock NativeName => nativeName;
		public TextBlock LocalizedName => localaziedName;

		public void OnPropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			var language = sender as Language;
			if (language == null) return;

			if (e.PropertyName == nameof(language.LocalizedName)) {
				localaziedName.Text = language.LocalizedName;
			}
		}
	}
}
