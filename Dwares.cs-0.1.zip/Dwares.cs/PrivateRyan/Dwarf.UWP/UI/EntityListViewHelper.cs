﻿using System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Dwarf.ObjectModel;


namespace Dwarf.UI
{
	public class EntityListViewHelper<TEntity> : EntityListViewHelper<ListView, FrameworkElement, TEntity> where TEntity : class, IEntity
	{
		public EntityListViewHelper(uint numPhases = 2) : base(numPhases) { }
	}

	public class EntityGridViewHelper<TEntity> : EntityListViewHelper<GridView, FrameworkElement, TEntity> where TEntity : class, IEntity
	{
		public EntityGridViewHelper(uint numPhases = 2) : base(numPhases) { }
	}


	public class EntityListViewHelper<TContainer, TView, TEntity> : ListViewBaseHelper<TContainer, TView, TEntity>
		where TContainer : ListViewBase
		where TView : FrameworkElement
		where TEntity : class, IEntity
	{
		public EntityListViewHelper(uint numPhases = 2) : base(numPhases) { }

		public override void ClearView(TContainer container, TView view)
		{
			base.ClearView(container, view);

			var indent = EntityView.Indent(view);
			var image = EntityView.Image(view);
			var label = EntityView.Label(view);

			if (indent != null) {
				indent.Width = indent.MinWidth;
			}
			if (image != null) {
				image.ClearValue(Image.SourceProperty);
			}
			if (label != null) {
				label.ClearValue(TextBlock.TextProperty);
			}
		}

		public override void ShowPhase(uint phase, TContainer container, TView view, TEntity item)
		{
			switch (phase) {
			case 0:
				ShowPlaceholder(container, view, item);
				break;
			case 1:
				ShowLabel(view, item);
				break;
			case 2:
				ShowImage(view, item);
				break;
			}
		}

		public override void ShowPlaceholder(TContainer container, TView view, TEntity item)
		{
			base.ShowPlaceholder(container, view, item);

			var indent = EntityView.Indent(view);
			var image = EntityView.Image(view);
			var label = EntityView.Label(view);

			if (indent != null) {
				if (item is IKin) {
					int indentLevel = ((IKin)item).KinLevel();
					var indentWidth = indent.Width - indent.MinWidth;
					indent.Width = indent.MinWidth + indentLevel * indentWidth;
				} else {
					indent.Width = indent.MinWidth;
				}
			}
			if (image != null) {
				image.Opacity = 0;
			}
			if (label != null) {
				label.Opacity = 0;
			}
		}

		public void ShowLabel(TView view, TEntity item)
		{
			var label = EntityView.Label(view);
			if (label != null) {
				label.Text = item.ToString();
				label.Opacity = 1;
			}
		}

		public void ShowImage(TView view, TEntity item)
		{
			var image = EntityView.Image(view);
			if (image != null) {
				image.Source = item.Icon;
				image.Opacity = 1;
			}
		}
	}
}
