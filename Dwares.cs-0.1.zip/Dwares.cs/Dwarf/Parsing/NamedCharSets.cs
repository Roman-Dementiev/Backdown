﻿using System;
using System.Text;
using System.Collections.Generic;
using Dwarf.Utility;
#pragma warning disable RCS1060, RCS1023


namespace Dwarf.Parsing
{
	/// <summary>
	/// Class StdCharsets
	/// </summary>
	public class NamedCharSets
	{
		Dictionary<string, CharSet> dict = new Dictionary<string, CharSet>();

		#region Constants
		public const char chHT = '\x09';		// Horizontal tab
		public const char chLF = '\x0A';		// Line feed
		public const char chVT = '\x0B';		// Vertical tab
		public const char chFF = '\x0C';		// Form feed
		public const char chCR = '\x0D';		// Carriage return
		public const char chSpace = ' ';
		public const char chNBSP = '\xA0';		// No-Break Space character
		public const char chLS = '\x2028';		// Unicode Line Separator
		public const char chPS = '\x2029';		// Unicode Paragraph Separator
		public const char chEuro = '\x20AC';	// Euro Currency Sign.

		public const string csHT = "{HT}";
		public const string csVT = "{VT}";
		public const string csFF = "{FF}";
		public const string csLF = "{LF}";
		public const string csCR = "{CR}";
		public const string csSpace = "{Space}";
		public const string csBlank = "{Blank}";
		public const string csNBSP = "{NBSP}";
		public const string csLS = "{LS}";
		public const string csPS = "{PS}";
		public const string csEuro = "{Euro}";
		public const string csControlCodes = "{Control Codes}";
		public const string csFormatting = "{Formatting}";
		public const string csWhitespace = "{Whitespace}";
		public const string csDigit = "{Digit}";
		public const string csLetter = "{Letter}";
		public const string csAlphaNumeric = "{AphaNumeric}";
		public const string csLowerCase = "{LowerCase}";
		public const string csUpperCase = "{UpperCase}";
		public const string csPrintable = "{Printable}";
		public const string csPrintableExtended = "{Printable Extended}";
		public const string csANSIPrintable = "{ANSI Printable}";
		public const string csLetterExtended = "{Letter Extended}";
		public const string csAllLatin = "{All Latin}";
//		public const string csAllLetter = "{All Letter}";
		public const string csAllPrintable = "{All Printable}";
		public const string csAllSpace = "{All Space}";
		public const string csAllNewline = "{All Newline}";
		public const string csAllWhitespace = "{All Whitespace}";
		public const string csAllValid = "{All Valid}";
		#endregion

		#region Properties
		public int DefaultNamingMaxRanges { get; set; } = 0;

		public Encoding<char> CharEncoding {
			get { return charEncoding ?? DefaultCharEncoding; }
			set { charEncoding = value; }
		}
		public Encoding<CharSet> Naming {
			get { return naming ?? DefaultNaming; }
			set { naming = value; }
		}
		public Encoding<CharSet> Descriptor {
			get { return descriptor ?? DefaultDescriptor; }
			set { descriptor = value; }
		}
		Encoding<char> charEncoding = null;
		Encoding<CharSet> naming = null;
		Encoding<CharSet> descriptor = null;

		public CharSet this[string name] {
			get { return GetCharSet(name); }
			set { AddCharSet(value, name); }
		}

		public CharSet HT => GetCharSet(csHT);
		public CharSet VT => GetCharSet(csVT);
		public CharSet FF => GetCharSet(csFF);
		public CharSet LF => GetCharSet(csLF);
		public CharSet CR => GetCharSet(csCR);
		public CharSet Space => GetCharSet(csSpace);
		public CharSet Blank => GetCharSet(csBlank);
		public CharSet NBSP => GetCharSet(csNBSP);
		public CharSet LS => GetCharSet(csLS);
		public CharSet PS => GetCharSet(csPS);
		public CharSet Euro => GetCharSet(csEuro);
		public CharSet ControlCodes => GetCharSet(csControlCodes);
		public CharSet Formatting => GetCharSet(csFormatting);
		public CharSet Whitespace => GetCharSet(csWhitespace);
		public CharSet Digit => GetCharSet(csDigit);
		public CharSet Letter => GetCharSet(csLetter);
		public CharSet AlphaNumeric => GetCharSet(csAlphaNumeric);
		public CharSet LowerCase => GetCharSet(csLowerCase);
		public CharSet UpperCase => GetCharSet(csUpperCase);
		public CharSet Printable => GetCharSet(csPrintable);
		public CharSet PrintableExtended => GetCharSet(csPrintableExtended);
		public CharSet ANSIPrintable => GetCharSet(csANSIPrintable);
		public CharSet LetterExtended => GetCharSet(csLetterExtended);
		public CharSet AllLatin => GetCharSet(csAllLatin);
//		public CharSet AllLetters => GetCharSet(csAllLetters);
		public CharSet AllPrintable => GetCharSet(csAllPrintable);
		public CharSet AllSpace => GetCharSet(csAllSpace);
		public CharSet AllNewline => GetCharSet(csAllNewline);
		public CharSet AllWhitespace => GetCharSet(csAllWhitespace);
		public CharSet AllValid => GetCharSet(csAllValid);
		#endregion

		#region Constructors
		public NamedCharSets()
		{
		}
		#endregion

		#region Methods
		public void AddStdCharSets()
		{
			foreach (var kvp in stdArrays) {
				string name = kvp.Key;
				if (!dict.ContainsKey(name)) {
					CharSet charSet = new CharSet(stdArrays[name]);
					charSet.Description = name;
					AddCharSet(charSet, name);
				}
			}
		}

		public string AddCharSet(CharSet charSet, string name = null, string defaultName = null)
		{
			if (charSet.Description == null) {
				charSet.Description = Descriptor(charSet);
			}

			if (name != null) {
				charSet.Name = name;
			} else if (charSet.Name != null) {
				name = charSet.Name;
			} else {
				name = Naming(charSet);
				if (name == null) {
					if (defaultName == null) {
						defaultName = String.Format("<0>", dict.Count+1);
					}
					name = defaultName;
				}
				charSet.Name = name;
			}

			dict.Add(name, charSet);
			return name;
		}

		public CharSet[] AddCharSets(ICharSets charSets, string defaultFormat = null, bool returnArray = false)
		{
			CharSet[] result = null;
			if (returnArray) {
				result = new CharSet[charSets.CharSetCount];
			}
			if (defaultFormat == null) {
				defaultFormat = "CS{0}";
			}
			for (uint i = 0; i < charSets.CharSetCount; i++) {
				CharSet charSet = charSets.GetCharSet(i);
				CharSet found = FindCharSet(charSet);
				if (found == null) {
					string defaultName = String.Format(defaultFormat, i);
					AddCharSet(charSet, null, defaultName);
				} else {
					charSet = found;
				}
				if (returnArray) {
					result[i] = charSet;
				}
			}

			return result;
		}

		public CharSet GetCharSet(string name)
		{
			if (dict.ContainsKey(name)) {
				return dict[name];
			}
			if (stdArrays.ContainsKey(name)) {
				CharSet charSet = new CharSet(stdArrays[name]);
				AddCharSet(charSet, name);
				return charSet;
			}
			return null;
		}

		public CharSet FindCharSet(CharSet charSet, bool checkStd = true)
		{
			if (!String.IsNullOrEmpty(charSet.Name)) {
				CharSet found = GetCharSet(charSet.Name);
				if (found != null && charSet.Equals(found))
					return found;
			}

			foreach(var kvp in dict) {
				if (charSet.Equals(kvp.Value))
					return kvp.Value;
			}

			if (checkStd)
			{
				foreach (var kvp in stdArrays) {
					if (dict.ContainsKey(kvp.Key))
						continue;

					if (charSet.Equals(kvp.Value)) {
						AddCharSet(charSet, kvp.Key);
						return charSet;
					}
				}

				return null;
			}

			return null;
		}

		public static string DefaultCharEncoding(char ch)
		{
			switch (ch)
			{
			case ' ': case chNBSP:
			case '.': case '[': case ']':
				break;
			default:
				if (ch.IsPrintable()) {
					return String.Format("{0}", ch);
				}
				break;
			}
			return Chars.AsciiAbbreviation(ch);
		}

		public string DefaultNaming(CharSet charSet)
		{
			if (DefaultNamingMaxRanges > 0 && charSet.RangeCount > DefaultNamingMaxRanges)
				return null;

			if (charSet.Description == null) {
				charSet.Description = Descriptor(charSet);
			}
			return charSet.Description;
		}

		public string DefaultDescriptor(CharSet charSet)
		{
			Encoding<char> charEncoding = CharEncoding;
			bool first = true;
			var ranges = charSet.Ranges;
			StringBuilder sb = new StringBuilder();
			foreach (CharSet.Range range in ranges) {
				if (first) {
					first = false;
				} else {
					sb.Append(" ");
				}
				if (range.end == range.start + 1) {
					sb.Append(charEncoding(range.start));
				} else {
					sb.Append("[");
					sb.Append(charEncoding(range.start));
					sb.Append("..");
					sb.Append(charEncoding((char)(range.end - 1)));
					sb.Append("]");
				}
			}
			return sb.ToString();
		}
		#endregion

		#region StdCharSetArrays
		private class StdCharSetArrays : Dictionary<string, char[]>
		{
			public StdCharSetArrays()
			{
				Add(csHT, arrHT);
				Add(csVT, arrVT);
				Add(csFF, arrFF);
				Add(csLF, arrLF);
				Add(csCR, arrCR);
				Add(csSpace, arrSpace);
				Add(csBlank, arrBlank);
				Add(csNBSP, arrNBSP);
				Add(csLS, arrLS);
				Add(csPS, arrPS);
				Add(csEuro, arrEuro);
				Add(csControlCodes, arrControlCodes);
				Add(csFormatting, arrFormatting);
				Add(csWhitespace, arrWhitespace);
				Add(csDigit, arrDigit);
				Add(csLetter, arrLetter);
				Add(csLetterExtended, arrLetterExtended);
				Add(csAlphaNumeric, arrAlphaNumeric);
				Add(csLowerCase, arrLowerCase);
				Add(csUpperCase, arrUpperCase);
				Add(csPrintable, arrPrintable);
				Add(csPrintableExtended, arrPrintableExtended);
				Add(csANSIPrintable, arrANSIPrintable);
				Add(csAllLatin, arrAllLatin);
//				Add(csAllLetters, arrAllLetters);
				Add(csAllPrintable, arrAllPrintable);
				Add(csAllSpace, arrAllSpace);
				Add(csAllNewline, arrAllNewline);
				Add(csAllWhitespace, arrAllWhitespace);
				Add(csAllValid, arrAllValid);
			}

		}
		public static char[] SingleChar(char ch) =>
			new char[] { ch, (char)(ch + 1) };

		public static char[] IncludeEnds(char[] array)
		{
			for (int i = 1; i < array.Length; i += 2) {
				array[i]++;
			}
			return array;
		}

		public static readonly char[] arrHT = SingleChar(chHT);
		public static readonly char[] arrVT = SingleChar(chVT);
		public static readonly char[] arrFF = SingleChar(chFF);
		public static readonly char[] arrLF = SingleChar(chLF);
		public static readonly char[] arrCR = SingleChar(chCR);
		public static readonly char[] arrSpace = SingleChar(chSpace);
		public static readonly char[] arrNBSP = SingleChar(chNBSP);
		public static readonly char[] arrLS = SingleChar(chLS);
		public static readonly char[] arrPS = SingleChar(chPS);
		public static readonly char[] arrEuro = SingleChar(chEuro);

		public static char[] arrControlCodes = IncludeEnds(new char[] {
			'\x00','\x1F',
			'\x7F','\x9F',
		});

		public static char[] arrFormatting = IncludeEnds(new char[] {
			'\x200B','\x200F',
			'\x202A','\x202E',
			'\x2060','\x2064',
			'\x206A','\x206F',
			'\xFEFF','\xFEFF',
			'\xFFF9','\xFFFB',
		});

		public static char[] arrWhitespace = IncludeEnds(new char[] {
			'\x09','\x0D',
			chSpace, chSpace,
			chNBSP, chNBSP
		});

		public static char[] arrBlank = IncludeEnds(new char[] {
			'\x09','\x09',
			'\x0B','\x0C',
			chSpace, chSpace,
			chNBSP, chNBSP
		});

		public static char[] arrDigit = IncludeEnds(new char[] {
			'0', '9'
		});

		public static char[] arrLetter = IncludeEnds(new char[] {
			'A', 'Z',
			'a', 'z'
		});

		public static char[] arrAlphaNumeric = IncludeEnds(new char[] {
			'0', '9',
			'A', 'Z',
			'a', 'z'
		});

		public static char[] arrLowerCase = IncludeEnds(new char[] {
			'a', 'z'
		});

		public static char[] arrUpperCase = IncludeEnds(new char[] {
			'A', 'Z'
		});

		public static char[] arrPrintable = IncludeEnds(new char[] {
			' ', '\x7E',
			chNBSP, chNBSP
		});

		public static char[] arrPrintableExtended = IncludeEnds(new char[] {
			'\xA1', '\xFF'
		});

		public static char[] arrANSIPrintable = IncludeEnds(new char[] {
			' ', '\x7E',
			'\xA0', '\xFF'
		});

		public static char[] arrLetterExtended = IncludeEnds(new char[] {
			'\xC0', '\xD6',
			'\xD8', '\xF6',
			'\xF8', '\xFF'
		});

		public static char[] arrAllLatin = IncludeEnds(new char[] {
			'A', 'Z',
			'a', 'z',
			'\xAA', '\xAA',
			'\xB5', '\xB5',
			'\xBA', '\xBA',
			'\xC0', '\xD6',
			'\xD8', '\xF6',
			'\xF8', '\x024F',
			'\x1E00', '\x1EFF',
			'\x2C60', '\x2C7F',
			'\xA720', '\xA7FF'
		});

		//public static char[] arrAllLetter = IncludeEnds(new char[] {
		//	...
		//});

		public static char[] arrAllPrintable = IncludeEnds(new char[] {
			'\x20', '\x7F',
			'\xA0', '\x200A',
			'\x2010', '\x2027',
			'\x202F', '\x205F',
			'\x2065', '\x2069',
			'\x2070', '\xD7FF',
			'\xE000', '\xFEFE',
			'\xFF00', '\xFFEF'
		});

		public static char[] arrAllSpace = IncludeEnds(new char[] {
			chSpace, chSpace,
			chNBSP, chNBSP,
			'\x1680', '\x1680',
			'\x180E', '\x180E',
			'\x2000', '\x200A',
			'\x202F', '\x202F',
			'\x205F', '\x205F',
			'\x3000', '\x3000'
		});

		public static char[] arrAllNewline = IncludeEnds(new char[] {
			'\x0A', '\x0A',
			'\x0D', '\x0D',
			'\x2028', '\x2029',
		});

		public static char[] arrAllWhitespace = IncludeEnds(new char[] {
			'\x09', '\x0D',
			chSpace, chSpace,
			'\x85', '\x85',
			chNBSP, chNBSP,
			'\x1680', '\x1680',
			'\x180E', '\x180E',
			'\x2000', '\x200A',
			'\x2028', '\x2029',
			'\x202F', '\x202F',
			'\x205F', '\x205F',
			'\x3000', '\x3000',
		});

		public static char[] arrAllValid = IncludeEnds(new char[] {
			'\x01', '\xD7FF',
			'\xE000', '\xFFEF',
		});

		private static StdCharSetArrays stdArrays = new StdCharSetArrays();

		#endregion
	}

	#region UnitStdCharsets
	public sealed class UnitStdCharsets : ClassUnit
	{
		private UnitStdCharsets() : base(typeof(NamedCharSets), UnitParsing._) { }
		public static readonly UnitStdCharsets _ = new UnitStdCharsets();
		public static UnitStdCharsets Instance => _;
	}
	#endregion
}
