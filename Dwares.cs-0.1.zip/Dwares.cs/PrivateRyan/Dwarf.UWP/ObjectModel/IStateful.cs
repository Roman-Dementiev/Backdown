﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dwarf.ObjectModel
{
	public interface IStateful
	{
		string StateKey { get; }

		void LoadState(StateDict state, StateDict shared, object navigationParameter);
		void SaveState(ref StateDict state, ref StateDict shared, object navigationParameter);
	}
}
