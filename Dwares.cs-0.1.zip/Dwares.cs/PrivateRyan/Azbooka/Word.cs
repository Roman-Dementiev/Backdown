﻿using System;
using System.Diagnostics;
using Dwarf.ObjectModel;


namespace Azbooka
{
	public class Word : Entity, ICloneable<Word>
	{
		public Word(string languageTag)
		{
			LanguageTag = languageTag ?? throw new ArgumentNullException(nameof(languageTag));
			Text = String.Empty;
		//	Uid = null;
			Meanings = new ClonableCollection<Meaning>();
			IsEditable = true;
		}


		public Word(string languageTag, string text)
		{
			LanguageTag = languageTag ?? throw new ArgumentNullException(nameof(languageTag));
			Text = text ?? throw new ArgumentNullException(nameof(text));
			Uid = String.Format("{0}-{1}", languageTag, Text);
			Meanings = new ClonableCollection<Meaning>();
			IsEditable = isEditable;
		}

		public Word(string languageTag, string text, string posTag, string meaningText) :
			this(languageTag, text)
		{
			var meaning = new Meaning(this) {
				PoS = PartsOfSpeech.GetPoS(languageTag, posTag),
				Text = meaningText
			};
			Meanings.Add(meaning);
		}

		public Word(Word word, bool deepCopy, bool isEditable = false)
		{
			CopyFrom(word, deepCopy);

			if (isEditable) {
				IsEditable = true;
			}
		}

		public string LanguageTag { get; private set; }
		public string Text { get; set; }

		public bool IsEditable {
			get => isEditable;
			set => isEditable.Set(value, () => Meanings.SetItemsProperty(nameof(Meaning.IsEditable), value));
		}
		ScalarPropertyValue<bool> isEditable;

		public ClonableCollection<Meaning> Meanings { get; private set; }

		object ICloneable.Clone(bool deepCopy) => new Word(this, deepCopy);
		public Word Clone(bool deepCopy) => new Word(this, deepCopy);
		
		public void CopyFrom(object obj, bool deepCopy)
		{
			if (obj is Word word) {
				CopyFrom(word, deepCopy);
			}
		}

		public void CopyFrom(Word word, bool deepCopy=false)
		{
			base.CopyFrom(word);
			LanguageTag = word.LanguageTag;
			Text = word.Text;
			Meanings = word.Meanings.Clone(deepCopy);
		}
	}
}
