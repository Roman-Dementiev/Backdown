using System;
using System.Collections.Generic;


namespace Dwarf.ObjectModel
{
	public interface ISelectableItems : IEnumerable<ISelectable>
	{
		IEnumerable<ISelectable> GetSepected();
	}
}
