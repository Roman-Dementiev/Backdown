﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dwarf.Collections;


namespace Dwarf.ObjectModel
{
	public class StateDict : Vocabulary
	{
		public void Load()
		{
			// TODO
		}

		public void Save()
		{
			// TODO
		}
	}
}
