﻿using System;
using System.Collections.Generic;
using Dwarf.Utility;

namespace Dwarf.Config
{
	/// <summary>
	/// Abstract class BaseConfig
	/// </summary>
	public abstract class CachedConfig : IConfig
	{
		#region Fields
		/// <summary>
		/// The cache containing configuration key-value pairs.
		/// </summary>
		protected Dictionary<string, object> cache = new Dictionary<string, object>();
		#endregion

		#region Constructors
		/// <summary>
		/// Initializes a new instance of the <see cref="CachedConfig" /> class.
		/// </summary>
		/// <param name="source">The buffer for this config.</param>
		/// <param name="mutable">if set to <c>true</c> config is mutable.</param>
		public CachedConfig(IConfig source, bool mutable = true)
		{
			Source = source;
			IsMutable = mutable;
			IsModified = false;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="CachedConfig"/> class.
		/// </summary>
		/// <param name="mutable">if set to <c>true</c> config is mutable.</param>
		public CachedConfig(bool mutable = true) :
			this(null, mutable)
		{}
		#endregion

		#region Properties
		/// <summary>
		/// Gets or sets the buffer for this config.
		/// </summary>
		/// <value>
		/// The buffer.
		/// </value>
		public IConfig Source { get; protected set; }

		/// <summary>
		/// Gets a value indicating whether this instance is mutable.
		/// </summary>
		/// <value>
		/// <c>true</c> if this instance is mutable; otherwise, <c>false</c>.
		/// </value>
		public bool IsMutable { get; }

		/// <summary>
		/// Determines whether this instance is modified.
		/// </summary>
		public bool IsModified { get; protected set; }

		#endregion

		#region Methods
		/// <summary>
		/// Gets a collection containing the keys in this config.
		/// </summary>
		/// <value>
		/// The keys.
		/// </value>
		public IEnumerable<string> Keys()
		{
			FetchAll();
			return cache.Keys;
		}

		/// <summary>
		/// Gets a collection containing all key and values in this config.
		/// </summary>
		/// <returns></returns>
		public IEnumerable<KeyValuePair<string, object>> All()
		{
			FetchAll();
			return cache;
		}

		/// <summary>
		/// Gets a collection containing key and values in the specified group.
		/// </summary>
		/// <param name="groupName">The name of the group.</param>
		/// <returns></returns>
		public IEnumerable<KeyValuePair<string, object>> Group(string groupName)
		{
			FetchAll();
			if (String.IsNullOrEmpty(groupName)) {
				return cache;
			}

			var group = new Dictionary<string, object>();
			foreach (KeyValuePair<string, object> kvp in cache)
			{
				string key = kvp.Key;
				if (key.StartsWith(groupName)) {
					if (key.Length == groupName.Length) {
						group.Add(String.Empty, kvp.Value);
					} else if (key[groupName.Length] == '.') {
						group.Add(key.Substring(groupName.Length + 1), kvp.Value);
					}
				}
			}

			return group;
		}

		/// <summary>
		/// Sets the default value for specified key.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="value">The value.</param>
		public void SetDefaultValue(string key, object value)
		{
			if (Get(key) == null) {
				cache[key] = value;
			}
		}

		/// Sets the value for specified key.
		/// </summary>
		/// <typeparam name="Type">Type of value</typeparam>
		/// <param name="key">The key.</param>
		/// <param name="value">The value.</param>
		public void Set<Type>(string key, Type value)
		{
			cache[key] = value;
			IsModified = true;
		}

		/// <summary>
		/// Gets the value for specified key.
		/// </summary>
		/// <typeparam name="Type">The type of the value.</typeparam>
		/// <param name="key">The key.</param>
		/// <returns></returns>
		public Type Get<Type>(string key)
		{
			 return (Type)Get(key, typeof(Type));
		}

		/// <summary>
		/// Gets value for specified key.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="type">The type of value; <c>null</c> for any type.</param>
		/// <returns>The value.</returns>
		public object Get(string key, Type type=null)
		{
			object value;
			if (cache.ContainsKey(key)) {
				value = cache[key];
			} else {
				value = Fetch(key, type);
				cache[key] = value;
			}
			if (value != null && type != null && !value.GetType().Equals(type)) {
				try {
					value = Convert.ChangeType(value, type);
				}
				catch (Exception exc) {
					throw new InvalidConfigValue(UnitBaseConfig._, key, value, type, exc);
				}
			}
			return value;
		}

		/// <summary>
		/// Gets the enum value for specified key.
		/// </summary>
		/// <typeparam name="EnumType">The type of the enum.</typeparam>
		/// <param name="key">The key.</param>
		/// <param name="ignoreCase"><c>true</c> to ignore case; <c>false</c> otherwise.</param>
		/// <returns></returns>
		public EnumType GetEnum<EnumType>(string key, bool ignoreCase = false) where EnumType : struct
		{
			object value = Get(key);
			if (value != null) {
				return Enums.ToEnum<EnumType>(value, ignoreCase);
			} else {
				return default(EnumType);
			}
		}
		#endregion

		/// <summary>
		/// Fetches all configuration data into <see cref="dictionary"/>.
		/// </summary>
		protected virtual void FetchAll()
		{
			if (Source != null) {
				foreach (string key in Source.Keys()) {
					if (!cache.ContainsKey(key)) {
						cache[key] = Source.Get(key);
					}
				}
			}
		}

		/// <summary>
		/// Fetches the value for specified key.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="type">The type of the value.</param>
		/// <returns>The value.</returns>
		protected virtual object Fetch(string key, Type type)
		{
			if (Source != null) {
				return Source.Get(key, type);
			} else {
				return null;
			}
		}

		/// <summary>
		/// Sets <see cref="IsModified" /> to <c>false</c>.
		/// </summary>
		public virtual void Commit()
		{
			IsModified = false;
		}
	}

	#region UnitBaseConfig
	#pragma warning disable RCS1060, RCS1023
	public sealed class UnitBaseConfig : ClassUnit
	{
		private UnitBaseConfig() : base(typeof(CachedConfig), UnitConfig._) { }
		public static readonly UnitBaseConfig _ = new UnitBaseConfig();
		public static UnitBaseConfig Instance => _;
	}
	#endregion
}
