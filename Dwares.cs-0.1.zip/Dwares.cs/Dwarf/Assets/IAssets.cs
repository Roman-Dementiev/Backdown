﻿using System;
using System.Collections;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Assets
{
	public interface IAssets
	{
		#region Properties
		bool IsMultiCultural { get; }
		object Culture { get; }
		object this[string key, Type type, object culture = null] { get; set; }
		#endregion

		#region Methods
		IEnumerable GetCultures();

		bool HasAsset(string key, object culture = null);
		void AddAsset(string key, object asset, object culture = null);
		object GetAsset(string key, object culture = null);
		object GetAsset(string key, Type type, object culture = null);

		void ReleaseAllAssets(bool dispose);
		void ReleaseCultureAssets(object culture, bool dispose);
		#endregion
	}

	#region UnitIAssets
	public sealed class UnitIAssets : InterfaceUnit
	{
		private UnitIAssets() : base(typeof(IAssets), UnitAssets._) { }
		public static readonly UnitIAssets _ = new UnitIAssets();
		public static UnitIAssets Instance => _;
	}
	#endregion
}
