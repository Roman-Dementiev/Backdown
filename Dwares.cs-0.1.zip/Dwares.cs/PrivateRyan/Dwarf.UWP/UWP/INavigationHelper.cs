﻿using System;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;


namespace Dwarf.UWP
{
	public interface INavigationHelper
	{
		void OnNavigatedTo(Page page, NavigationEventArgs e);
		void OnNavigatedFrom(Page page, NavigationEventArgs e);
		void OnNavigatingFrom(Page page, NavigatingCancelEventArgs e);
	}
}
