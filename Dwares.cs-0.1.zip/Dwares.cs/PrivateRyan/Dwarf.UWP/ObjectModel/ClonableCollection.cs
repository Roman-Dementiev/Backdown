﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dwarf.ObjectModel
{
	public class ClonableCollection<TItem> : EntityCollection<TItem>, ICloneable<ClonableCollection<TItem>>
		where TItem : class, IEntity, ICloneable<TItem>
	{
		public ClonableCollection() { }

		public ClonableCollection(ClonableCollection<TItem> items, bool deepCopy)
		{
			CopyFrom(items, deepCopy);
		}

		object ICloneable.Clone(bool deepCopy)
			=> new ClonableCollection<TItem>(this, deepCopy);

		public ClonableCollection<TItem> Clone(bool deepCopy)
			=> new ClonableCollection<TItem>(this, deepCopy);

		public void CopyFrom(ClonableCollection<TItem> items, bool deepCopy)
		{
			Clear();
			foreach (var item in items)
			{
				if (deepCopy) {
					Add(item.Clone(true));
				} else {
					Add(item);
				}
			}
		}

	}
}
