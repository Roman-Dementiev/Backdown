﻿//using System;
//using Windows.UI.Xaml.Controls;
//using Windows.UI.Xaml;
//using Dwarf.Platform;


//namespace Dwarf.UI
//{
//	public class LocalizedButton : AppBarButton //, ILocalizable
//	{
//		public LocalizedButton() { }

//		//public string Uid {
//		//	get => (string)GetValue(UidProperty);
//		//	set {
//		//		SetValue(UidProperty, value);
//		//		Localize();
//		//	}
//		//}
//		//public static readonly DependencyProperty UidProperty = UI.RegisterDependencyProperty<IconButton, string>(nameof(Uid));

//		public Symbol Symbol {
//			set {
//				Icon = new SymbolIcon(value);
//			}
//		}


//		//public new string Label {
//		//	get => base.Label;
//		//	set {
//		//		base.Label = value;
//		//		if (Uid == null && value != null) {
//		//			Uid = value;
//		//		}
//		//	}
//		//}

//		public Action Action {
//			set {
//				if (value == null) {
//					Command = null;
//				} else if (Command is RelayCommand relayCommand) {
//					relayCommand.SetExecute(value);
//				} else {
//					Command = new RelayCommand(value);
//				}
//			}
//		}

//		public virtual void Localize()
//		{
//			string uid = Localizer.GetUid(this);
//			if (!String.IsNullOrEmpty(uid)) {
//				Label = Appx.GetString(uid, true);
//			}
//		}

//		public void RaiseCanExecuteChanged()
//		{
//			if (Command is RelayCommand relayCommand) {
//				relayCommand.RaiseCanExecuteChanged();
//			}
//		}
//	}
//}
