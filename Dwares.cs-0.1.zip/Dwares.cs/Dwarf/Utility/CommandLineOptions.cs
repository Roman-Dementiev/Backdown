﻿using System;
using System.Collections.Generic;
using System.Reflection;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Utility
{
	/// <summary>
	/// Class CommandLineOptions
	/// </summary>
	public partial class CommandLine
	{
		public class OptionGroup : Element, IOptionGroup
		{
			List<IOption> options = new List<IOption>();

			public OptionGroup(string name, string description = null, string note = null,
								bool required = false, bool afterArguments = false) :
				base(name, description, note, required)
			{
				AfterArguments = afterArguments;
			}

			public bool AfterArguments { get; set; } = false;
			public IEnumerable<IOption> Options => options;
			public void Add(IOption option) =>  options.Add(option);
		}

		public class Option<TValue> : Argument<TValue>, IOption where TValue : IConvertible
		{
			#region Constructors
			public Option(IOptionGroup group, char shortName, string longName, string param, string description,
							string note, bool required, OptionStyle style = OptionStyle.Default) :
				base(param, description, note, required)
			{
				if ((Style & OptionStyle.IgnoreCase) != 0) {
					ShortName = char.ToLower(shortName);
					LongName = longName.ToLower();
				} else {
					ShortName = shortName;
					LongName = longName;
				}

				Group = group;
				Style = style;
			}

			public Option(OptionGroup group, char shortName, string longName, string param, string description,
						string note, bool required, object target, PropertyInfo propertyInfo, OptionStyle style = OptionStyle.Default) :
				this(group, shortName, longName, param, description, note, required, style)
			{
				InitForProperty(target, propertyInfo);
			}

			public Option(OptionGroup group, char shortName, string longName, string param, string description,
						string note, bool required, object target, string property, OptionStyle style = OptionStyle.Default) :
				this(group, shortName, longName, param, description, note, required)
			{
				InitForProperty(target, property);
			}
			#endregion

			#region Properties
			public IOptionGroup Group { get; }
			public char ShortName { get; set; }
			public string LongName { get; set; }
			public OptionStyle Style { get; set; }
			public bool IsHelpOption { get; set; } = false;
			public bool AllowMultiple { get; set; } = false;
			#endregion
		}

		public class MultiOption<TValue> : Option<TValue> where TValue : IConvertible
		{
			#region Properties
			public MultiOption(IOptionGroup group, char shortName, string longName, string param, string description,
								string note, bool required, OptionStyle style = OptionStyle.Default) :
				base(group, shortName, longName, param, description, note, required, style)
			{
				AllowMultiple = true;
				List = new List<TValue>();
			}

			public MultiOption(IOptionGroup group, char shortName, string longName, string param, string description,
								string note, bool required, object target, PropertyInfo propertyInfo, OptionStyle style = OptionStyle.Default) :
				base(group, shortName, longName, param, description, note, required, style)
			{
				AllowMultiple = true;
				InitForProperty(target, propertyInfo);
			}

			public MultiOption(IOptionGroup group, char shortName, string longName, string param, string description,
								string note, bool required, object target, string property, OptionStyle style = OptionStyle.Default) :
				base(group, shortName, longName, param, description, note, required, style)
			{
				AllowMultiple = true;
				InitForProperty(target, property);
			}

			protected new void InitForProperty(object target, string property)
			{
				if (target == null) {
					throw new ArgumentNullException(nameof(target));
				}
				if (String.IsNullOrEmpty(property)) {
					throw new ArgumentNullException(nameof(property));
				}

				PropertyInfo propertyInfo = Reflection.GetProperty(target, property, true);
				InitForProperty(target, propertyInfo);
			}

			protected new void InitForProperty(object target, PropertyInfo propertyInfo)
			{
				if (target == null) {
					throw new ArgumentNullException(nameof(target));
				}
				if (propertyInfo == null) {
					throw new ArgumentNullException(nameof(propertyInfo));
				}

				if (propertyInfo.PropertyType != typeof(List<TValue>)) {
					throw new ArgumentException(Messages.InvalidOptionType, propertyInfo.Name);
				}

				List = (List<TValue>)propertyInfo.GetMethod.Invoke(target, null);
			}
			#endregion

			#region Properties
			public List<TValue> List { get; private set; } = null;
			public new object Value { get { return List; } }
			#endregion

			#region Methods
			public new object GetValue()
			{
				return List;
			}

			public override object Parse(string text)
			{
				object value = base.Parse(text);
				List.Add(base.Value);
				return value;
			}
			#endregion
		}
	}
}
