﻿using System;


namespace Dwarf
{
	public class Wrapper<TObject> : IDisposable where TObject : class
	{
		public Wrapper(TObject obj = null)
		{
			wrapped = obj;
		}

		public TObject Value { 
			get => wrapped;
			protected set => wrapped = value;
		}
		protected TObject wrapped = null;

		public virtual void Dispose()
		{
			if (wrapped != null) {
				var disposable = wrapped as IDisposable;
				if (disposable != null) {
					disposable.Dispose();
				}
				wrapped = null;
			}
		}

		public static Wrapper<TObject> Wrap(TObject obj)
		{
			return new Wrapper<TObject>(obj);
		}

		public static TObject Unwrap(Wrapper<TObject> wrapper)
		{
			return (wrapper != null) ? wrapper.wrapped : null;
		}
	}

	public class ExplicitWrapper<TObject> : Wrapper<TObject> where TObject : class
	{
		public ExplicitWrapper(TObject obj = default(TObject)) : base(obj) { }

		public static explicit operator TObject(ExplicitWrapper<TObject> wrapper) => Unwrap(wrapper);
	}

	public class ImplicitWrapper<TObject> : Wrapper<TObject> where TObject : class
	{
		public ImplicitWrapper(TObject obj = default(TObject)) : base(obj) { }

		public static implicit operator TObject(ImplicitWrapper<TObject> wrapper) => Unwrap(wrapper);
	}
}
