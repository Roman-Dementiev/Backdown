﻿using System;
using Dwarf;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Logging
{
	/// <summary>
	/// Specifies what messages to output into log.
	/// </summary>
	public enum LogLevel
	{
		/// <summary>
		/// Output no messages.
		/// </summary>
		None,

		/// <summary>
		/// Output only fatal error messages.
		/// </summary>
		Fatal,

		/// <summary>
		/// Output all error messages.
		/// </summary>
		Error,

		/// <summary>
		/// Output error and warning messages.
		/// </summary>
		Warning,

		/// <summary>
		/// Output only important information messages and all above.
		/// </summary>
		Important,

		/// <summary>
		/// Output normal information messages and all above.
		/// </summary>
		Message,

		/// <summary>
		/// Output verbose information messages and all above.
		/// </summary>
		Verbose,

		/// <summary>
		/// Output debug messages and all above.
		/// </summary>
		Debug,

		/// <summary>
		/// Output tracing messages and all above.
		/// </summary>
		Trace,

		/// <summary>
		/// Output all messages.
		/// </summary>
		All = int.MaxValue,

#if DEBUG
		DebugOnly = Debug,

		/// <summary>
		/// The default log level.
		/// </summary>
		Default = Debug
#else
		DebugOnly = None,

		/// <summary>
		/// The default log level.
		/// </summary>
		Default = Message
#endif
	}

	#region UnitLogging
	public sealed class UnitLogging : NamespaceUnit
	{
		private UnitLogging() : base("Logging", UnitDwarf._) { }
		public static readonly UnitLogging _ = new UnitLogging();
		public static UnitLogging Instance => _;
	}
	#endregion
}
