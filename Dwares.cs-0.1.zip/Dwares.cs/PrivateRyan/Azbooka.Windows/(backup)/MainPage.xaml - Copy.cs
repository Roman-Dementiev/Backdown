﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Dwarf.Platform;


namespace Azbooka
{
	public sealed partial class MainPage : Page
	{
		DirectoryHelper directoryHelper;

		public MainPage()
		{
			this.InitializeComponent();

			directoryHelper = new DirectoryHelper(ViewModel.Directory);
			directory.ItemsSource = ViewModel.Directory;
			//secondary.ItemsSource = ViewModel.Secondary;

			directoryToggle.Command = new RelayCommand(directoryHelper.Toggle);
		}

		public Abc ViewModel => Abc.Instance;

		void directory_ContainerContentChanging(ListViewBase sender, ContainerContentChangingEventArgs args)
		{
			directoryHelper.ContainerContentChanging(sender, args);
		}
	}
}
