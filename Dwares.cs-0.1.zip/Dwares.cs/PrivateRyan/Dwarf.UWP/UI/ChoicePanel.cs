﻿using System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;


namespace Dwarf.UI
{
	public class ChoicePanel : StackPanel
	{
		public ChoicePanel()
		{
			Image = new Image() {
				Visibility = Visibility,
				Stretch = Stretch.Uniform,
				VerticalAlignment = VerticalAlignment.Stretch,
				HorizontalAlignment = HorizontalAlignment.Stretch
			};

			Label = new TextBlock() {
				Visibility = Visibility.Collapsed,
				VerticalAlignment = VerticalAlignment.Center,
				HorizontalAlignment = HorizontalAlignment.Left,
			};

			Orientation = Orientation.Horizontal;
			Margin = new Thickness(2);
			Padding = new Thickness(3, 0, 3, 0);


			Children.Add(Image);
			Children.Add(Label);
		}

		public TextBlock Label { get; }
		public Image Image { get; }

		public new Thickness Padding {
			get => base.Padding;
			set {
				base.Padding = value;
				Image.Margin = value;
				Label.Margin = value;
			}
		}

		public Brush Foreground {
			get => (Brush)GetValue(ForegroundProperty);
			set {
				SetValue(ForegroundProperty, value);
				Label.Foreground = value;
			}
		}
		public static readonly DependencyProperty ForegroundProperty = UI.RegisterDependencyProperty<ChoicePanel, Brush>(nameof(Foreground));

		public string LabelText {
			get => (string)GetValue(LabelTexthProperty);
			set {
				SetValue(LabelTexthProperty, value);
				Label.Text = value ?? String.Empty;
				Label.Visibility = String.IsNullOrEmpty(value) ? Visibility.Collapsed : LabelVisibility;
			}
		}
		public static readonly DependencyProperty LabelTexthProperty = UI.RegisterDependencyProperty<ChoicePanel, string>(nameof(LabelText));

		public Visibility LabelVisibility {
			get => (Visibility)GetValue(LabelVisibilityProperty);
			set {
				SetValue(LabelVisibilityProperty, value);
				if (!String.IsNullOrEmpty(LabelText)) {
					Label.Visibility = value;
				}
			}
		}
		public static readonly DependencyProperty LabelVisibilityProperty = UI.RegisterDependencyProperty<ChoicePanel, Visibility>(nameof(LabelVisibility));

		public ImageSource ImageSource {
			get => (ImageSource)GetValue(ImageSourceProperty);
			set {
				SetValue(ImageSourceProperty, value);
				if (value != null) {
					Image.Source = value;
					Image.Visibility = ImageVisibility;
				} else {
					Image.Visibility = Visibility.Collapsed;
				}
			}
		}
		public static readonly DependencyProperty ImageSourceProperty = UI.RegisterDependencyProperty<ChoicePanel, ImageSource>(nameof(ImageSource));

		public Visibility ImageVisibility {
			get => (Visibility)GetValue(ImageVisibilityProperty);
			set {
				SetValue(ImageVisibilityProperty, value);
				if (ImageSource != null) {
					Image.Visibility = value;
				}
			}
		}
		public static readonly DependencyProperty ImageVisibilityProperty = UI.RegisterDependencyProperty<ChoicePanel, Visibility>(nameof(ImageVisibility));

		public double ImageWidth {
			get => (double)GetValue(ImageWidthProperty);
			set {
				SetValue(ImageWidthProperty, value);
				Image.Width = value;
			}
		}
		public static readonly DependencyProperty ImageWidthProperty = UI.RegisterDependencyProperty<ChoicePanel, double>(nameof(ImageWidth));

		public double ImageHeight {
			get => (double)GetValue(ImageHeightProperty);
			set {
				SetValue(ImageHeightProperty, value);
				Image.Height = value;
			}
		}
		public static readonly DependencyProperty ImageHeightProperty = UI.RegisterDependencyProperty<ChoicePanel, double>(nameof(ImageHeight));
	}
}
