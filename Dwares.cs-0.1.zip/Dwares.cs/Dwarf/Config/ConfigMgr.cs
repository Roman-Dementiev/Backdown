﻿using System;
using System.IO;
using Dwarf.Utility;
using Factories = System.Collections.Generic.Dictionary<string, Dwarf.Config.IConfigFactory>;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Config
{
	/// <summary>
	/// Class ConfigMgr
	/// </summary>
	public class ConfigMgr : Manager<ConfigMgr, IConfig, Factories, Factories>, IConfigFactory
	{
		#region Properties
		public Factories Factories => source;
		#endregion


		#region Constructors
		public ConfigMgr() { }
		public ConfigMgr(MakeCurrentMode mode) : base(mode) { }
		#endregion

		#region Methods
		public IConfigFactory GetFactory(string ext)
		{
			if (Factories != null) {
				return Factories[ext.ToLowerCase()];
			} else {
				return null;
			}
		}

		public void AddFactory(string ext, IConfigFactory factory)
		{
			Factories factories = GetSource();
			factories[ext.ToLowerCase()] = factory;
		}

		public virtual IConfig CreateFromFile(string filename)
		{
			if (Factories != null) {
				string ext = Path.GetExtension(filename).ToLowerCase();
				IConfigFactory factory = Factories[ext];
				return factory?.CreateFromFile(filename);
			} else {
				return null;
			}
		}

		public virtual IConfig CreateFromStream(Stream stream) => null;
		#endregion

		#region Static Methods
		public static IConfig CreateConfig(string filename) =>
			GetManaged(mgr => mgr.CreateFromFile(filename));
	
		public static IConfig CreateConfig(Stream stream) =>
			GetManaged(mgr => mgr.CreateFromStream(stream));
		#endregion

	}

	#region UnitConfigMgr
	public sealed class UnitConfigMgr : ClassUnit
	{
		private UnitConfigMgr() : base(typeof(ConfigMgr), UnitConfig._) { }
		public static readonly UnitConfigMgr _ = new UnitConfigMgr();
		public static UnitConfigMgr Instance => _;
	}
	#endregion
}
