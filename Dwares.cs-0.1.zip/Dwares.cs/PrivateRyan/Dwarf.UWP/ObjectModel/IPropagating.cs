﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dwarf.ObjectModel
{
	//public interface IPropagating
	//{
	//	void PropagateProperty(string propertyName, object propertyValue);
	//}


	//public static partial class Extensions
	//{
	//	public static void PropagateProperties(this IPropagating propagating, object source, bool sourceMustHaveProperties, params string[] propertyNames)
	//	{
	//		foreach (var propertyName in propertyNames) {
	//			var propertyInfo = Reflection.GetProperty(source, propertyName, sourceMustHaveProperties);
	//			if (propertyInfo != null) {
	//				var propertyValue = Reflection.GetPropertyValue(source, propertyInfo);
	//				propagating.PropagateProperty(propertyName, propertyValue);
	//			}
	//		}
	//	}

	//	public static void PropagateProperties(this IPropagating propagating, bool mustHaveProperties, params string[] propertyNames)
	//		=> PropagateProperties(propagating, propagating, mustHaveProperties, propertyNames);
		
	//	public static void PropagateProperties(this IPropagating propagating, params string[] propertyNames) 
	//		=> PropagateProperties(propagating, propagating, false, propertyNames);
	//}
}
