﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing
{
	/// <summary>
	/// Interface IDfaStates
	/// </summary>
	public interface IDfaStates
	{
		#region Properties
		int StateCount { get; }
		#endregion

		#region Methods
		int AcceptSymbol(uint state);
		bool IsAcceptState(uint state);
		uint EdgeCount(uint state);
		uint EdgeCharSet(uint state, uint edge);
		uint EdgeTargetState(uint state, uint edge);
		#endregion
	}

	#region UnitIDfaStates
	public sealed class UnitIDfaStates : InterfaceUnit
	{
		private UnitIDfaStates() : base(typeof(IDfaStates), UnitParsing._) { }
		public static readonly UnitIDfaStates _ = new UnitIDfaStates();
		public static UnitIDfaStates Instance => _;
	}
	#endregion
}
