﻿//using System;
//#pragma warning disable RCS1060, RCS1023

//namespace $rootnamespace$
//{
//	/// <summary>
//	/// Abstract class $safeitemrootname$
//	/// </summary>
//	public abstract class $safeitemrootname$
//	{
//		#region Fields
//		#endregion

//		#region Properties
//		#endregion

//		#region Constructors
//		public $safeitemrootname$()
//		{
//		}
//		#endregion

//		#region Methods
//		#endregion
//	}

//	#region Unit$safeitemrootname$
//	public sealed class Unit$safeitemrootname$ : ClassUnit
//	{
//		private Unit$safeitemrootname$() : base(typeof($safeitemrootname$), Unit/*$rootnamespace$*/._) { }
//		public static readonly Unit$safeitemrootname$ _ = new Unit$safeitemrootname$();
//		public static Unit$safeitemrootname$ Instance => _;
//	}
//	#endregion
//}
