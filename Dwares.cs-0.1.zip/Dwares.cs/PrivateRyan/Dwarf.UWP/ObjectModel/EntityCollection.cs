﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;


namespace Dwarf.ObjectModel
{
	public class EntityCollection<TItem> : ObservableCollection<TItem> //, IPropagating
		where TItem : class, IEntity
	{
		public EntityCollection() { }

		public EntityCollection(IEnumerable<TItem> items)
		{
			foreach (var item in items) {
				Add(item);
			}
		}

		public new virtual int Add(TItem item)
		{
			int index = IndexOf(item);
			if (index < 0) {
				index = Count;
				base.Add(item);
			}
			return index;
		}

		public void Add(IEnumerable<TItem> items)
		{
			foreach (var item in items) {
				Add(item);
			}
		}


		protected override void ClearItems()
		{
			foreach (var item in this) {
				if (item is IIndexed indexed) {
					indexed.Index = -1;
				}
			}
			base.ClearItems();
		}

		protected override void InsertItem(int index, TItem item)
		{
			if (item is IIndexed indexed) {
				indexed.Index = index;
			}

			base.InsertItem(index, item);
			ReorderItems(index+1);
		}

		protected override void RemoveItem(int index)
		{
			if (this[index] is IIndexed indexed) {
				indexed.Index = -1;
			}

			base.RemoveItem(index);
			ReorderItems(index);
		}

		protected void ReorderItems(int startingIndex)
		{
			for (int index = startingIndex; index < Count; index++) {
				if (this[index] is IIndexed indexed) {
					indexed.Index = index;
				}
			}
		}

		protected override void SetItem(int index, TItem item)
		{
			base.SetItem(index, item);
			if (item is IIndexed ordered) {
				ordered.Index = index;
			}
		}

		public void SetItemsProperty(string propertyName, object propertyValue)
		{
			foreach (var item in this) {
				Reflection.SetPropertyValue(item, propertyName, propertyValue, false);
			}
		}
	}
}
