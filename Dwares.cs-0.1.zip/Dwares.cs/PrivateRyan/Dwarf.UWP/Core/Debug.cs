﻿using System;
using System.Diagnostics;


namespace Dwarf
{
	public static class Debug
	{
		public static void Print(object obj)
		{
			// TODO: Logging
			System.Diagnostics.Debug.WriteLine(obj);
		}

		public static void Print(string format, params object[] args)
		{
			// TODO: Logging
			System.Diagnostics.Debug.WriteLine(format, args);
		}
	}
}
