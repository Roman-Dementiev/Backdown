﻿using System;
using System.Data;
using System.Data.Common;

namespace Dwarf.Data
{
	public interface ICommandParameters
	{
//		string ParameterName(string column);

		DbParameter AddParameter(string column, DbType type, object value = null);
		DbParameter AddBlobParameter(string column, byte[] value = null);
		DbParameter AddTextParameter(string column, string text = null);
		DbParameter AddBoolParameter(string column, bool? value = null);
		DbParameter AddLongParameter(string column, long? value = null);
		DbParameter AddIntParameter(string column, int? value = null);

		// TODO
	}
}
