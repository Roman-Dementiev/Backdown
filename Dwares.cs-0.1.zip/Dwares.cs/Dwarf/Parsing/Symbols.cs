﻿using System;
#pragma warning disable RCS1060, RCS1023

namespace Dwarf.Parsing
{
	/// <summary>
	/// 
	/// Class Symbols
	/// </summary>
	public class Symbols
	{
		#region Constants
		public const int cEOF = 0;
		public const int cError = 1;
		#endregion

		#region Properties
		public string[] Names { get; protected set; }
		public uint NoiseCount { get; protected set; }
		public uint NoiseStart { get; protected set; }
		public uint NoiseEnd { get; protected set; }
		public uint TerminalCount { get; protected set; }
		public uint TerminalStart { get; protected set; }
		public uint TerminalEnd { get; protected set; }
		public uint NonterminalCount { get; protected set; }
		public uint NonterminalStart { get; protected set; }
		public uint NonterminalEnd { get; protected set; }
		public uint SymbolCount { get; protected set; }
		public uint LexerSymbolCount { get; protected set; }
		#endregion

		#region Constructors
		protected Symbols()
		{
		}

		public Symbols(uint terminalCount, uint nonterminalCount, uint noiseCount, string[] names=null)
		{
			Init(terminalCount, nonterminalCount, noiseCount, names);
		}

		protected void Init(uint terminalCount, uint nonterminalCount, uint noiseCount, string[] names = null)
		{
			Names = names ?? new string[0];
			NoiseCount = noiseCount;
			NoiseStart = cError + 1;
			NoiseEnd = NoiseStart + NoiseCount;
			TerminalCount = terminalCount;
			TerminalStart = NoiseEnd;
			TerminalEnd = TerminalStart + TerminalCount;
			NonterminalCount = nonterminalCount;
			NonterminalStart = TerminalEnd;
			NonterminalEnd = NonterminalStart + NonterminalCount;
			SymbolCount = NonterminalEnd;
			LexerSymbolCount = TerminalEnd;
		}
		#endregion

		#region Methods
		public virtual int Find(string name)
		{
			for (int sym = 0; sym < SymbolCount; sym++) {
				if (name == GetName(sym))
					return sym;
			}
			return -1;
		}

		public virtual string GetName(int sym)
		{
			if (sym < Names.Length && !String.IsNullOrEmpty(Names[sym])) {
				return Names[sym];
			}
			if (IsEOF(sym)) {
				return "(EOF)";
			}
			if (IsError(sym)) {
				return "(Error)";
			}
			if (IsNoise(sym)) {
				return String.Format("Noise[{0}]", sym);
			}
			if (IsTerminal(sym)) {
				return String.Format("Terminal[{0}]", sym);
			}
			if (IsNonterminal(sym)) {
				return String.Format("Nonterminal[{0}]", sym);
			}
			return String.Empty;
		}

		public bool IsValid(int sym) {
			return sym >= 0 && sym < SymbolCount;
		}

		public  bool IsEOF(int sym) {
			return sym == cEOF;
		}

		public bool IsError(int sym) {
			return sym == cError;
		}

		public bool IsNoise(int sym) {
			return sym >= NoiseStart && sym < NoiseEnd;
		}

		public bool IsTerminal(int sym) {
			return sym >= TerminalStart && sym < TerminalEnd;
		}

		public bool IsNonterminal(int sym) {
			return sym >= NonterminalStart && sym < NonterminalEnd;
		}

		#endregion

	}

	#region UnitSymbol
	public sealed class UnitSymbols : ClassUnit
	{
		private UnitSymbols() : base(typeof(Symbols), UnitParsing._) { }
		public static readonly UnitSymbols _ = new UnitSymbols();
		public static UnitSymbols Instance => _;
	}
	#endregion
}
