﻿using System;


namespace Dwarf.Platform
{
	public interface ICommand : System.Windows.Input.ICommand
	{
	}
}
